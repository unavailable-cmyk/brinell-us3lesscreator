#include "GlRenderer.hpp"
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <GL/gl.h>
#include <algorithm>
#include <bit>
#include <chrono>
#include <cstddef>
#include <cstring>
#include <limits>
#include <optional>
#include <stdexcept>
#include <string>

namespace vulkanizer::v2 {
namespace {
constexpr GLenum arrayBuffer = 0x8892, uniformBuffer = 0x8a11;
constexpr GLenum storageBuffer = 0x90d2, dispatchBuffer = 0x90ee;
constexpr GLbitfield shaderBarrier = 0x2000, commandBarrier = 0x0040, bufferUpdateBarrier = 0x0200;
constexpr std::uint32_t workgroupWidth = 64, maxCommands = 256;
using Clock = std::chrono::steady_clock;
constexpr std::size_t pageBytes = paletteSize * sizeof(PaletteEntry);
const char* vertexSource = R"(#version 330 core
layout(location=0) in vec3 position;
layout(location=1) in vec2 texcoord;
layout(location=2) in vec4 color;
layout(location=3) in float chain;
layout(std140) uniform Chains { vec4 translation[256]; };
uniform mat4 mvp;
out vec2 uv;
out vec4 tint;
void main() {
    vec3 p = position;
    p.xy += translation[int(chain)].xy;
    gl_Position = mvp * vec4(p, 1.0);
    uv = texcoord;
    tint = color;
})";
const char* fragmentSource = R"(#version 330 core
in vec2 uv;
in vec4 tint;
uniform sampler2D texture0;
out vec4 outputColor;
void main() { outputColor = texture(texture0, uv) * tint; }
)";
const char* residentVertex = R"(#version 430 core
layout(location=0) in vec3 position;
layout(location=1) in vec2 texcoord;
layout(location=2) in vec4 color;
layout(location=4) in uint objectId;
struct Resident { dvec4 position; vec4 angles; ivec2 section; uint properties; uint pad; };
layout(std430,binding=0) readonly buffer State { Resident states[]; };
uniform mat4 mvp;
out vec2 uv;
out vec4 tint;
void main() {
    Resident state = states[objectId];
    vec3 p = position;
    if (state.angles.xy == state.angles.zw) {
        p.xy += vec2(state.position.xy - state.position.zw);
    } else {
        // Cocos uses clockwise rotation, with separate X/Y basis angles.
        vec2 oldAngle = radians(-state.angles.zw);
        vec2 newAngle = radians(-state.angles.xy);
        mat2 oldBasis = mat2(cos(oldAngle.y), sin(oldAngle.y), -sin(oldAngle.x), cos(oldAngle.x));
        mat2 newBasis = mat2(cos(newAngle.y), sin(newAngle.y), -sin(newAngle.x), cos(newAngle.x));
        vec2 local = position.xy - vec2(state.position.zw);
        vec2 delta = newAngle - oldAngle;
        mat2 rigid = mat2(cos(delta.x), sin(delta.x), -sin(delta.x), cos(delta.x));
        mat2 basis = abs(determinant(oldBasis)) > 0.00001 ? newBasis * inverse(oldBasis) : rigid;
        p.xy = vec2(state.position.xy) + basis * local;
    }
    gl_Position = mvp * vec4(p, 1.0);
    uv = texcoord;
    tint = color;
})";
const char* gatherSource = R"(#version 430 core
layout(local_size_x=64) in;
struct Move { dvec2 delta; uint group; uint stamp; uint flags; uint kind; dvec2 center; vec4 matrix; vec2 shift; float orientation; uint journalIndex; };
struct Resident { dvec4 position; vec4 angles; ivec2 section; uint properties; uint pad; };
layout(std430,binding=0) buffer State { Resident states[]; };
layout(std430,binding=1) readonly buffer GroupOffsets { uint groupOffset[]; };
layout(std430,binding=2) readonly buffer Members { uint members[]; };
layout(std430,binding=5) readonly buffer Commands { Move commands[]; };
layout(std430,binding=6) buffer Stamps { uint seen[]; };
layout(std430,binding=7) buffer Work { uint x; uint y; uint z; uint count; uint ids[]; };
uniform uint epoch, commandCount, retireCount;
uniform int gather;
void main() {
    uint i = gl_GlobalInvocationID.x;
    if (gather == 2) {
        if (i < commandCount) {
            uint object = commands[i].group & 0x7fffffffu;
            // Never reactivate a genuinely retired resident.
            if (seen[object] != 0xffffffffu) states[object].position.xy = commands[i].delta;
        }
        return;
    }
    if (gather == 0) {
        if (i == 0u) { x = 0u; y = 1u; z = 1u; count = 0u; }
        if (i < retireCount) seen[commands[commandCount + i].group] = 0xffffffffu;
        return;
    }
    uint group = commands[commandCount + retireCount + gl_WorkGroupID.y].group;
    uint first = groupOffset[group];
    if (i >= groupOffset[group + 1u] - first) return;
    uint object = members[first + i];
    if (atomicAdd(seen[object], 0u) == 0xffffffffu) return;
    if (atomicExchange(seen[object], epoch) == epoch) return;
    uint slot = atomicAdd(count, 1u);
    ids[slot] = object;
    atomicMax(x, slot / 64u + 1u);
})";
const char* applySource = R"(#version 430 core
layout(local_size_x=64) in;
struct Move { dvec2 delta; uint group; uint stamp; uint flags; uint kind; dvec2 center; vec4 matrix; vec2 shift; float orientation; uint journalIndex; };
struct Resident { dvec4 position; vec4 angles; ivec2 section; uint properties; uint pad; };
struct SectionEvent { dvec2 position; uint object; uint action; uvec2 reserved; };
layout(std430,binding=0) buffer State { Resident states[]; };
layout(std430,binding=1) buffer Events { uint eventCount; uint eventPad0; uint eventPad1; uint eventPad2; SectionEvent events[]; };
layout(std430,binding=3) readonly buffer ObjectOffsets { uint objectOffset[]; };
layout(std430,binding=4) readonly buffer ObjectGroups { uint groups[]; };
layout(std430,binding=5) readonly buffer Commands { Move commands[]; };
layout(std430,binding=7) readonly buffer Work { uint x; uint y; uint z; uint count; uint ids[]; };
uniform uint commandCount;
uniform uint sectionXBits, sectionYBits;
bool contains(uint first, uint end, uint target) {
    uint limit = end;
    while (first < end) {
        uint mid = first + (end - first) / 2u;
        if (groups[mid] < target) first = mid + 1u;
        else end = mid;
    }
    return first < limit && groups[first] == target;
}
int sectionIndex(double value, float factor) {
    if (value <= 0.0LF) return 0;
    if (value >= 10000000.0LF) return int(10000000.0 * factor);
    return int(value * double(factor));
}
void main() {
    uint i = gl_GlobalInvocationID.x;
    if (i >= count) return;
    uint object = ids[i];
    uint first = objectOffset[object], end = objectOffset[object + 1u];
    Resident state = states[object];
    precise dvec2 position = state.position.xy;
    for (uint j = 0u; j < commandCount; ++j) {
        Move movement = commands[j];
        if (!contains(first, end, movement.group)) continue;
        if (movement.kind == 1u) {
            precise vec2 relative = vec2(position - movement.center);
            precise dvec2 xa = double(relative.x) * dvec2(movement.matrix.xy);
            precise dvec2 yc = double(relative.y) * dvec2(movement.matrix.zw);
            precise vec2 point = vec2((yc + xa) + dvec2(movement.shift));
            precise vec2 moved = point + vec2(movement.delta);
            precise dvec2 delta = dvec2(moved) - position;
            position = position + delta;
            if ((state.properties & 1u) != 0u && movement.orientation != 0.0) {
                precise vec2 angle = state.angles.xy + vec2(movement.orientation);
                state.angles.xy = angle;
            }
        } else {
            if (movement.delta.x != 0.0LF) position.x += movement.delta.x;
            if (movement.delta.y != 0.0LF) position.y += movement.delta.y;
        }
        if ((movement.flags & 2u) != 0u && state.section.x >= 0) {
            ivec2 section = ivec2(sectionIndex(position.x, uintBitsToFloat(sectionXBits)),
                sectionIndex(position.y, uintBitsToFloat(sectionYBits)));
            if (any(notEqual(section, state.section))) {
                uint slot = atomicAdd(eventCount, 1u);
                events[slot] = SectionEvent(position, object, movement.journalIndex, uvec2(0));
                state.section = section;
            }
        }
    }
    state.position.xy = position;
    states[object] = state;
})";
}
namespace {
struct alignas(32) ResidentGpuState {
    std::array<double, 4> position;
    std::array<float, 4> angles;
    std::int32_t sectionX, sectionY;
    std::uint32_t properties, pad = 0;
};
static_assert(sizeof(ResidentGpuState) == 64 && offsetof(ResidentGpuState, angles) == 32 &&
    offsetof(ResidentGpuState, sectionX) == 48);
}
struct GlRenderer::Impl {
#define PROC(R, N, A) R(APIENTRY* N)A = nullptr
    PROC(GLuint, CreateShader, (GLenum));
    PROC(void, ShaderSource, (GLuint, GLsizei, const char* const*, const GLint*));
    PROC(void, CompileShader, (GLuint));
    PROC(void, GetShaderiv, (GLuint, GLenum, GLint*));
    PROC(void, GetShaderInfoLog, (GLuint, GLsizei, GLsizei*, char*));
    PROC(void, DeleteShader, (GLuint));
    PROC(GLuint, CreateProgram, ());
    PROC(void, AttachShader, (GLuint, GLuint));
    PROC(void, LinkProgram, (GLuint));
    PROC(void, GetProgramiv, (GLuint, GLenum, GLint*));
    PROC(void, GetProgramInfoLog, (GLuint, GLsizei, GLsizei*, char*));
    PROC(void, DeleteProgram, (GLuint));
    PROC(void, UseProgram, (GLuint));
    PROC(GLint, GetUniformLocation, (GLuint, const char*));
    PROC(void, Uniform1i, (GLint, GLint));
    PROC(void, UniformMatrix4fv, (GLint, GLsizei, GLboolean, const float*));
    PROC(GLuint, GetUniformBlockIndex, (GLuint, const char*));
    PROC(void, UniformBlockBinding, (GLuint, GLuint, GLuint));
    PROC(void, GenBuffers, (GLsizei, GLuint*));
    PROC(void, DeleteBuffers, (GLsizei, const GLuint*));
    PROC(void, BindBuffer, (GLenum, GLuint));
    PROC(void, BufferData, (GLenum, std::ptrdiff_t, const void*, GLenum));
    PROC(void, BufferSubData, (GLenum, std::ptrdiff_t, std::ptrdiff_t, const void*));
    PROC(void, BindBufferRange, (GLenum, GLuint, GLuint, std::ptrdiff_t, std::ptrdiff_t));
    PROC(void, GenVertexArrays, (GLsizei, GLuint*));
    PROC(void, DeleteVertexArrays, (GLsizei, const GLuint*));
    PROC(void, BindVertexArray, (GLuint));
    PROC(void, EnableVertexAttribArray, (GLuint));
    PROC(void, VertexAttribPointer, (GLuint, GLint, GLenum, GLboolean, GLsizei, const void*));
    PROC(void, VertexAttribIPointer, (GLuint, GLint, GLenum, GLsizei, const void*));
    PROC(void, Uniform1ui, (GLint, GLuint));
    PROC(void, DispatchCompute, (GLuint, GLuint, GLuint));
    PROC(void, DispatchComputeIndirect, (std::ptrdiff_t));
    PROC(void, MemoryBarrier, (GLbitfield));
    PROC(void, GetBufferSubData, (GLenum, std::ptrdiff_t, std::ptrdiff_t, void*));
    PROC(void, GetIntegerv, (GLenum, GLint*));
    PROC(void, GetIntegeri_v, (GLenum, GLuint, GLint*));
    PROC(void, GetInteger64i_v, (GLenum, GLuint, std::int64_t*));
    PROC(void, BindBufferBase, (GLenum, GLuint, GLuint));
    PROC(void, DrawArrays, (GLenum, GLint, GLsizei));
    PROC(GLenum, GetError, ());
#undef PROC
    GLuint program = 0, geometry = 0, palette = 0, vao = 0;
    GLuint residentProgram = 0, gatherProgram = 0, applyProgram = 0;
    std::array<GLuint, 8> storage{};
    GLuint sectionEvents = 0;
    std::size_t sectionCapacity = 0;
    std::vector<std::uint32_t> groupWidths, gatheredEpochs;
    std::vector<gpu::ResidentTranslation> uploads;
    std::uint32_t epoch = 0;
    std::size_t residentObjectCount = 0;
    GLint gatherPhase = -1, gatherEpoch = -1, retireCount = -1, gatherCount = -1, applyCount = -1;
    GLint applySectionX = -1, applySectionY = -1;
    GLint residentMvp = -1, residentTexture = -1;
    GLint mvpLocation = -1, textureLocation = -1;
    std::size_t stride = pageBytes;
    std::uint64_t generation = 0;
    RenderCounters counters;

    explicit Impl(const Resolve& resolve) {
#define LOAD(N) N = reinterpret_cast<decltype(N)>(resolve("gl" #N)); if (!N) throw std::runtime_error("Missing GL entry point gl" #N)
        LOAD(CreateShader); LOAD(ShaderSource); LOAD(CompileShader); LOAD(GetShaderiv);
        LOAD(GetShaderInfoLog); LOAD(DeleteShader); LOAD(CreateProgram); LOAD(AttachShader);
        LOAD(LinkProgram); LOAD(GetProgramiv); LOAD(GetProgramInfoLog); LOAD(DeleteProgram);
        LOAD(UseProgram); LOAD(GetUniformLocation); LOAD(Uniform1i); LOAD(UniformMatrix4fv);
        LOAD(GetUniformBlockIndex); LOAD(UniformBlockBinding); LOAD(GenBuffers); LOAD(DeleteBuffers);
        LOAD(BindBuffer); LOAD(BufferData); LOAD(BufferSubData); LOAD(BindBufferRange);
        LOAD(GenVertexArrays); LOAD(DeleteVertexArrays); LOAD(BindVertexArray);
        LOAD(EnableVertexAttribArray); LOAD(VertexAttribPointer); LOAD(GetIntegerv); LOAD(DrawArrays); LOAD(GetError);
        LOAD(GetIntegeri_v); LOAD(GetInteger64i_v); LOAD(BindBufferBase);
#undef LOAD
#define OPTIONAL(N) N = reinterpret_cast<decltype(N)>(resolve("gl" #N))
        OPTIONAL(VertexAttribIPointer); OPTIONAL(Uniform1ui); OPTIONAL(DispatchCompute);
        OPTIONAL(DispatchComputeIndirect); OPTIONAL(MemoryBarrier); OPTIONAL(GetBufferSubData);
#undef OPTIONAL
    }
    void check(const char* operation) {
        const auto error = GetError();
        if (error) throw std::runtime_error(std::string(operation) + " GL error " + std::to_string(error));
    }
    struct StateGuard {
        Impl& gl;
        GLint program = 0, vao = 0, array = 0, uniform = 0, indexed = 0;
        std::int64_t start = 0, size = 0;
        explicit StateGuard(Impl& api) : gl(api) {
            gl.GetIntegerv(0x8b8d, &program);
            gl.GetIntegerv(0x85b5, &vao);
            gl.GetIntegerv(0x8894, &array);
            gl.GetIntegerv(0x8a28, &uniform);
            gl.GetIntegeri_v(0x8a28, 0, &indexed);
            gl.GetInteger64i_v(0x8a29, 0, &start);
            gl.GetInteger64i_v(0x8a2a, 0, &size);
        }
        ~StateGuard() {
            gl.UseProgram(program);
            gl.BindVertexArray(vao);
            gl.BindBuffer(arrayBuffer, array);
            if (indexed && size > 0) gl.BindBufferRange(uniformBuffer, 0, indexed, start, size);
            else gl.BindBufferBase(uniformBuffer, 0, indexed);
            gl.BindBuffer(uniformBuffer, uniform);
        }
    };
    struct StorageGuard {
        Impl& gl;
        GLint buffer = 0, indirect = 0, program = 0;
        struct Binding { GLint name = 0; std::int64_t start = 0, size = 0; };
        std::array<Binding, 8> bindings{};
        unsigned slots;
        explicit StorageGuard(Impl& api, unsigned slots = 8) : gl(api), slots(slots) {
            gl.GetIntegerv(0x90d3, &buffer);
            gl.GetIntegerv(0x90ef, &indirect);
            gl.GetIntegerv(0x8b8d, &program);
            for (GLuint i = 0; i < slots; ++i) {
                gl.GetIntegeri_v(0x90d3, i, &bindings[i].name);
                gl.GetInteger64i_v(0x90d4, i, &bindings[i].start);
                gl.GetInteger64i_v(0x90d5, i, &bindings[i].size);
            }
        }
        ~StorageGuard() {
            gl.UseProgram(program);
            for (GLuint i = 0; i < slots; ++i) {
                const auto& b = bindings[i];
                if (b.name && b.size > 0) gl.BindBufferRange(storageBuffer, i, b.name, b.start, b.size);
                else gl.BindBufferBase(storageBuffer, i, b.name);
            }
            gl.BindBuffer(storageBuffer, buffer);
            gl.BindBuffer(dispatchBuffer, indirect);
        }
    };
    GLuint shader(GLenum type, const char* source) {
        const auto id = CreateShader(type);
        ShaderSource(id, 1, &source, nullptr);
        CompileShader(id);
        GLint success = 0;
        GetShaderiv(id, 0x8b81, &success);
        if (!success) {
            char log[4096]{};
            GetShaderInfoLog(id, sizeof(log), nullptr, log);
            DeleteShader(id);
            throw std::runtime_error(std::string("V2 shader compilation failed ") + log);
        }
        return id;
    }
    void createProgram() {
        GLuint vertex = 0, fragment = 0;
        try {
            vertex = shader(0x8b31, vertexSource);
            fragment = shader(0x8b30, fragmentSource);
            program = CreateProgram();
            AttachShader(program, vertex);
            AttachShader(program, fragment);
            LinkProgram(program);
            GLint success = 0;
            GetProgramiv(program, 0x8b82, &success);
            if (!success) {
                char log[4096]{};
                GetProgramInfoLog(program, sizeof(log), nullptr, log);
                throw std::runtime_error(std::string("V2 program linking failed ") + log);
            }
            UniformBlockBinding(program, GetUniformBlockIndex(program, "Chains"), 0);
            mvpLocation = GetUniformLocation(program, "mvp");
            textureLocation = GetUniformLocation(program, "texture0");
        } catch (...) {
            if (vertex) DeleteShader(vertex);
            if (fragment) DeleteShader(fragment);
            throw;
        }
        DeleteShader(vertex);
        DeleteShader(fragment);
    }
    GLuint link(GLenum type, const char* source, const char* fragment = nullptr) {
        const auto primary = shader(type, source);
        GLuint secondary = 0, result = 0;
        try {
            if (fragment) secondary = shader(0x8b30, fragment);
            result = CreateProgram();
            AttachShader(result, primary);
            if (secondary) AttachShader(result, secondary);
            LinkProgram(result);
            GLint success = 0;
            GetProgramiv(result, 0x8b82, &success);
            if (!success) {
                char log[4096]{};
                GetProgramInfoLog(result, sizeof(log), nullptr, log);
                throw std::runtime_error(std::string("Resident shader link failed ") + log);
            }
        } catch (...) {
            if (result) DeleteProgram(result);
            if (secondary) DeleteShader(secondary);
            DeleteShader(primary);
            throw;
        }
        if (secondary) DeleteShader(secondary);
        DeleteShader(primary);
        return result;
    }
    ~Impl() {
        if (vao) DeleteVertexArrays(1, &vao);
        if (geometry) DeleteBuffers(1, &geometry);
        if (palette) DeleteBuffers(1, &palette);
        if (program) DeleteProgram(program);
        for (auto id : {residentProgram, gatherProgram, applyProgram}) if (id) DeleteProgram(id);
        DeleteBuffers(static_cast<GLsizei>(storage.size()), storage.data());
        if (sectionEvents) DeleteBuffers(1, &sectionEvents);
    }
};
GlRenderer::GlRenderer(Resolve resolve) : m_impl(std::make_unique<Impl>(resolve)) {
    m_impl->createProgram();
}
GlRenderer::~GlRenderer() = default;
void GlRenderer::attach(Scene& scene) {
    auto& gl = *m_impl;
    if (gl.residentProgram) throw std::logic_error("Resident renderer is bound to one scene");
    Impl::StateGuard preserve(gl);
    gl.generation = 0;
    GLint alignment = 0, maxBlock = 0;
    gl.GetIntegerv(0x8a34, &alignment);
    gl.GetIntegerv(0x8a30, &maxBlock);
    if (alignment <= 0 || maxBlock < pageBytes) throw std::runtime_error("V2 palette UBO unavailable");
    gl.stride = ((pageBytes + alignment - 1) / alignment) * alignment;
    if (!gl.geometry) gl.GenBuffers(1, &gl.geometry);
    if (!gl.palette) gl.GenBuffers(1, &gl.palette);
    if (!gl.vao) gl.GenVertexArrays(1, &gl.vao);
    gl.BindVertexArray(gl.vao);
    gl.BindBuffer(arrayBuffer, gl.geometry);
    const auto vertices = scene.geometry();
    gl.BufferData(arrayBuffer, vertices.size_bytes(), vertices.data(), 0x88e4);
    gl.EnableVertexAttribArray(0);
    gl.EnableVertexAttribArray(1);
    gl.EnableVertexAttribArray(2);
    gl.EnableVertexAttribArray(3);
    gl.VertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, x)));
    gl.VertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, u)));
    gl.VertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, color)));
    gl.VertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, chain)));
    // Bring the retained palette up to date even when this is a recovery attach.
    scene.updates();
    const auto palette = scene.palette();
    const auto pages = (palette.size() + paletteSize - 1) / paletteSize;
    std::vector<std::byte> initial(std::max<std::size_t>(pages, 1) * gl.stride);
    for (std::size_t id = 0; id < palette.size(); ++id)
        std::memcpy(initial.data() + (id / paletteSize) * gl.stride + (id % paletteSize) * sizeof(PaletteEntry),
            &palette[id], sizeof(PaletteEntry));
    gl.BindBuffer(uniformBuffer, gl.palette);
    gl.BufferData(uniformBuffer, initial.size(), initial.data(), 0x88e8);
    scene.draws();
    gl.check("V2 scene upload");
    scene.acknowledgeUpdates();
    gl.counters.initialUploadBytes += vertices.size_bytes() + initial.size();
    gl.generation = scene.generation();
}
void GlRenderer::attachResident(Scene& scene, std::span<const ResidentObject> objects, std::size_t groupCount) {
    auto& gl = *m_impl;
    if (!gl.DispatchCompute || !gl.DispatchComputeIndirect || !gl.MemoryBarrier ||
        !gl.Uniform1ui || !gl.VertexAttribIPointer || !gl.GetBufferSubData)
        throw std::runtime_error("Resident GL compute requires GL 4.3 with double precision");
    if (objects.size() != scene.objectCount() || objects.empty() || !groupCount ||
        objects.size() > workgroupWidth * 65535u || groupCount > UINT32_MAX)
        throw std::invalid_argument("Invalid resident scene dimensions");
    attach(scene);
    Impl::StateGuard preserve(gl);
    Impl::StorageGuard preserveStorage(gl);
    gl.residentProgram = gl.link(0x8b31, residentVertex, fragmentSource);
    gl.gatherProgram = gl.link(0x91b9, gatherSource);
    gl.applyProgram = gl.link(0x91b9, applySource);
    gl.residentMvp = gl.GetUniformLocation(gl.residentProgram, "mvp");
    gl.residentTexture = gl.GetUniformLocation(gl.residentProgram, "texture0");
    gl.gatherPhase = gl.GetUniformLocation(gl.gatherProgram, "gather");
    gl.gatherEpoch = gl.GetUniformLocation(gl.gatherProgram, "epoch");
    gl.gatherCount = gl.GetUniformLocation(gl.gatherProgram, "commandCount");
    gl.retireCount = gl.GetUniformLocation(gl.gatherProgram, "retireCount");
    gl.applyCount = gl.GetUniformLocation(gl.applyProgram, "commandCount");
    gl.applySectionX = gl.GetUniformLocation(gl.applyProgram, "sectionXBits");
    gl.applySectionY = gl.GetUniformLocation(gl.applyProgram, "sectionYBits");

    std::vector<ResidentGpuState> positions;
    std::vector<std::uint32_t> groupOffsets(groupCount + 1), objectOffsets, groups;
    positions.reserve(objects.size());
    objectOffsets.reserve(objects.size() + 1);
    gl.groupWidths.assign(groupCount, 0);
    gl.gatheredEpochs.assign(groupCount, 0);
    for (const auto& object : objects) {
        const auto [x, y] = object.base;
        positions.push_back({{x, y, x, y}, {object.rotationX, object.rotationY, object.rotationX, object.rotationY},
            object.sectionX, object.sectionY, object.canRotate ? 1u : 0u});
        objectOffsets.push_back(static_cast<std::uint32_t>(groups.size()));
        if (groups.size() + object.groups.size() > UINT32_MAX ||
            !std::is_sorted(object.groups.begin(), object.groups.end()) ||
            std::adjacent_find(object.groups.begin(), object.groups.end()) != object.groups.end())
            throw std::invalid_argument("Invalid resident object memberships");
        for (auto group : object.groups) {
            if (group >= groupCount) throw std::out_of_range("Unknown resident movement route");
            ++gl.groupWidths[group];
            groups.push_back(group);
        }
    }
    objectOffsets.push_back(static_cast<std::uint32_t>(groups.size()));
    for (std::size_t i = 0; i < groupCount; ++i) groupOffsets[i + 1] = groupOffsets[i] + gl.groupWidths[i];
    std::vector<std::uint32_t> members(groups.size()), next = groupOffsets;
    for (ObjectId i = 0; i < objects.size(); ++i)
        for (auto group : objects[i].groups) members[next[group]++] = i;

    gl.GenBuffers(static_cast<GLsizei>(gl.storage.size()), gl.storage.data());
    auto buffer = [&](unsigned slot, std::size_t bytes, const void* data) {
        gl.BindBuffer(storageBuffer, gl.storage[slot]);
        gl.BufferData(storageBuffer, std::max<std::size_t>(4, bytes), bytes ? data : nullptr, 0x88e8);
        gl.counters.initialUploadBytes += data ? bytes : 0;
    };
    buffer(0, positions.size() * sizeof(positions.front()), positions.data());
    buffer(1, groupOffsets.size() * sizeof(std::uint32_t), groupOffsets.data());
    buffer(2, members.size() * sizeof(std::uint32_t), members.data());
    buffer(3, objectOffsets.size() * sizeof(std::uint32_t), objectOffsets.data());
    buffer(4, groups.size() * sizeof(std::uint32_t), groups.data());
    std::vector<std::uint32_t> stamps(objects.size());
    buffer(6, stamps.size() * sizeof(std::uint32_t), stamps.data());
    buffer(7, (4 + objects.size()) * sizeof(std::uint32_t), nullptr);
    gl.BindVertexArray(gl.vao);
    gl.BindBuffer(arrayBuffer, gl.geometry);
    gl.EnableVertexAttribArray(4);
    gl.VertexAttribIPointer(4, 1, GL_UNSIGNED_INT, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, object)));
    gl.residentObjectCount = objects.size();
    gl.uploads.reserve(2 * maxCommands);
    gl.check("Resident topology upload");
}
void GlRenderer::dispatchResident(std::span<const gpu::ResidentTranslation> commands, std::span<const ObjectId> retired,
    std::vector<gpu::ResidentSectionEvent>* events, float sectionX, float sectionY) {
    auto& gl = *m_impl;
    if (!gl.residentProgram) throw std::logic_error("Attach resident storage before executing commands");
    if (commands.empty() && retired.empty()) return;
    // Absolute positions from scoped native writes. Upload a contiguous,
    // deduplicated batch instead of one GL call per edited object.
    constexpr std::uint32_t rebaseBit = 0x80000000u;
    if (!commands.empty() && (commands.front().group & rebaseBit)) {
        if (!retired.empty() || commands.size() > gl.residentObjectCount)
            throw std::length_error("Resident rebase capacity exceeded");
        for (const auto& command : commands)
            if (!(command.group & rebaseBit) || (command.group & ~rebaseBit) >= gl.residentObjectCount)
                throw std::out_of_range("Unknown resident rebase");
        const auto started = Clock::now();
        Impl::StorageGuard preserve(gl);
        for (GLuint i = 0; i < gl.storage.size(); ++i) gl.BindBufferBase(storageBuffer, i, gl.storage[i]);
        gl.BindBuffer(storageBuffer, gl.storage[5]);
        gl.UseProgram(gl.gatherProgram);
        gl.Uniform1i(gl.gatherPhase, 2);
        // GL guarantees at least 65535 workgroups per dimension.
        constexpr std::size_t maxRebases = 65535u * workgroupWidth;
        for (std::size_t first = 0; first < commands.size(); first += maxRebases) {
            const auto count = std::min(maxRebases, commands.size() - first);
            const auto bytes = count * sizeof(gpu::ResidentTranslation);
            gl.BufferData(storageBuffer, bytes, commands.data() + first, 0x88e0);
            gl.Uniform1ui(gl.gatherCount, static_cast<GLuint>(count));
            gl.DispatchCompute(static_cast<GLuint>((count + workgroupWidth - 1) / workgroupWidth), 1, 1);
            gl.MemoryBarrier(shaderBarrier | bufferUpdateBarrier);
            ++gl.counters.dispatches;
            ++gl.counters.residentSubmissions;
            gl.counters.uploadBytes += bytes;
            gl.counters.residentCommandBytes += bytes;
        }
        gl.counters.residentUploadMs += std::chrono::duration<double, std::milli>(Clock::now() - started).count();
        gl.check("Resident absolute rebase");
        return;
    }
    if (commands.size() > maxCommands || retired.size() > gl.residentObjectCount || gl.epoch >= UINT32_MAX - 1)
        throw std::length_error("Resident dispatch capacity exceeded");
    const auto started = Clock::now();
    Impl::StorageGuard preserve(gl);
    gl.uploads.assign(commands.begin(), commands.end());
    for (auto id : retired) {
        if (id >= gl.residentObjectCount) throw std::out_of_range("Unknown retired resident");
        gl.uploads.push_back({0, 0, id, 0});
    }
    unsigned width = 0, gatherGroups = 0;
    std::size_t eventCapacity = 0;
    const auto epoch = ++gl.epoch;
    for (const auto& command : commands) {
        if (command.flags & gpu::residentTrackSections) eventCapacity += gl.groupWidths.at(command.group);
        auto& gathered = gl.gatheredEpochs.at(command.group);
        if (gathered == epoch) continue;
        gathered = epoch;
        const auto members = gl.groupWidths[command.group];
        if (!members) continue;
        width = std::max(width, members);
        gl.uploads.push_back({0, 0, command.group, 0});
        ++gatherGroups;
    }
    if (eventCapacity && !events) throw std::logic_error("Missing resident section event consumer");
    for (GLuint i = 0; i < gl.storage.size(); ++i) gl.BindBufferBase(storageBuffer, i, gl.storage[i]);
    gl.BindBuffer(storageBuffer, gl.storage[5]);
    const auto bytes = gl.uploads.size() * sizeof(gpu::ResidentTranslation);
    gl.BufferData(storageBuffer, bytes, gl.uploads.data(), 0x88e0);
    gl.counters.uploadBytes += bytes;
    gl.counters.residentCommandBytes += bytes;
    gl.counters.residentUploadMs += std::chrono::duration<double, std::milli>(Clock::now() - started).count();
    const auto blocks = [](std::uint32_t n) { return (n + workgroupWidth - 1) / workgroupWidth; };
    gl.UseProgram(gl.gatherProgram);
    gl.Uniform1ui(gl.gatherEpoch, epoch);
    gl.Uniform1ui(gl.gatherCount, static_cast<GLuint>(commands.size()));
    gl.Uniform1ui(gl.retireCount, static_cast<GLuint>(retired.size()));
    gl.Uniform1i(gl.gatherPhase, 0);
    gl.DispatchCompute(std::max(1u, blocks(static_cast<GLuint>(retired.size()))), 1, 1);
    ++gl.counters.dispatches;
    ++gl.counters.residentSubmissions;
    gl.MemoryBarrier(shaderBarrier);
    if (width) {
        gl.Uniform1i(gl.gatherPhase, 1);
        gl.DispatchCompute(blocks(width), gatherGroups, 1);
        gl.MemoryBarrier(shaderBarrier | commandBarrier);
        gl.UseProgram(gl.applyProgram);
        gl.Uniform1ui(gl.applyCount, static_cast<GLuint>(commands.size()));
        if (eventCapacity) {
            if (!gl.sectionEvents) gl.GenBuffers(1, &gl.sectionEvents);
            gl.BindBuffer(storageBuffer, gl.sectionEvents);
            if (eventCapacity > gl.sectionCapacity) {
                gl.BufferData(storageBuffer, 16 + eventCapacity * sizeof(gpu::ResidentSectionEvent), nullptr, 0x88e8);
                gl.sectionCapacity = eventCapacity;
            }
            const std::uint32_t zero = 0;
            gl.BufferSubData(storageBuffer, 0, sizeof(zero), &zero);
            gl.BindBufferBase(storageBuffer, 1, gl.sectionEvents);
            gl.Uniform1ui(gl.applySectionX, std::bit_cast<std::uint32_t>(sectionX));
            gl.Uniform1ui(gl.applySectionY, std::bit_cast<std::uint32_t>(sectionY));
        }
        gl.BindBuffer(dispatchBuffer, gl.storage[7]);
        gl.DispatchComputeIndirect(0);
        gl.MemoryBarrier(shaderBarrier | bufferUpdateBarrier);
        if (eventCapacity) {
            std::uint32_t count = 0;
            gl.BindBuffer(storageBuffer, gl.sectionEvents);
            gl.GetBufferSubData(storageBuffer, 0, sizeof(count), &count);
            if (count > eventCapacity) throw std::runtime_error("Resident section event overflow");
            events->resize(count);
            if (count) gl.GetBufferSubData(storageBuffer, 16, count * sizeof(events->front()), events->data());
        }
        gl.counters.dispatches += 2;
    }
    gl.check("Resident ordered compute");
}
std::vector<Translation> GlRenderer::validateResidentPositions() {
    auto& gl = *m_impl;
    if (!gl.residentProgram) throw std::logic_error("No resident state to validate");
    std::vector<ResidentGpuState> readback(gl.residentObjectCount);
    Impl::StorageGuard preserve(gl, 0);
    gl.BindBuffer(storageBuffer, gl.storage[0]);
    const auto size = readback.size() * sizeof(readback.front());
    const auto start = Clock::now();
    gl.GetBufferSubData(storageBuffer, 0, size, readback.data());
    gl.counters.residentValidationWaitMs += std::chrono::duration<double, std::milli>(Clock::now() - start).count();
    gl.counters.residentValidationReadbackBytes += size;
    gl.check("Resident validation readback");
    std::vector<Translation> result;
    result.reserve(readback.size());
    for (const auto& state : readback) result.push_back({state.position[0], state.position[1]});
    return result;
}
void GlRenderer::updateResidentQuad(const Draw& draw, const std::array<Corner, 4>& quad, Translation origin,
    float rotationX, float rotationY) {
    auto& gl = *m_impl;
    if (!gl.residentProgram || draw.nativeObject >= gl.residentObjectCount || draw.vertexCount != 6)
        throw std::logic_error("Cannot refresh an invalid resident quad");
    Impl::StateGuard preserve(gl);
    Impl::StorageGuard preserveStorage(gl, 0);
    constexpr std::array<unsigned, 6> indices{0, 1, 2, 2, 1, 3};
    std::array<Vertex, 6> vertices;
    for (unsigned i = 0; i < vertices.size(); ++i) {
        const auto& corner = quad[indices[i]];
        vertices[i] = {corner.x, corner.y, corner.z, corner.u, corner.v, corner.color, 0, draw.nativeObject};
    }
    gl.BindBuffer(arrayBuffer, gl.geometry);
    gl.BufferSubData(arrayBuffer, draw.firstVertex * sizeof(Vertex), sizeof(vertices), vertices.data());
    const double base[]{origin.x, origin.y};
    gl.BindBuffer(storageBuffer, gl.storage[0]);
    const auto offset = sizeof(ResidentGpuState) * draw.nativeObject;
    gl.BufferSubData(storageBuffer, offset + 2 * sizeof(double), sizeof(base), base);
    const float angles[]{rotationX, rotationY};
    gl.BufferSubData(storageBuffer, offset + offsetof(ResidentGpuState, angles) + 2 * sizeof(float), sizeof(angles), angles);
    gl.counters.residentGeometryBytes += sizeof(vertices) + sizeof(base);
    gl.counters.uploadBytes += sizeof(vertices) + sizeof(base);
    gl.check("Resident quad refresh");
}
void GlRenderer::updateResidentSection(ObjectId object, int x, int y) {
    auto& gl = *m_impl;
    if (object >= gl.residentObjectCount) throw std::out_of_range("Unknown resident section");
    Impl::StorageGuard preserve(gl, 0);
    const std::int32_t section[]{x, y};
    gl.BindBuffer(storageBuffer, gl.storage[0]);
    gl.BufferSubData(storageBuffer, sizeof(ResidentGpuState) * object + offsetof(ResidentGpuState, sectionX),
        sizeof(section), section);
}
void GlRenderer::render(Scene& scene, const std::array<float, 16>& mvp, RenderSink& sink) {
    renderRanges(scene, scene.draws(), mvp, sink);
}
void GlRenderer::renderRanges(Scene& scene, std::span<const Draw> draws,
                             const std::array<float, 16>& mvp, RenderSink& sink) {
    auto& gl = *m_impl;
    Impl::StateGuard preserve(gl);
    std::optional<Impl::StorageGuard> preserveStorage;
    if (gl.generation != scene.generation()) throw std::logic_error("Attach the V2 scene before rendering");
    if (gl.residentProgram) preserveStorage.emplace(gl, 1);
    else {
        gl.BindBuffer(uniformBuffer, gl.palette);
        for (const auto& update : scene.updates()) {
            const auto offset = (update.chain / paletteSize) * gl.stride + (update.chain % paletteSize) * sizeof(PaletteEntry);
            gl.BufferSubData(uniformBuffer, offset, sizeof(PaletteEntry), &update.value);
            gl.counters.uploadBytes += sizeof(PaletteEntry);
            gl.counters.paletteUploadBytes += sizeof(PaletteEntry);
        }
        gl.check("V2 palette update");
        scene.acknowledgeUpdates();
    }
    for (const auto& draw : draws) {
        if (draw.path == ExecutionPath::nativeCpu) { sink.drawNative(draw.nativeObject); continue; }
        sink.bindMaterial(draw.material);
        // A native range can mutate GL state, so each shared range establishes
        // all state owned by this backend again at its original draw position.
        gl.UseProgram(gl.residentProgram ? gl.residentProgram : gl.program);
        gl.BindVertexArray(gl.vao);
        gl.UniformMatrix4fv(gl.residentProgram ? gl.residentMvp : gl.mvpLocation, 1, GL_FALSE, mvp.data());
        gl.Uniform1i(gl.residentProgram ? gl.residentTexture : gl.textureLocation, 0);
        gl.counters.drawUniformUploadBytes += sizeof(float) * 16 + sizeof(GLint);
        gl.counters.uploadBytes += sizeof(float) * 16 + sizeof(GLint);
        if (gl.residentProgram) gl.BindBufferBase(storageBuffer, 0, gl.storage[0]);
        else gl.BindBufferRange(uniformBuffer, 0, gl.palette, draw.page * gl.stride, pageBytes);
        if (draw.vertexCount > std::numeric_limits<GLsizei>::max()) throw std::length_error("V2 draw range too large");
        gl.DrawArrays(GL_TRIANGLES, draw.firstVertex, draw.vertexCount);
        ++gl.counters.drawCalls;
        if (gl.residentProgram && gl.epoch) ++gl.counters.residentMovedDrawCalls;
    }
    gl.check("V2 ordered rendering");
}
void GlRenderer::abandonContext() {
    auto& gl = *m_impl;
    // Resources belong to the lost context. Calling its deletion functions in
    // a replacement context could delete unrelated names owned by the host.
    gl.program = gl.geometry = gl.palette = gl.vao = 0;
    gl.residentProgram = gl.gatherProgram = gl.applyProgram = 0;
    gl.storage = {};
    gl.sectionEvents = 0;
    gl.generation = 0;
}
void GlRenderer::clearCounters() { m_impl->counters = {}; }
const RenderCounters& GlRenderer::counters() const { return m_impl->counters; }
}
