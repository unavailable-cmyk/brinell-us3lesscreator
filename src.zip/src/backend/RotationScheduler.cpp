#include "RotationScheduler.hpp"
#include "HybridTransformExecutor.hpp"
#include "TransformStateParity.hpp"
#include "TransformCulling.hpp"
#include "StableTransitionSort.hpp"
#include "AdaptiveCulling.hpp"
#include "HybridTransformPipeline.hpp"
#include "core/RendererManager.hpp"
#include <Geode/Geode.hpp>
#include <Geode/binding/GJBaseGameLayer.hpp>
#include <Geode/binding/GJEffectManager.hpp>
#include <Geode/binding/GroupCommandObject2.hpp>
#include <Geode/binding/GameObject.hpp>
#include <Geode/binding/LocalLevelManager.hpp>
#include <Geode/binding/GJGameLevel.hpp>
#include <Geode/binding/PlayLayer.hpp>
#include <Geode/binding/PlayerObject.hpp>
#include <Geode/binding/OBB2D.hpp>
#include <Geode/binding/EffectGameObject.hpp>
#include <Geode/binding/SpawnTriggerGameObject.hpp>
#include <Geode/binding/ColorActionSprite.hpp>
#include <Geode/binding/DynamicMoveCalculation.hpp>
#include <Geode/binding/FMODAudioEngine.hpp>
#include "diagnostics/GameplaySpeedWindow.hpp"
#include <windows.h>
#include <GL/gl.h>
#include <cstdlib>
#include <algorithm>
#include <array>
#include <bit>
#include <chrono>
#include <cstring>
#include <tuple>
#include <vector>
#include <unordered_map>
#include <unordered_set>
#include <memory>
#include <cmath>
#include <map>
#include <optional>
#include <fstream>
#include <emmintrin.h>

using namespace geode::prelude;
namespace vulkanizer {
namespace {
using Clock = std::chrono::steady_clock;
static_assert(offsetof(GJEffectManager, m_unkVector5b0) == 0x668);
static_assert(offsetof(GJEffectManager, m_unkMap5c8) == 0x680);
static_assert(offsetof(GroupCommandObject2, m_targetGroupID) == 0x28);
static_assert(offsetof(GroupCommandObject2, m_centerGroupID) == 0x2c);
static_assert(offsetof(GroupCommandObject2, m_finishRelated) == 0x72);
static_assert(offsetof(GroupCommandObject2, m_lockObjectRotation) == 0xb8);
static_assert(offsetof(GroupCommandObject2, m_someInterpValue1RelatedFalse) == 0x1a8);
static_assert(offsetof(GroupCommandObject2, m_stepStamp) == 0x204);
static_assert(offsetof(GJBaseGameLayer, m_parentGroupsDict) == 0xf80);
static_assert(offsetof(GameObject, m_positionY) == offsetof(GameObject, m_positionX) + sizeof(double));
static_assert(offsetof(GameObject, m_positionYOffset) == offsetof(GameObject, m_positionXOffset) + sizeof(float));

enum class Mode { live, nativeProof, cpuProof, gpuProof, batchProof, streamProof, cullingProof };
Mode mode = Mode::live;
int verified = 0;
bool runtimeFailed = false, liveGpuApplied = false;
std::uint64_t liveEntries = 0, liveObjects = 0, liveGpuObjects = 0, livePositionObjects = 0;
double liveMs = 0;
double sampleGpuWaitMs = 0, sampleGpuTransferMs = 0;
bool gameplayTest = false;
std::uint64_t gameplayPhysicsSteps = 0;
bool nativeGameplayBaseline() {
    static const bool requested = std::getenv("VULKANIZER_TRANSFORM_VANILLA_BASELINE") != nullptr;
    return requested;
}
Clock::time_point gameplayTestStart;
double gameplayTestDurationMs = 2000;
unsigned nativeProbeEntries = 0;
bool nativeProbeRecursed = false;
std::uint64_t proofExecutions = 0;
std::uint64_t proofGpuBatches = 0;

double ms(Clock::time_point start) {
    return std::chrono::duration<double, std::milli>(Clock::now() - start).count();
}
template<class T> T readAction(GroupCommandObject2* action, std::size_t offset) {
    T result;
    std::memcpy(&result, reinterpret_cast<unsigned char*>(action) + offset, sizeof(T));
    return result;
}
template<class T> void writeAction(GroupCommandObject2* action, std::size_t offset, T value) {
    std::memcpy(reinterpret_cast<unsigned char*>(action) + offset, &value, sizeof(T));
}

// The inlined scheduler uses double subtraction before narrowing, the double
// intermediates of PointApplyAffineTransform, and double delta accumulation.
// This deliberately differs from the standalone rotateObjects helper.
struct RotationKernel {
    __m128d ab, cd, translation, center;
    __m128 move;
    RotationKernel(CCPoint pivot, CCPoint offset, CCAffineTransform const& matrix)
      : ab(_mm_set_pd(matrix.b, matrix.a)), cd(_mm_set_pd(matrix.d, matrix.c)),
        translation(_mm_set_pd(matrix.ty, matrix.tx)), center(_mm_set_pd(pivot.y, pivot.x)),
        move(_mm_set_ps(0.f, 0.f, offset.y, offset.x)) {}
    __forceinline gpu::ObjectState position(GameObject* object) const {
        const __m128d original = _mm_loadu_pd(&object->m_positionX);
        const __m128 offsetsFloat = _mm_castsi128_ps(_mm_loadl_epi64(
            reinterpret_cast<__m128i const*>(&object->m_positionXOffset)));
        const __m128d offsets = _mm_cvtps_pd(offsetsFloat);
        return position(original, offsets);
    }
    __forceinline gpu::ObjectState position(__m128d original, __m128d offsets) const {
        const __m128 relativeFloat = _mm_cvtpd_ps(_mm_sub_pd(_mm_sub_pd(original, offsets), center));
        const __m128d relative = _mm_cvtps_pd(relativeFloat);
        const __m128d xa = _mm_mul_pd(_mm_unpacklo_pd(relative, relative), ab);
        const __m128d yc = _mm_mul_pd(_mm_unpackhi_pd(relative, relative), cd);
        const __m128 point = _mm_cvtpd_ps(_mm_add_pd(_mm_add_pd(yc, xa), translation));
        const __m128 moved = _mm_add_ps(point, move);
        const __m128d delta = _mm_add_pd(_mm_sub_pd(_mm_cvtps_pd(moved), original), offsets);
        gpu::ObjectState result{};
        _mm_storeu_pd(&result.x, _mm_add_pd(original, delta));
        return result;
    }
};

struct DeferredRotation {
    CCArray* members;
    RotationKernel kernel;
    float orientation;
    bool finished;
};

struct GroupSnapshot {
    Ref<CCArray> array;
    std::vector<GameObject*> members;
};

struct RotationPlan {
    std::vector<GroupSnapshot> groups;
    std::vector<GameObject*> objects;
    std::vector<gpu::Span> spans;
    std::vector<std::uint32_t> indices;
    std::vector<std::uint32_t> lastAction;
    std::vector<std::vector<std::uint32_t>> originalOrder;
};

struct BatchCounters {
    std::uint64_t referenceVisits = 0, objectLoads = 0, positionWrites = 0;
    std::uint64_t sectionCalls = 0, sectionCallsAvoided = 0, orientationWrites = 0;
    std::uint64_t cacheHits = 0, cacheMisses = 0, barriers = 0, batches = 0;
    double elapsedMs = 0;
};
BatchCounters batchCounters;
GJBaseGameLayer* planOwner = nullptr;
std::vector<std::unique_ptr<RotationPlan>> plans;
bool pipelineEnabled() {
    static const bool enabled = std::getenv("VULKANIZER_TRANSFORM_LOCAL_BATCHING") != nullptr;
    return mode == Mode::batchProof || (mode == Mode::live && enabled);
}

bool batchObjectSupported(GJBaseGameLayer* layer, GameObject* object) {
    return object && object != layer->m_player1 && object != layer->m_player2 &&
        (object->m_objectType == GameObjectType::Solid || object->m_objectType == GameObjectType::Decoration) &&
        (object->m_classType == GameObjectClassType::Game || object->m_classType == GameObjectClassType::Enhanced) &&
        !object->m_isTrigger && !object->m_isStartPos && !object->m_hasGroupParent &&
        !object->m_hasAreaParent && object->m_parentMode <= 0 && !object->m_linkedGroup;
}

bool groupSupported(GJBaseGameLayer* layer, CCArray* group) {
    for (auto* object : CCArrayExt<GameObject, false>(group))
        if (!batchObjectSupported(layer, object)) return false;
    return true;
}

bool planMatches(RotationPlan const& plan, std::vector<DeferredRotation> const& actions) {
    if (plan.groups.size() != actions.size()) return false;
    for (std::size_t i = 0; i < actions.size(); ++i) {
        auto* array = actions[i].members;
        auto const& snapshot = plan.groups[i];
        if (snapshot.array.data() != array || snapshot.members.size() != array->count() ||
            std::memcmp(snapshot.members.data(), array->data->arr, snapshot.members.size() * sizeof(GameObject*)) != 0)
            return false;
    }
    return true;
}

RotationPlan& getPlan(GJBaseGameLayer* layer, std::vector<DeferredRotation> const& actions) {
    if (planOwner != layer) { plans.clear(); planOwner = layer; }
    for (auto& plan : plans) {
        if (planMatches(*plan, actions)) { ++batchCounters.cacheHits; return *plan; }
    }
    ++batchCounters.cacheMisses;
    auto plan = std::make_unique<RotationPlan>();
    std::unordered_map<GameObject*, std::uint32_t> objectIndices;
    std::vector<std::uint32_t> counts;
    for (std::uint32_t actionIndex = 0; actionIndex < actions.size(); ++actionIndex) {
        GroupSnapshot group{actions[actionIndex].members, {}};
        std::vector<std::uint32_t> order;
        for (auto* object : CCArrayExt<GameObject, false>(group.array)) {
            group.members.push_back(object);
            auto [entry, inserted] = objectIndices.try_emplace(object, static_cast<std::uint32_t>(plan->objects.size()));
            const auto index = entry->second;
            if (inserted) {
                plan->objects.push_back(object); counts.push_back(0);
                plan->lastAction.push_back(actionIndex);
            }
            ++counts[index]; plan->lastAction[index] = actionIndex;
            order.push_back(index);
        }
        plan->groups.push_back(std::move(group)); plan->originalOrder.push_back(std::move(order));
    }
    std::uint32_t offset = 0;
    for (auto count : counts) { plan->spans.push_back({offset, count}); offset += count; }
    plan->indices.resize(offset);
    std::vector<std::uint32_t> cursors(plan->objects.size(), 0);
    for (std::uint32_t actionIndex = 0; actionIndex < actions.size(); ++actionIndex)
        for (auto objectIndex : plan->originalOrder[actionIndex])
            plan->indices[plan->spans[objectIndex].offset + cursors[objectIndex]++] = actionIndex;
    // Bound retained group/object ownership across changing action topologies.
    if (plans.size() >= 8) plans.erase(plans.begin());
    plans.push_back(std::move(plan));
    return *plans.back();
}

struct DeferredState {
    double x, y;
    float offsetX, offsetY, rotationX, rotationY, rotationOffsetX, rotationOffsetY;
    bool fallback = false, rotated = false;
};
static_assert(offsetof(GameObject, m_outerSectionIndex) == 0x278);
static_assert(offsetof(GameObject, m_middleSectionIndex) == 0x27c);
static_assert(offsetof(GJBaseGameLayer, m_sectionXFactor) == 0x37a0);
static_assert(offsetof(GJBaseGameLayer, m_sectionYFactor) == 0x37a4);

bool sameSection(GJBaseGameLayer* layer, GameObject* object, double x, double y) {
    if (object->m_outerSectionIndex < 0) return true;
    // Larger/non-finite coordinates retain the native clamp and conversion path.
    if (!std::isfinite(x) || !std::isfinite(y) || x > 1'000'000.0 || y > 1'000'000.0) return false;
    const int sectionX = x <= 0 ? 0 : static_cast<int>(static_cast<double>(layer->m_sectionXFactor) * x);
    const int sectionY = y <= 0 ? 0 : static_cast<int>(static_cast<double>(layer->m_sectionYFactor) * y);
    return sectionX == object->m_outerSectionIndex && sectionY == object->m_middleSectionIndex;
}

void applySchedulerOrientation(GameObject* object, float orientation) {
    // The native inlined scheduler (0x334ade..0x334b43) is stricter than
    // the SDK's fastRotateObject inline: it invalidates both collision caches
    // even when an oriented box already exists. Never leave a rotated solid
    // with an apparently clean old bounding box.
    object->m_rotationXOffset += orientation;
    object->m_rotationYOffset += orientation;
    object->addRotation(orientation);
    if (object->m_objectType != GameObjectType::Decoration) {
        object->dirtifyObjectRect();
        if (!object->m_shouldUseOuterOb) object->calculateOrientedBox();
    }
}

void applyPrimitive(GJBaseGameLayer* layer, GameObject* object, DeferredRotation const& action) {
    object->m_unk4fb = action.finished;
    preserveTransformHistory(*object, layer->m_gameState.m_commandIndex);
    object->m_isDirty = true; object->m_isUnmodifiedPosDirty = true;
    const auto result = action.kernel.position(object);
    object->m_positionX = result.x; object->m_positionY = result.y;
    if (action.orientation != 0.f && object->m_canRotateFree) applySchedulerOrientation(object, action.orientation);
    layer->updateObjectSection(object);
}

void flushRotations(GJBaseGameLayer* layer, std::vector<DeferredRotation>& actions) {
    if (actions.empty()) return;
    const auto started = Clock::now();
    auto& plan = getPlan(layer, actions);
    std::vector<DeferredState> states;
    states.reserve(plan.objects.size());
    for (std::size_t i = 0; i < plan.objects.size(); ++i) {
        auto* object = plan.objects[i];
        DeferredState state{object->m_positionX, object->m_positionY, object->m_positionXOffset,
            object->m_positionYOffset, object->getRotationX(), object->getRotationY(),
            object->m_rotationXOffset, object->m_rotationYOffset};
        state.fallback = !batchObjectSupported(layer, object) ||
            (object->m_objectType != GameObjectType::Decoration && !object->m_shouldUseOuterOb && object->m_canRotateFree);
        const auto span = plan.spans[i];
        for (std::uint32_t entry = 0; entry < span.count && !state.fallback; ++entry) {
            const auto& action = actions[plan.indices[span.offset + entry]];
            const auto result = action.kernel.position(_mm_set_pd(state.y, state.x),
                                                       _mm_set_pd(state.offsetY, state.offsetX));
            state.x = result.x; state.y = result.y;
            if (!sameSection(layer, object, state.x, state.y)) { state.fallback = true; break; }
            if (action.orientation != 0.f && object->m_canRotateFree) {
                state.rotationX += action.orientation; state.rotationY += action.orientation;
                state.rotationOffsetX += action.orientation; state.rotationOffsetY += action.orientation;
                state.rotated = true;
            }
        }
        states.push_back(state);
    }
    batchCounters.referenceVisits += plan.indices.size();
    batchCounters.objectLoads += plan.objects.size();
    ++batchCounters.batches;
    bool anyFallback = false;
    for (std::size_t i = 0; i < plan.objects.size(); ++i) {
        auto* object = plan.objects[i];
        const auto& state = states[i];
        if (state.fallback) { anyFallback = true; continue; }
        // One authoritative write, regardless of the number of overlapping groups.
        object->m_unk4fb = actions[plan.lastAction[i]].finished;
        preserveTransformHistory(*object, layer->m_gameState.m_commandIndex);
        object->m_isDirty = true; object->m_isUnmodifiedPosDirty = true;
        object->m_positionX = state.x; object->m_positionY = state.y;
        if (state.rotated) {
            object->m_rotationXOffset = state.rotationOffsetX;
            object->m_rotationYOffset = state.rotationOffsetY;
            object->setRotationX(state.rotationX); object->setRotationY(state.rotationY);
            if (object->m_objectType != GameObjectType::Decoration) object->dirtifyObjectRect();
            ++batchCounters.orientationWrites;
        }
        ++batchCounters.positionWrites;
        batchCounters.sectionCallsAvoided += plan.spans[i].count;
    }
    // Side-effectful section changes and collision-box initialization keep
    // their action-major order and intermediate states. Safe objects require
    // no second traversal through all of their action entries.
    for (std::size_t actionIndex = 0; actionIndex < actions.size(); ++actionIndex) {
        auto const& action = actions[actionIndex];
        if (anyFallback) {
            for (auto objectIndex : plan.originalOrder[actionIndex]) {
                if (!states[objectIndex].fallback) continue;
                applyPrimitive(layer, plan.objects[objectIndex], action);
                ++batchCounters.positionWrites; ++batchCounters.sectionCalls;
            }
        }
        layer->updateDisabledObjectsLastPos(action.members);
    }
    batchCounters.elapsedMs += ms(started);
    actions.clear();
}

// A visual tape contains operations, not per-object copies of each operation.
// Membership combinations share one ordered tape and one GPU submission.
struct VisualGroup {
    unsigned group575Members = 0;
    std::map<std::string, std::uint64_t> rejectionCounts;
    Ref<CCArray> source;
    Ref<CCArray> cpu;
    std::vector<GameObject*> snapshot;
    std::vector<std::uint32_t> visualObjects;
    std::vector<std::uint32_t> tape;
    std::unordered_map<std::uint32_t, std::uint32_t> order;
};
struct VisualCombination {
    std::vector<std::uint32_t> groups, objects;
    struct Cohort {
        std::vector<std::uint32_t> objects;
        TransformBounds bounds, swept;
        double minOffsetX = 0, maxOffsetX = 0, minOffsetY = 0, maxOffsetY = 0, radius = 0;
        std::uint32_t cursor = 0, boundsCursor = 0, deferredSince = 0, stagger = 0;
        bool eligible = true;
    };
    std::vector<Cohort> cohorts;
    std::vector<std::pair<std::uint32_t, gpu::Span>> tapeScratch;
    bool cohortsDirty = true;
};
struct VectorHash {
    std::size_t operator()(std::vector<std::uint32_t> const& values) const {
        std::size_t result = 0;
        for (auto value : values) result = (result * 16777619u) ^ value;
        return result;
    }
};
struct SectionTransition {
    std::uint32_t action, order, object;
    gpu::SectionEvent event;
    bool replay;
};
struct CohortSelection { VisualCombination::Cohort* cohort; std::size_t first, count; bool checkBounds; };
struct VisualStream {
    GJBaseGameLayer* owner = nullptr;
    bool audited = false, allowed = false, topologyDirty = true, checking = false, failed = false;
    std::unordered_set<int> protectedGroups;
    std::map<int,std::uint32_t> protectedCauses;
    std::unordered_set<int> anchorGroups;
    std::unordered_set<GameObject*> anchors;
    std::unordered_map<CCArray*, std::uint32_t> groupIndices;
    std::unordered_map<GameObject*, std::uint32_t> objectIndices;
    std::vector<VisualGroup> groups;
    std::vector<GameObject*> objects;
    std::vector<unsigned char> group575Objects;
    std::vector<Ref<GameObject>> objectReferences;
    std::vector<VisualCombination> combinations;
    std::unordered_map<std::vector<std::uint32_t>, std::uint32_t, VectorHash> combinationIndices;
    std::vector<std::vector<std::uint32_t>> memberships;
    std::vector<std::uint32_t> objectCombinations, objectSlots, dirtyObjects;
    std::vector<std::uint32_t> objectCursors;
    std::vector<gpu::Action> actions;
    std::vector<std::uint32_t> actionGroups;
    std::vector<gpu::ObjectState> states, initial;
    std::vector<gpu::Span> spans;
    std::vector<std::uint32_t> indices, objectIds;
    std::vector<SectionTransition> transitions, transitionScratch;
    std::vector<CohortSelection> selections;
    std::uint64_t logicalVisits = 0, stateWrites = 0, gpuBatches = 0, replayedVisits = 0;
    std::uint64_t moveVisits = 0, rotationVisits = 0, cpuMoveVisits = 0, cpuRotationVisits = 0;
    std::uint64_t topologyBuilds = 0, reusedGroups = 0, sectionEvents = 0;
    std::uint64_t singleTapeSortsAvoided = 0, activeChains = 0, dormantChains = 0, chainObjects = 0, maxChainObjects = 0;
    std::uint64_t censusTranslationCalls = 0, censusAffineCalls = 0;
    double censusDispatchMs = 0, censusUploadMs = 0;
    std::uint64_t cpuMoveFallbackVisits=0, cpuMoveMixedVisits=0, cpuRotationNoCenterVisits=0, cpuRotationBodyVisits=0, legacyGpuSampleVisits=0;
    std::uint64_t censusStageCycles=0, censusFenceCycles=0;
    double censusQpcStageMs=0, censusGpuMs=0;
    std::uint64_t group575MoveVisits=0, group575RotationVisits=0, group575StateWrites=0, group575UnrelatedBarriersAvoided=0;
    unsigned group575ParityBatches=0;
    bool cullingInitialized = false, cullingFailed = false;
    AdaptiveCulling adaptive;
    bool switchingCulling = false;
    std::uint32_t cullingFrame = 0;
    std::uint32_t lastCullingLogFrame = UINT32_MAX;
    std::uint64_t culledInputs = 0, deferredOperations = 0, visibilityResolutions = 0, budgetResolutions = 0, boundChecks = 0;
    TransformBounds previousViewport;
    double packMs = 0, waitMs = 0, readbackMs = 0, applyMs = 0, totalMs = 0;
    std::uint64_t diagGroups = 0, diagCacheHits = 0, diagObjects = 0, diagDecor = 0, diagSolid = 0;
    std::uint64_t diagLockedSolid = 0, diagRotatableSolid = 0, diagOther = 0, diagSectionSamples = 0;
    double diagGroupMs = 0, diagSectionMs = 0, diagBoundsMs = 0, diagGpuApplyMs = 0, diagTransitionMs = 0;
};
VisualStream visual;
std::map<std::pair<std::uintptr_t,std::string>, std::pair<std::uint64_t,std::uint64_t>> moveFallbackAttribution;
thread_local unsigned nativeMoveAttributionDepth=0;
std::map<CCArray*,std::pair<int,int>> nativeMoveArrays;
std::uintptr_t nativeMoveCaller(GJBaseGameLayer* layer, CCArray* objects, int& groupId) {
    static_assert(offsetof(GJBaseGameLayer,m_staticGroups)==0xf50);
    static_assert(offsetof(GJBaseGameLayer,m_optimizedGroups)==0xf68);
    if(nativeMoveAttributionDepth){
        auto found=nativeMoveArrays.find(objects);
        if(found==nativeMoveArrays.end()) {
            int domain=0;groupId=-1;
            for(std::size_t i=0;i<layer->m_staticGroups.size();++i)if(layer->m_staticGroups[i]==objects){domain|=1;groupId=static_cast<int>(i);}
            for(std::size_t i=0;i<layer->m_optimizedGroups.size();++i)if(layer->m_optimizedGroups[i]==objects){domain|=2;groupId=static_cast<int>(i);}
            found=nativeMoveArrays.emplace(objects,std::make_pair(domain,groupId)).first;
        }
        groupId=found->second.second;
        // Native processMoveActions has two calls to moveObjects, selected
        // by these distinct array domains. Ambiguous aliases stay unresolved.
        if(found->second.first==1)return 0x33645a;
        if(found->second.first==2)return 0x3364ef;
    }
    void* frames[32]{};
    const auto count=CaptureStackBackTrace(0,32,frames,nullptr);
    const auto base=reinterpret_cast<std::uintptr_t>(GetModuleHandleW(nullptr));
    auto* dos=reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    auto* nt=reinterpret_cast<IMAGE_NT_HEADERS*>(base+dos->e_lfanew);
    for(unsigned i=0;i<count;++i){auto address=reinterpret_cast<std::uintptr_t>(frames[i]);
        if(address>=base && address-base<nt->OptionalHeader.SizeOfImage)return address-base;}
    return 0;
}
void logMoveFallbackAttribution() {
    std::uint64_t total=0;
    for(auto const& [key,value]:moveFallbackAttribution){
        total+=value.second;
        log::info("VULKANIZER_MOVE_FALLBACK caller_rva=0x{:x} reason={} calls={} nominations={}",key.first,key.second,value.first,value.second);
    }
    log::info("VULKANIZER_MOVE_FALLBACK_TOTAL attributed={} original_counter={} reconciled={}",total,visual.cpuMoveFallbackVisits,total==visual.cpuMoveFallbackVisits);
}
bool precompilingVisual = false;
bool group575MovementRequested(){static const bool requested=Mod::get()->getSettingValue<bool>("experimental-group575-movement")&&!Mod::get()->getSettingValue<bool>("experimental-transform-culling")&&!std::getenv("VULKANIZER_TRANSFORM_CULLING");return mode==Mode::live && requested;}
bool belongsTo575(GameObject* object){if(!object||!object->m_groups)return false;for(short i=0;i<object->m_groupCount;++i)if((*object->m_groups)[i]==575)return true;return false;}
bool transformCostDiagnostics() {
    static const bool enabled = Mod::get()->getSettingValue<bool>("transform-cost-diagnostics");
    return enabled && mode == Mode::live;
}
void flushVisualStream(bool force = true);
std::optional<TransformBounds> cullingProofViewport;

bool cullingRequested() {
    static const bool requested = Mod::get()->getSettingValue<bool>("experimental-transform-culling") ||
        std::getenv("VULKANIZER_TRANSFORM_CULLING") != nullptr;
    return mode == Mode::cullingProof || (mode == Mode::live && requested);
}

bool streamRequested() {
    static const bool baseline = std::getenv("VULKANIZER_TRANSFORM_BATCHING_BASELINE") != nullptr;
    return mode == Mode::streamProof || mode == Mode::cullingProof || (mode == Mode::live && !baseline && liveGpuApplied &&
        RendererManager::get().gpuTransformAllRequested() && RendererManager::get().gpuTransformReady());
}

void auditVisualDependencies(GJBaseGameLayer* layer) {
    if (visual.owner != layer) { visual = {}; visual.owner = layer; moveFallbackAttribution.clear(); nativeMoveArrays.clear(); }
    if (visual.audited) return;
    visual.audited = true;
    if (mode == Mode::streamProof || mode == Mode::cullingProof) { visual.allowed = true; return; }
    if ((!precompilingVisual && PlayLayer::get() != layer) || !layer->m_objects || !layer->m_effectManager) return;
    visual.allowed = true;
    std::unordered_map<int, unsigned> unsupported;
    auto protect = [](int group, std::uint32_t cause=1) { if (group > 0 && group < 10000) {visual.protectedGroups.insert(group);visual.protectedCauses[group]|=cause;} };
    auto anchor = [](int group) { if (group > 0 && group < 10000) visual.anchorGroups.insert(group); };
    for (auto* object : CCArrayExt<GameObject, false>(layer->m_objects)) {
        if (!object || !object->m_isTrigger) continue;
        if (object->m_isStartPos || object->m_objectID == 31) continue;
        auto* effect = typeinfo_cast<EffectGameObject*>(object);
        if (!effect) { visual.allowed = false; ++unsupported[object->m_objectID]; continue; }
        if (auto* spawn = typeinfo_cast<SpawnTriggerGameObject*>(object);
            spawn && (!spawn->m_remapObjects.empty() || !spawn->m_remapKeys.empty())) {
            visual.allowed = false; ++unsupported[object->m_objectID];
        }
        anchor(effect->m_centerGroupID); anchor(effect->m_rotationTargetID); anchor(effect->m_targetModCenterID);
        // These vanilla trigger families operate on resolved action parameters,
        // colors, opacity, activation, or spawning. Position-dependent families
        // require a separate dependency implementation before visual deferral.
        switch (object->m_objectID) {
            case 29: case 30: case 105: case 744: case 899:
            case 1006: case 1007: case 1049: case 1268: case 1616:
            case 1520: case 1612: case 1613: case 1812: case 1814: case 1818: case 1819:
                break;
            case 901: case 1346:
                if (effect->m_useMoveTarget || effect->m_isDynamicMode || effect->m_specialTarget ||
                    effect->m_targetPlayer1 || effect->m_targetPlayer2 || effect->m_lockToPlayerX ||
                    effect->m_lockToPlayerY || effect->m_lockToCameraX || effect->m_lockToCameraY)
                {
                    const std::uint32_t cause=(effect->m_useMoveTarget?2:0)|(effect->m_isDynamicMode?4:0)|(effect->m_specialTarget?8:0)|
                        (effect->m_targetPlayer1?16:0)|(effect->m_targetPlayer2?32:0)|(effect->m_lockToPlayerX?64:0)|
                        (effect->m_lockToPlayerY?128:0)|(effect->m_lockToCameraX?256:0)|(effect->m_lockToCameraY?512:0);
                    protect(effect->m_targetGroupID,cause); protect(effect->m_centerGroupID,cause);
                    protect(effect->m_rotationTargetID,cause); protect(effect->m_targetModCenterID,cause);
                }
                break;
            default:
                visual.allowed = false; ++unsupported[object->m_objectID];
                break;
        }
    }
    for (auto const& [group, targets] : layer->m_targetGroups) {
        protect(group); protect(targets.first); protect(targets.second);
    }
    if(group575MovementRequested() && visual.allowed && visual.protectedCauses[575]==64u){
        // Only the resolved lock delta is consumed here. Keep every other
        // protection, explicit pivot and runtime calculation anchor below.
        visual.protectedGroups.erase(575);
        log::info("VULKANIZER_GROUP575 mode=ordered_gpu native_lock_calculation=retained exception_group=575 cause_bits=64 actual_cpu_consumers=protected");
    }
    for (auto group : visual.protectedGroups) {
        if (!layer->m_groups[group]) continue;
        for (auto* object : CCArrayExt<GameObject, false>(layer->m_groups[group])) visual.anchors.insert(object);
    }
    for (auto group : visual.anchorGroups)
        if (auto* object = layer->tryGetMainObject(group)) visual.anchors.insert(object);
    for (auto const& calculation : layer->m_effectManager->m_unkVector708)
        if (calculation.m_gameObject) visual.anchors.insert(calculation.m_gameObject);
    std::string rejected;
    for (auto const& [id, count] : unsupported) rejected += fmt::format("{}({}) ", id, count);
    log::info("VULKANIZER_VISUAL_AUDIT allowed={} protected_groups={} anchor_groups={} anchor_objects={} unsupported_trigger_ids={}",
        visual.allowed, visual.protectedGroups.size(), visual.anchorGroups.size(), visual.anchors.size(), rejected.empty() ? "none" : rejected);
    if(transformCostDiagnostics())for(auto const& [group,cause]:visual.protectedCauses)
        log::info("VULKANIZER_MOVE_PROTECTION group={} cause_bits={}",group,cause);
}

std::string_view visualObjectRejection(GameObject* object) {
    if(!object)return "null_member";
    if(object->m_objectType!=GameObjectType::Decoration)return "non_decoration_type";
    if(object->m_classType!=GameObjectClassType::Game)return "unsupported_object_class";
    if(object->m_isTrigger)return "trigger_object";
    if(object->m_isStartPos)return "startpos_object";
    if(object->m_hasGroupParent)return "group_parent";
    if(object->m_hasAreaParent)return "area_parent";
    if(object->m_parentMode>0)return "parent_mode";
    if(object->m_linkedGroup)return "linked_group";
    if(object->m_particle||object->m_hasParticles)return "particle_dependency";
    if(object->m_hasAnimatedChild)return "animated_child";
    if(object->m_isUIObject)return "ui_object";
    if (object->m_groups) {
        for (short i = 0; i < object->m_groupCount; ++i)
            if (visual.protectedGroups.contains((*object->m_groups)[i])) return "protected_target_group";
    }
    if (visual.anchors.contains(object)) return "authoritative_anchor";
    return {};
}
bool visualObjectSupported(GameObject* object) { return visualObjectRejection(object).empty(); }
std::string rejectionCounterKey(GameObject* object,std::string_view reason){
    if(reason=="protected_target_group" && object->m_groups)
        for(short i=0;i<object->m_groupCount;++i){int id=(*object->m_groups)[i];
            if(visual.protectedGroups.contains(id))return fmt::format("protected_target_group_consumer_{}_flags_{}",id,visual.protectedCauses[id]);}
    return std::string(reason);
}

VisualGroup* visualGroup(GJBaseGameLayer* layer, CCArray* array) {
    if ((!precompilingVisual && !streamRequested()) || !array || layer->m_loadingStartPosition || layer->m_gameState.m_commandIndex >= 16'777'216u) return nullptr;
    auditVisualDependencies(layer);
    if (!visual.allowed || visual.failed) return nullptr;
    const bool sampleGroup = transformCostDiagnostics() && (++visual.diagGroups % 128 == 0);
    const auto groupStart = sampleGroup ? Clock::now() : Clock::time_point{};
    struct GroupTimer { bool active; Clock::time_point start; ~GroupTimer() { if (active) visual.diagGroupMs += ms(start); } } groupTimer{sampleGroup, groupStart};
    if (auto found = visual.groupIndices.find(array); found != visual.groupIndices.end()) {
        const auto previousGroup = found->second;
        auto& group = visual.groups[previousGroup];
        if (group.snapshot.size() == array->count() &&
            std::memcmp(group.snapshot.data(), array->data->arr, group.snapshot.size() * sizeof(GameObject*)) == 0) {
            ++visual.reusedGroups; if (sampleGroup) ++visual.diagCacheHits; return &group;
        }
        flushVisualStream();
        visual.groupIndices.erase(found);
        for (auto object : group.visualObjects) {
            auto& memberships = visual.memberships[object];
            memberships.erase(std::remove(memberships.begin(), memberships.end(), previousGroup), memberships.end());
            visual.dirtyObjects.push_back(object);
        }
        // Old topology retains indices until the next complete scene reset.
        group.visualObjects.clear(); group.snapshot.clear(); group.order.clear(); group.cpu = CCArray::create();
        visual.topologyDirty = true;
    }
    VisualGroup group;
    group.source = array; group.cpu = CCArray::create();
    std::unordered_set<GameObject*> seen;
    bool duplicates = false;
    for (auto* object : CCArrayExt<GameObject, false>(array)) {
        if (!object) break;
        if (!seen.insert(object).second) duplicates = true;
        group.snapshot.push_back(object);
        if (auto reason=visualObjectRejection(object); !reason.empty()) { ++group.rejectionCounts[rejectionCounterKey(object,reason)]; group.cpu->addObject(object); continue; }
        auto [entry, inserted] = visual.objectIndices.try_emplace(object, static_cast<std::uint32_t>(visual.objects.size()));
        if (inserted) {
            visual.objects.push_back(object); visual.objectReferences.emplace_back(object); visual.memberships.emplace_back();
            visual.group575Objects.push_back(group575MovementRequested() && belongsTo575(object));
            visual.objectCombinations.push_back(UINT32_MAX); visual.objectSlots.push_back(0);
            visual.objectCursors.push_back(static_cast<std::uint32_t>(visual.actions.size()));
        }
        group.visualObjects.push_back(entry->second);
        group.group575Members+=visual.group575Objects[entry->second];
        group.order.try_emplace(entry->second, static_cast<std::uint32_t>(group.snapshot.size() - 1));
    }
    if (duplicates) {
        flushVisualStream();
        group.cpu = array; group.visualObjects.clear(); group.order.clear();
        group.rejectionCounts.clear(); group.rejectionCounts["duplicate_member_array"]=array->count();
    }
    const auto index = static_cast<std::uint32_t>(visual.groups.size());
    for (auto object : group.visualObjects) {
        visual.memberships[object].push_back(index); visual.dirtyObjects.push_back(object);
    }
    visual.groupIndices.emplace(array, index); visual.groups.push_back(std::move(group));
    visual.topologyDirty = true;
    return &visual.groups.back();
}

void recordVisualAction(VisualGroup& group, gpu::Action action) {
    if (visual.actions.size() >= 16384) flushVisualStream(true);
    action.flags |= 32u;
    action.padding = static_cast<float>(visual.owner->m_gameState.m_commandIndex);
    action.cosine = static_cast<float>(visual.actions.size());
    group.tape.push_back(static_cast<std::uint32_t>(visual.actions.size()));
    visual.actions.push_back(action);
    visual.actionGroups.push_back(visual.groupIndices.at(group.source.data()));
    visual.logicalVisits += group.visualObjects.size();
    if (action.kind == 0) visual.moveVisits += group.visualObjects.size();
    else visual.rotationVisits += group.visualObjects.size();
    if (transformCostDiagnostics()) {
        if (action.kind == 0) ++visual.censusTranslationCalls;
        else ++visual.censusAffineCalls;
    }
}

void buildVisualCombinations() {
    if (!visual.topologyDirty) return;
    std::sort(visual.dirtyObjects.begin(), visual.dirtyObjects.end());
    visual.dirtyObjects.erase(std::unique(visual.dirtyObjects.begin(), visual.dirtyObjects.end()), visual.dirtyObjects.end());
    for (auto object : visual.dirtyObjects) {
        const auto previous = visual.objectCombinations[object];
        if (previous != UINT32_MAX) {
            visual.combinations[previous].cohortsDirty = true;
            auto& objects = visual.combinations[previous].objects;
            const auto slot = visual.objectSlots[object];
            objects[slot] = objects.back(); visual.objectSlots[objects[slot]] = slot;
            objects.pop_back(); visual.objectCombinations[object] = UINT32_MAX;
        }
        const auto& membership = visual.memberships[object];
        if (membership.empty()) continue;
        auto [entry, inserted] = visual.combinationIndices.try_emplace(membership, static_cast<std::uint32_t>(visual.combinations.size()));
        if (inserted) visual.combinations.push_back({membership, {}});
        auto& objects = visual.combinations[entry->second].objects;
        visual.combinations[entry->second].cohortsDirty = true;
        visual.objectCombinations[object] = entry->second;
        visual.objectSlots[object] = static_cast<std::uint32_t>(objects.size());
        objects.push_back(object);
    }
    visual.dirtyObjects.clear();
    visual.topologyDirty = false; ++visual.topologyBuilds;
}

void visualInput(GJBaseGameLayer* layer, GameObject* object, gpu::ObjectState& state) {
    state.x = object->m_positionX; state.y = object->m_positionY;
    state.rotation = object->m_fRotationX; state.padding = object->m_fRotationY;
    state.offsetX = object->m_positionXOffset; state.offsetY = object->m_positionYOffset;
    state.rotationOffsetX = object->m_rotationXOffset; state.rotationOffsetY = object->m_rotationYOffset;
    state.options = (object->m_canRotateFree ? 1u : 0u) | (object->m_unk4fb ? 2u : 0u) |
                    (object->m_tempOffsetXRelated ? 4u : 0u) | (object->m_isDecoration2 ? 256u : 0u);
    state.commandStamp = object->m_unk4C4;
    state.sectionX = object->m_outerSectionIndex; state.sectionY = object->m_middleSectionIndex;
    state.sectionFactorX = layer->m_sectionXFactor; state.sectionFactorY = layer->m_sectionYFactor;
    state.historyX = object->m_lastPosition.x; state.historyY = object->m_lastPosition.y;
}

void evaluateVisualCPU(gpu::ObjectState& state, gpu::Action const& action) {
    if (!(state.options & 256u) && state.commandStamp != static_cast<std::uint32_t>(action.padding)) {
        state.historyX = static_cast<float>(state.x); state.historyY = static_cast<float>(state.y);
        state.commandStamp = static_cast<std::uint32_t>(action.padding); state.options |= 512u;
    }
    if (action.kind == 0) {
        if (action.dx != 0 && !(state.options & 4u)) state.x += action.dx;
        if (action.dy != 0) state.y += action.dy;
    } else {
        state.options |= 32u;
        const CCAffineTransform matrix{action.matrixA, action.matrixB, action.matrixC, action.matrixD, action.matrixTx, action.matrixTy};
        const RotationKernel kernel({static_cast<float>(action.centerX), static_cast<float>(action.centerY)},
            {static_cast<float>(action.dx), static_cast<float>(action.dy)}, matrix);
        const auto position = kernel.position(_mm_set_pd(state.y, state.x), _mm_set_pd(state.offsetY, state.offsetX));
        state.x = position.x; state.y = position.y;
        if ((state.options & 1u) && action.rotationDelta != 0) {
            const float oldX = state.rotation, oldY = state.padding;
            state.rotation += action.rotationDelta; state.padding += action.rotationDelta;
            if (state.rotation != oldX) state.options |= 64u;
            if (state.padding != oldY) state.options |= 128u;
            state.rotationOffsetX += action.rotationDelta; state.rotationOffsetY += action.rotationDelta;
        }
        state.options = (state.options & ~2u) | ((action.flags & 64u) ? 2u : 0u);
    }
    if (action.kind == 0) state.options |= 16u;
    state.commandStamp = static_cast<std::uint32_t>(action.padding);
    if (state.sectionX >= 0) {
        if (!std::isfinite(state.x) || !std::isfinite(state.y) || state.x > 1'000'000.0 || state.y > 1'000'000.0)
            state.options |= 8u;
        else {
            const int sx = state.x <= 0 ? 0 : static_cast<int>(static_cast<double>(state.sectionFactorX) * state.x);
            const int sy = state.y <= 0 ? 0 : static_cast<int>(static_cast<double>(state.sectionFactorY) * state.y);
            if (sx != state.sectionX || sy != state.sectionY) {
                if (state.eventCount < 4u)
                    state.events[state.eventCount++] = {state.x, state.y, static_cast<std::uint32_t>(action.cosine), 0};
                else state.options |= 8u;
                state.sectionX = sx; state.sectionY = sy;
            }
        }
    }
}

std::optional<TransformBounds> visualViewport() {
    if (mode == Mode::cullingProof && cullingProofViewport) return cullingProofViewport;
    auto* layer = visual.owner;
    const auto size = CCDirector::sharedDirector()->getWinSize();
    TransformBounds viewport;
    for (auto point : {CCPoint(0, 0), CCPoint(size.width, 0), CCPoint(0, size.height), CCPoint(size.width, size.height)}) {
        const auto local = layer->m_objectLayer->convertToNodeSpace(point);
        viewport.include(local.x, local.y);
    }
    const auto camera = layer->m_gameState.m_cameraPosition;
    const double width = std::max<double>(viewport.right - viewport.left, layer->m_cameraWidth);
    const double height = std::max<double>(viewport.top - viewport.bottom, layer->m_cameraHeight);
    const double shake = std::abs(layer->m_gameState.m_cameraShakeStrength);
    if (!viewport.valid() || !std::isfinite(width) || !std::isfinite(height) || !std::isfinite(shake) || width <= 0 || height <= 0)
        return std::nullopt;
    // Include both the final scene transform and the authoritative camera state.
    // The margin covers native visibility buffers, shake and camera catch-up.
    viewport.include(camera.x - width, camera.y - height);
    viewport.include(camera.x + width * 2, camera.y + height * 2);
    const double margin = std::max(width, height) * (1.0 + shake) +
        std::abs(layer->m_gameState.m_cameraStepDiff.x) + std::abs(layer->m_gameState.m_cameraStepDiff.y) + 128.0;
    viewport.left -= margin; viewport.right += margin;
    viewport.bottom -= margin; viewport.top += margin;
    const auto current = viewport;
    if (visual.previousViewport.valid()) viewport.include(visual.previousViewport);
    visual.previousViewport = current;
    return viewport;
}

double cullingRadius(GameObject* object) {
    double radius = 0;
    for (CCSprite* sprite : {static_cast<CCSprite*>(object), object->m_colorSprite, object->m_glowSprite}) {
        if (!sprite) continue;
        const auto size = sprite->getContentSize();
        const auto anchor = sprite->getAnchorPointInPoints();
        radius = std::max<double>(radius, (std::abs(size.width) + std::abs(anchor.x)) * std::abs(sprite->getScaleX()) +
                                 (std::abs(size.height) + std::abs(anchor.y)) * std::abs(sprite->getScaleY()));
    }
    return radius + std::abs(object->m_fadeMargin) + 32.0;
}

void buildCullingCohorts(VisualCombination& combination) {
    if (!combination.cohortsDirty) return;
    combination.cohorts.clear();
    std::map<std::tuple<int, int, std::uint32_t, bool>, std::size_t> buckets;
    for (auto id : combination.objects) {
        auto* object = visual.objects[id];
        const bool finite = std::isfinite(object->m_positionX) && std::isfinite(object->m_positionY) &&
            std::abs(object->m_positionX) <= 1'000'000.0 && std::abs(object->m_positionY) <= 1'000'000.0;
        const auto radius = cullingRadius(object);
        // The swept region includes the previous viewport and native fade
        // margins, so recently visible/entering objects are always resolved.
        // Independently animated geometry needs a separate bound provider.
        const bool eligible = finite && std::isfinite(radius) && visualObjectSupported(object) &&
            !object->m_customAudioScale && !object->m_hasCustomChild && object->getChildrenCount() == 0 &&
            object->numberOfRunningActions() == 0 && !(object->m_colorSprite && object->m_colorSpriteLocked);
        const int x = finite ? static_cast<int>(std::floor(object->m_positionX / 256.0)) : 0;
        const int y = finite ? static_cast<int>(std::floor(object->m_positionY / 256.0)) : 0;
        const auto cursor = visual.objectCursors[id];
        auto [entry, inserted] = buckets.try_emplace({x, y, cursor, eligible}, combination.cohorts.size());
        if (inserted) {
            combination.cohorts.emplace_back();
            auto& cohort = combination.cohorts.back();
            cohort.cursor = cohort.boundsCursor = cursor; cohort.eligible = eligible;
            cohort.minOffsetX = cohort.maxOffsetX = object->m_positionXOffset;
            cohort.minOffsetY = cohort.maxOffsetY = object->m_positionYOffset;
            cohort.stagger = (static_cast<std::uint32_t>(x) * 73856093u) ^ (static_cast<std::uint32_t>(y) * 19349663u);
        }
        auto& cohort = combination.cohorts[entry->second];
        cohort.objects.push_back(id); cohort.bounds.include(object->m_positionX, object->m_positionY);
        cohort.minOffsetX = std::min<double>(cohort.minOffsetX, object->m_positionXOffset);
        cohort.maxOffsetX = std::max<double>(cohort.maxOffsetX, object->m_positionXOffset);
        cohort.minOffsetY = std::min<double>(cohort.minOffsetY, object->m_positionYOffset);
        cohort.maxOffsetY = std::max<double>(cohort.maxOffsetY, object->m_positionYOffset);
        cohort.radius = std::max(cohort.radius, radius);
    }
    for (auto& cohort : combination.cohorts) cohort.swept = cohort.bounds;
    combination.cohortsDirty = false;
}

void pruneVisualActions(bool cohortsUsed) {
    std::uint32_t trim = static_cast<std::uint32_t>(visual.actions.size());
    if (cohortsUsed) {
        for (auto const& combination : visual.combinations) {
            if (combination.objects.empty()) continue;
            for (auto const& cohort : combination.cohorts)
                if (!cohort.objects.empty()) trim = std::min(trim, cohort.cursor);
        }
    }
    if (!trim) return;
    if (trim != visual.actions.size() && trim < 512) return;
    visual.actions.erase(visual.actions.begin(), visual.actions.begin() + trim);
    visual.actionGroups.erase(visual.actionGroups.begin(), visual.actionGroups.begin() + trim);
    for (std::uint32_t i = 0; i < visual.actions.size(); ++i) visual.actions[i].cosine = static_cast<float>(i);
    for (auto& group : visual.groups) {
        group.tape.erase(group.tape.begin(), std::lower_bound(group.tape.begin(), group.tape.end(), trim));
        for (auto& action : group.tape) action -= trim;
    }
    for (auto& cursor : visual.objectCursors) cursor = cursor >= trim ? cursor - trim : 0;
    for (auto& combination : visual.combinations)
        for (auto& cohort : combination.cohorts) {
            cohort.cursor = cohort.cursor >= trim ? cohort.cursor - trim : 0;
            cohort.boundsCursor = cohort.boundsCursor >= trim ? cohort.boundsCursor - trim : 0;
        }
}

void flushVisualStream(bool force) {
    if (visual.actions.empty()) return;
    const auto started = Clock::now();
    const bool adaptiveActive = mode == Mode::live && cullingRequested();
    if (adaptiveActive && !force && !visual.adaptive.enabled && visual.cullingInitialized && !visual.switchingCulling) {
        // Drain all pending work before discarding cohort cursors. The nested
        // forced flush keeps the original action and section-event ordering.
        visual.switchingCulling = true;
        flushVisualStream(true);
        visual.switchingCulling = false;
        visual.cullingInitialized = false;
        for (auto& combination : visual.combinations) { combination.cohorts.clear(); combination.cohortsDirty = true; }
        log::info("VULKANIZER_ADAPTIVE_CULLING mode=batching cull_ms_per_million={:.3f} baseline_ms_per_million={:.3f}",
            visual.adaptive.cullCost * 1000000, visual.adaptive.baselineCost * 1000000);
        if (visual.actions.empty()) return;
    }
    struct AdaptiveSample {
        Clock::time_point started; bool active, frame;
        ~AdaptiveSample() {
            if (!active) return;
            const bool before = visual.adaptive.enabled;
            visual.adaptive.record(ms(started), visual.logicalVisits, frame);
            if (!before && visual.adaptive.enabled)
                log::info("VULKANIZER_ADAPTIVE_CULLING mode=culling cull_ms_per_million={:.3f} baseline_ms_per_million={:.3f}",
                    visual.adaptive.cullCost * 1000000, visual.adaptive.baselineCost * 1000000);
        }
    } sample{Clock::now(), adaptiveActive, !force};
    auto* layer = visual.owner;
    buildVisualCombinations();
    const bool cohortsUsed = (cullingRequested() && (!adaptiveActive || visual.adaptive.enabled)) || visual.cullingInitialized;
    std::optional<TransformBounds> viewport;
    if (cohortsUsed) {
        visual.cullingInitialized = true;
        if (!force) { ++visual.cullingFrame; viewport = visualViewport(); }
        force = force || visual.cullingFailed || !viewport;
    }
    auto& states = visual.states; auto& spans = visual.spans;
    auto& indices = visual.indices; auto& objectIds = visual.objectIds;
    states.clear(); spans.clear(); indices.clear(); objectIds.clear();
    states.reserve(visual.objects.size()); spans.reserve(visual.objects.size()); objectIds.reserve(visual.objects.size());
    auto& selections = visual.selections;
    selections.clear();
    const auto end = static_cast<std::uint32_t>(visual.actions.size());
    visual.activeChains = visual.dormantChains = visual.chainObjects = visual.maxChainObjects = 0;
    for (auto& combination : visual.combinations) {
        if (combination.objects.empty()) { combination.cohorts.clear(); combination.cohortsDirty = true; continue; }
        bool active = false;
        for (auto group : combination.groups) if (!visual.groups[group].tape.empty()) { active = true; break; }
        if (active) ++visual.activeChains; else ++visual.dormantChains;
        visual.chainObjects += combination.objects.size();
        visual.maxChainObjects = std::max<std::uint64_t>(visual.maxChainObjects, combination.objects.size());
        if (cohortsUsed) {
            buildCullingCohorts(combination);
            auto& tapes = combination.tapeScratch;
            tapes.clear();
            for (auto& cohort : combination.cohorts) {
                auto found = std::find_if(tapes.begin(), tapes.end(), [&](auto const& item) { return item.first == cohort.cursor; });
                gpu::Span span{};
                if (found != tapes.end()) span = found->second;
                else {
                    span.offset = static_cast<std::uint32_t>(indices.size());
                    for (auto group : combination.groups) {
                        const auto& tape = visual.groups[group].tape;
                        indices.insert(indices.end(), std::lower_bound(tape.begin(), tape.end(), cohort.cursor), tape.end());
                    }
                    span.count = static_cast<std::uint32_t>(indices.size()) - span.offset;
                    if (combination.groups.size() > 1) std::sort(indices.begin() + span.offset, indices.end());
                    else ++visual.singleTapeSortsAvoided;
                    tapes.emplace_back(cohort.cursor, span);
                }
                if (!span.count) {
                    cohort.cursor = cohort.boundsCursor = end;
                    for (auto id : cohort.objects) visual.objectCursors[id] = end;
                    continue;
                }
                std::uint32_t added = 0;
                const auto boundsStart = transformCostDiagnostics() ? Clock::now() : Clock::time_point{};
                for (auto i = span.offset; !force && i < span.offset + span.count; ++i) {
                    const auto action = indices[i];
                    if (action < cohort.boundsCursor) continue;
                    cohort.bounds = advanceTransformBounds(cohort.bounds, visual.actions[action],
                        cohort.minOffsetX, cohort.maxOffsetX, cohort.minOffsetY, cohort.maxOffsetY);
                    cohort.swept.include(cohort.bounds); ++added;
                }
                cohort.boundsCursor = end;
                if (transformCostDiagnostics()) visual.diagBoundsMs += ms(boundsStart);
                const auto age = cohort.deferredSince ? visual.cullingFrame - cohort.deferredSince : 0;
                const bool budget = age >= 8 || span.count >= 256 || (age >= 4 && (visual.cullingFrame + cohort.stagger) % 4 == 0);
                ++visual.boundChecks;
                const bool visible = force || !cohort.eligible || !cohort.swept.valid() || cohort.swept.intersects(*viewport, cohort.radius);
                if (!visible && !budget) {
                    if (!cohort.deferredSince) cohort.deferredSince = visual.cullingFrame;
                    visual.culledInputs += cohort.objects.size();
                    visual.deferredOperations += static_cast<std::uint64_t>(added) * cohort.objects.size();
                    continue;
                }
                if (budget) visual.budgetResolutions += cohort.objects.size();
                else visual.visibilityResolutions += cohort.objects.size();
                const auto first = states.size();
                for (auto id : cohort.objects) {
                    visualInput(layer, visual.objects[id], states.emplace_back());
                    spans.push_back(span); objectIds.push_back(id);
                }
                selections.push_back({&cohort, first, cohort.objects.size(), !force});
            }
            continue;
        }
        const auto offset = static_cast<std::uint32_t>(indices.size());
        for (auto group : combination.groups)
            indices.insert(indices.end(), visual.groups[group].tape.begin(), visual.groups[group].tape.end());
        const auto count = static_cast<std::uint32_t>(indices.size()) - offset;
        if (!count) continue;
        if (combination.groups.size() > 1) std::sort(indices.begin() + offset, indices.end());
        else ++visual.singleTapeSortsAvoided;
        for (auto object : combination.objects) {
            visualInput(layer, visual.objects[object], states.emplace_back());
            spans.push_back({offset, count}); objectIds.push_back(object);
        }
    }
    visual.packMs += ms(started);
    if (states.empty()) { pruneVisualActions(cohortsUsed); return; }
    auto& initial = visual.initial;
    const bool verify575 = std::getenv("VULKANIZER_GROUP575_VERIFY") && visual.group575ParityBatches<8 &&
        std::any_of(objectIds.begin(),objectIds.end(),[](auto id){return visual.group575Objects[id]!=0;});
    const bool backedUp = !visual.checking || verify575;
    if (backedUp) initial = states;
    gpu::HybridBatchMetrics metrics;
    std::string error;
    bool gpuOkay = gpu::HybridTransformExecutor::get().evaluate(states, visual.actions, spans, indices, metrics, error, transformCostDiagnostics());
    if (gpuOkay && backedUp) {
        for (std::size_t i = 0; i < initial.size(); ++i) {
            auto expected = initial[i];
            const auto span = spans[i];
            for (std::uint32_t j = 0; j < span.count; ++j) evaluateVisualCPU(expected, visual.actions[indices[span.offset + j]]);
            if (std::memcmp(&expected, &states[i], sizeof(expected)) != 0) { gpuOkay = false; error = "ordered visual tape parity mismatch"; break; }
        }
        if (gpuOkay) {
            visual.checking = true;
            log::info("VULKANIZER_VISUAL_GPU_PARITY PASS objects={} shared_action_entries={} operations={}", states.size(), indices.size(), visual.actions.size());
            if(verify575)log::info("VULKANIZER_GROUP575_PARITY PASS batch={} objects={} comparison=bit_exact_ordered_cpu includes_section_events=true",++visual.group575ParityBatches,states.size());
        }
    }
    if (!gpuOkay) {
        visual.failed = true;
        log::error("Visual GPU stream disabled; replaying pending operations on CPU: {}", error);
        if (backedUp) states = initial;
        for (std::size_t i = 0; i < states.size(); ++i) {
            const auto span = spans[i];
            for (std::uint32_t j = 0; j < span.count; ++j) evaluateVisualCPU(states[i], visual.actions[indices[span.offset + j]]);
        }
    } else { ++visual.gpuBatches; visual.waitMs += metrics.syncWaitMs; visual.readbackMs += metrics.transferMs;
        visual.censusDispatchMs += metrics.dispatchSubmitMs; visual.censusUploadMs += metrics.uploadMs;
        visual.censusStageCycles += metrics.stageThreadCycles; visual.censusFenceCycles += metrics.fenceThreadCycles;
        visual.censusQpcStageMs += metrics.qpcStageWallMs; visual.censusGpuMs += metrics.gpuComputeMs; }
    const auto applyStarted = Clock::now();
    auto& transitions = visual.transitions;
    const auto transitionStart = transformCostDiagnostics() ? Clock::now() : Clock::time_point{};
    transitions.clear();
    for (std::size_t i = 0; i < states.size(); ++i) {
        const auto& state = states[i];
        const auto objectId = objectIds[i];
        if (state.options & 8u) {
            const auto span = spans[i];
            for (std::uint32_t j = 0; j < span.count; ++j) {
                const auto action = indices[span.offset + j];
                const auto order = visual.groups[visual.actionGroups[action]].order.at(objectId);
                transitions.push_back({action, order, objectId, {}, true});
            }
        } else {
            for (std::uint32_t j = 0; j < state.eventCount; ++j) {
                const auto& event = state.events[j];
                const auto order = visual.groups[visual.actionGroups[event.actionIndex]].order.at(objectId);
                transitions.push_back({event.actionIndex, order, objectId, event, false});
            }
        }
    }
    sortSectionTransitions(transitions, visual.transitionScratch);
    const auto commandIndex = layer->m_gameState.m_commandIndex;
    for (auto const& transition : transitions) {
        auto* object = visual.objects[transition.object];
        const auto& action = visual.actions[transition.action];
        layer->m_gameState.m_commandIndex = static_cast<unsigned>(action.padding);
        if (!transition.replay) {
            object->m_positionX = transition.event.x; object->m_positionY = transition.event.y;
            layer->updateObjectSection(object); ++visual.sectionEvents;
        } else {
            if (action.kind == 0) {
                preserveTransformHistory(*object, layer->m_gameState.m_commandIndex);
                if (action.dx != 0 && !object->m_tempOffsetXRelated) object->m_positionX += action.dx;
                if (action.dy != 0) object->m_positionY += action.dy;
                object->dirtifyObjectPos(); layer->updateObjectSection(object);
            } else {
                const CCAffineTransform matrix{action.matrixA, action.matrixB, action.matrixC, action.matrixD, action.matrixTx, action.matrixTy};
                applyPrimitive(layer, object, {visual.groups[visual.actionGroups[transition.action]].source.data(),
                    RotationKernel({static_cast<float>(action.centerX), static_cast<float>(action.centerY)},
                    {static_cast<float>(action.dx), static_cast<float>(action.dy)}, matrix), action.rotationDelta, (action.flags & 64u) != 0});
            }
            if (object->m_isDecoration2) object->m_unk4C4 = layer->m_gameState.m_commandIndex;
            ++visual.replayedVisits;
        }
    }
    layer->m_gameState.m_commandIndex = commandIndex;
    if (transformCostDiagnostics()) visual.diagTransitionMs += ms(transitionStart);
    const auto stateApplyStart = transformCostDiagnostics() ? Clock::now() : Clock::time_point{};
    for (std::size_t i = 0; i < states.size(); ++i) {
        auto* object = visual.objects[objectIds[i]];
        const auto& state = states[i];
        if (state.options & 8u) continue;
        object->m_positionX = state.x; object->m_positionY = state.y;
        visual.group575StateWrites+=visual.group575Objects[objectIds[i]];
        if (state.options & 512u) {
            object->m_lastPosition = CCPoint(state.historyX, state.historyY);
            object->dirtifyObjectRect();
        }
        object->m_rotationXOffset = state.rotationOffsetX; object->m_rotationYOffset = state.rotationOffsetY;
        if (state.options & 64u) {
            if (object->getRotationX() == state.rotation)
                object->m_fRotationX = std::abs(state.rotation) < 1.f ? state.rotation + 1.f : std::nextafter(state.rotation, INFINITY);
            object->setRotationX(state.rotation);
        }
        if (state.options & 128u) {
            if (object->getRotationY() == state.padding)
                object->m_fRotationY = std::abs(state.padding) < 1.f ? state.padding + 1.f : std::nextafter(state.padding, INFINITY);
            object->setRotationY(state.padding);
        }
        if (state.options & 32u) object->m_isDirty = true;
        if (state.options & 16u) object->m_isObjectPosDirty = true;
        object->m_isUnmodifiedPosDirty = true;
        object->m_unk4fb = (state.options & 2u) != 0; object->m_unk4C4 = state.commandStamp;
        ++visual.stateWrites;
    }
    for (auto id : objectIds) {
        auto* object = visual.objects[id];
        const CCPoint position(static_cast<float>(object->m_positionX), static_cast<float>(object->m_positionY));
        object->cocos2d::CCSprite::setPosition(position);
        if (object->m_colorSprite && !object->m_colorSpriteLocked) object->m_colorSprite->setPosition(position);
    }
    if (transformCostDiagnostics()) visual.diagGpuApplyMs += ms(stateApplyStart);
    for (auto const& selection : selections) {
        auto& cohort = *selection.cohort;
        for (auto i = selection.first; i < selection.first + selection.count; ++i) {
            if (selection.checkBounds && !cohort.bounds.contains(states[i].x, states[i].y)) {
                visual.cullingFailed = true;
                log::error("Transformation culling bounds failed validation; resolving all pending objects and disabling culling");
            }
        }
        cohort.bounds = {};
        for (auto i = selection.first; i < selection.first + selection.count; ++i) cohort.bounds.include(states[i].x, states[i].y);
        cohort.swept = cohort.bounds; cohort.cursor = cohort.boundsCursor = end; cohort.deferredSince = 0;
        for (auto id : cohort.objects) visual.objectCursors[id] = end;
    }
    visual.applyMs += ms(applyStarted); visual.totalMs += ms(started);
    if (visual.gpuBatches == 1 || visual.gpuBatches % 120 == 0 || !gpuOkay)
        log::info("VULKANIZER_VISUAL_STREAM gpu_batches={} logical_visits={} state_writes={} replayed_visits={} section_events={} combinations={} cached_groups={} topology_builds={} reused_groups={} pack_ms={:.3f} wait_ms={:.3f} readback_ms={:.3f} apply_ms={:.3f} total_ms={:.3f} move_visits={} rotation_visits={} cpu_move_visits={} cpu_rotation_visits={}",
            visual.gpuBatches, visual.logicalVisits, visual.stateWrites, visual.replayedVisits, visual.sectionEvents, visual.combinations.size(), visual.groups.size(),
            visual.topologyBuilds, visual.reusedGroups, visual.packMs, visual.waitMs, visual.readbackMs, visual.applyMs, visual.totalMs,
            visual.moveVisits, visual.rotationVisits, visual.cpuMoveVisits, visual.cpuRotationVisits);
    if (visual.gpuBatches == 1 || visual.gpuBatches % 120 == 0 || !gpuOkay)
        log::info("VULKANIZER_CHAIN_PLAN active={} dormant={} objects={} max_objects={} single_tape_sorts_avoided={} note=shared_action_lists_per_object_math_retained", visual.activeChains, visual.dormantChains, visual.chainObjects, visual.maxChainObjects, visual.singleTapeSortsAvoided);
    if (cohortsUsed && visual.lastCullingLogFrame != visual.cullingFrame &&
        (visual.cullingFrame == 1 || visual.cullingFrame % 120 == 0 || visual.cullingFailed)) {
        visual.lastCullingLogFrame = visual.cullingFrame;
        log::info("VULKANIZER_TRANSFORM_CULLING enabled={} deferred_object_windows={} offscreen_operations_deferred={} visibility_resolutions={} budget_resolutions={} bound_tests={} pending_records={} resolved_objects={} force={}",
            !visual.cullingFailed, visual.culledInputs, visual.deferredOperations, visual.visibilityResolutions,
            visual.budgetResolutions, visual.boundChecks, visual.actions.size(), states.size(), force);
    }
    if (transformCostDiagnostics() && (visual.gpuBatches == 1 || visual.gpuBatches % 120 == 0))
        log::info("VULKANIZER_TRANSFORM_COST group_calls={} group_samples={} sampled_cache_hits={} group_sample_ms={:.3f} cpu_object_samples={} sampled_decor={} sampled_solid={} sampled_orientation_locked_solid={} sampled_rotatable_solid={} sampled_other={} section_samples={} section_sample_ms={:.3f} bounds_ms={:.3f} transition_inclusive_ms={:.3f} state_and_cocos_apply_ms={:.3f} gpu_wait_ms={:.3f} gpu_readback_ms={:.3f} pack_inclusive_ms={:.3f} deferred_operations={} state_writes={} cpu_move_visits={} cpu_rotation_visits={} adaptive_culling={}",
            visual.diagGroups, visual.diagGroups / 128, visual.diagCacheHits, visual.diagGroupMs, visual.diagObjects,
            visual.diagDecor, visual.diagSolid, visual.diagLockedSolid, visual.diagRotatableSolid, visual.diagOther,
            visual.diagSectionSamples, visual.diagSectionMs, visual.diagBoundsMs, visual.diagTransitionMs,
            visual.diagGpuApplyMs, visual.waitMs, visual.readbackMs, visual.packMs, visual.deferredOperations,
            visual.stateWrites, visual.cpuMoveVisits, visual.cpuRotationVisits, visual.adaptive.enabled);
    if (transformCostDiagnostics() && (visual.gpuBatches == 1 || visual.gpuBatches % 120 == 0))
        log::info("VULKANIZER_ELIGIBILITY_CENSUS A_runtime_translation_calls={} A_object_operations={} B_runtime_affine_calls={} B_object_operations={} eligible_unique_objects={} active_chains={} dormant_chains={} max_objects_per_chain={} cpu_move_visits_unclassified={} cpu_rotation_visits_unclassified={} C_time=unmeasured D_time=unmeasured E_time=unmeasured dispatch_submit_ms={:.3f} upload_ms={:.3f} sync_wait_ms={:.3f} readback_ms={:.3f} action_bytes={} object_input_bytes={} note=GPU_route_only_not_whole_frame_percentages",
            visual.censusTranslationCalls, visual.moveVisits, visual.censusAffineCalls, visual.rotationVisits,
            visual.objects.size(), visual.activeChains, visual.dormantChains, visual.maxChainObjects,
            visual.cpuMoveVisits, visual.cpuRotationVisits, visual.censusDispatchMs, visual.censusUploadMs,
            visual.waitMs, visual.readbackMs, visual.actions.size() * sizeof(gpu::Action), states.size() * sizeof(gpu::ObjectState));
    if (transformCostDiagnostics() && (visual.gpuBatches == 1 || visual.gpuBatches % 120 == 0))
        log::info("VULKANIZER_CAUSAL_CENSUS move_native_fallback={} move_mixed_subset={} rotation_no_center={} rotation_body={} rotation_body_legacy_gpu_subset={} qpc_executor_wall_ms={:.3f} executor_thread_cycles={} fence_thread_cycles={} gpu_query_ms={:.3f} fence_wall_ms={:.3f} counter_domain=helper_member_nominations_not_propagation_or_unique_objects",
            visual.cpuMoveFallbackVisits, visual.cpuMoveMixedVisits, visual.cpuRotationNoCenterVisits, visual.cpuRotationBodyVisits, visual.legacyGpuSampleVisits,
            visual.censusQpcStageMs,visual.censusStageCycles,visual.censusFenceCycles,visual.censusGpuMs,visual.waitMs);
    if(transformCostDiagnostics()&&(visual.gpuBatches==1||visual.gpuBatches%120==0))
        log::info("VULKANIZER_GROUP575_GPU move_member_operations={} rotation_member_operations={} cpu_final_state_writes={} unrelated_barriers_avoided={} note=section_event_and_replay_writes_reported_separately_in_stream",visual.group575MoveVisits,visual.group575RotationVisits,visual.group575StateWrites,visual.group575UnrelatedBarriersAvoided);
    pruneVisualActions(cohortsUsed);
    if ((visual.cullingFailed || visual.failed) && !visual.actions.empty()) flushVisualStream(true);
}

bool schedulerGpu(GJBaseGameLayer* layer, CCArray* objects, CCPoint center, CCPoint move,
                  CCAffineTransform const& matrix, std::vector<gpu::ObjectState>& result) {
    if (runtimeFailed || objects->count() == 0) return false;
    std::vector<GameObject*> unique;
    std::vector<gpu::Action> actions;
    std::vector<gpu::Span> spans;
    std::vector<std::uint32_t> indices;
    for (auto* object : CCArrayExt<GameObject, false>(objects)) {
        if (!object || (object->m_objectType != GameObjectType::Decoration && object->m_objectType != GameObjectType::Solid) ||
            (object->m_classType != GameObjectClassType::Game && object->m_classType != GameObjectClassType::Enhanced) ||
            object == layer->m_player1 || object == layer->m_player2 || object->m_isTrigger || object->m_isStartPos ||
            object->m_hasGroupParent || object->m_hasAreaParent || object->m_parentMode || object->m_linkedGroup) {
            static unsigned reasons = 0;
            if (mode == Mode::live && object && reasons++ < 4)
                log::info("VULKANIZER_SCHEDULER_GPU_REJECT id={} type={} class={} trigger={} start={} group_parent={} area_parent={} parent_mode={} linked={}",
                    object->m_objectID, static_cast<int>(object->m_objectType), static_cast<int>(object->m_classType),
                    object->m_isTrigger, object->m_isStartPos, object->m_hasGroupParent,
                    object->m_hasAreaParent, object->m_parentMode, object->m_linkedGroup);
            return false;
        }
        unique.push_back(object);
    }
    auto sorted = unique;
    std::sort(sorted.begin(), sorted.end(), std::less<GameObject*>{});
    if (std::adjacent_find(sorted.begin(), sorted.end()) != sorted.end()) return false;
    result.reserve(unique.size()); actions.reserve(unique.size());
    spans.reserve(unique.size()); indices.reserve(unique.size());
    for (std::uint32_t i = 0; i < unique.size(); ++i) {
        auto* object = unique[i];
        result.push_back({object->m_positionX, object->m_positionY, 0.f, 0.f});
        gpu::Action action{};
        action.kind = 1; action.flags = 8u;
        action.centerX = center.x; action.centerY = center.y;
        action.dx = move.x; action.dy = move.y;
        action.matrixA = matrix.a; action.matrixB = matrix.b;
        action.matrixC = matrix.c; action.matrixD = matrix.d;
        action.matrixTx = matrix.tx; action.matrixTy = matrix.ty;
        action.objectOffsetX = object->m_positionXOffset;
        action.objectOffsetY = object->m_positionYOffset;
        actions.push_back(action); spans.push_back({i, 1}); indices.push_back(i);
    }
    gpu::HybridBatchMetrics metrics;
    std::string error;
    if (!gpu::HybridTransformExecutor::get().evaluate(result, actions, spans, indices, metrics, error)) {
        runtimeFailed = true;
        log::error("Scheduler GPU disabled for this process; completing this action on CPU before future vanilla fallback: {}", error);
        return false;
    }
    const RotationKernel reference(center, move, matrix);
    for (std::size_t i = 0; i < unique.size(); ++i) {
        const auto expected = reference.position(unique[i]);
        if (std::bit_cast<std::uint64_t>(expected.x) != std::bit_cast<std::uint64_t>(result[i].x) ||
            std::bit_cast<std::uint64_t>(expected.y) != std::bit_cast<std::uint64_t>(result[i].y)) {
            runtimeFailed = true;
            log::error("Scheduler GPU position parity failed; applying CPU results and disabling replacement for subsequent calls");
            return false;
        }
    }
    if (mode == Mode::live) {
        liveGpuApplied = true;
        sampleGpuWaitMs = metrics.syncWaitMs;
        sampleGpuTransferMs = metrics.transferMs;
    }
    else ++proofGpuBatches;
    (void)layer;
    return true;
}

bool execute(GJBaseGameLayer* layer) {
    if (mode != Mode::live) ++proofExecutions;
    auto* effects = layer->m_effectManager;
    if (!effects || !layer->m_objectLayer || !layer->m_areaTransformNode || !layer->m_areaSkewNode ||
        !layer->m_areaScaleNode || !layer->m_areaTransformNode2 || layer->m_groups.size() < 10000 ||
        layer->m_staticGroups.size() < 10000 || layer->m_optimizedGroups.size() < 10000) return false;
    // Preflight only; do not partially replay scheduling on an unsupported input.
    for (auto* action : effects->m_unkVector5b0) if (!action) return false;
    for (auto const& [key, actions] : effects->m_unkMap5c8)
        for (auto* action : actions) if (!action) return false;
    auto start = Clock::now();
    auto* root = layer->m_objectLayer;
    const float scaleX = root->getScaleX(), scaleY = root->getScaleY();
    const CCPoint rootPosition = root->getPosition();
    root->setScale(1.f); root->setPosition(CCPointZero);
    for (auto const& [key, actions] : effects->m_unkMap5c8)
        for (auto* action : actions) action->m_stepStamp = layer->m_gameState.m_commandIndex;
    std::uint64_t visits = 0, positionVisits = 0;
    std::vector<DeferredRotation> deferred;
    for (auto* action : effects->m_unkVector5b0) {
        if (action->m_stepStamp != layer->m_gameState.m_commandIndex || action->m_someInterpValue1RelatedFalse) continue;
        auto* centerObject = layer->tryGetMainObject(action->m_centerGroupID);
        if (centerObject && visual.owner == layer && visual.objectIndices.contains(centerObject)) {
            flushVisualStream();
            visual.allowed = false;
            log::warn("Visual stream disabled because a runtime pivot escaped the dependency audit");
        }
        if (centerObject) {
            for (auto const& pending : deferred) {
                if (!pending.members->containsObject(centerObject)) continue;
                ++batchCounters.barriers;
                flushRotations(layer, deferred);
                break;
            }
        }
        auto* staticGroup = layer->getStaticGroup(action->m_targetGroupID);
        auto* objects = layer->getOptimizedGroup(action->m_targetGroupID);
        const bool ignoreStatic = staticGroup->count() == 0;
        if (!ignoreStatic) objects = layer->getGroup(action->m_targetGroupID);
        float rotation = static_cast<float>(ignoreStatic ?
            readAction<double>(action, 0xa8) - readAction<double>(action, 0x118) :
            readAction<double>(action, 0xa0) - readAction<double>(action, 0x110));
        const bool finished = action->m_finishRelated;
        if (rotation == 0.f && !finished) continue;
        action->m_someInterpValue1RelatedFalse = true;
        float orientation = action->m_lockObjectRotation ? 0.f : rotation;
        layer->claimRotationAction(action->m_targetGroupID, action->m_centerGroupID,
                                   rotation, orientation, ignoreStatic, false);
        if (!centerObject) {
            if (orientation != 0.f) {
                // A pivot-less rotation of CPU-only members consumes none of
                // the pending GPU object states. Do not drain unrelated tapes.
                // Mixed/GPU targets retain the original conservative barrier.
                const bool selective = group575MovementRequested() || mode==Mode::streamProof || mode==Mode::cullingProof;
                auto* unrelated = selective ? visualGroup(layer,objects) : nullptr;
                if(unrelated && unrelated->visualObjects.empty())++visual.group575UnrelatedBarriersAvoided;
                else flushVisualStream();
                flushRotations(layer, deferred);
                if (mode == Mode::live && visual.owner == layer) { visual.cpuRotationVisits += objects->count(); visual.cpuRotationNoCenterVisits += objects->count(); }
                for (auto* object : CCArrayExt<GameObject, false>(objects)) {
                    if (!object) break;
                    layer->rotateObject(object, orientation);
                    ++visits;
                }
            }
            continue;
        }
        const bool canDefer = pipelineEnabled() && (mode != Mode::live || liveGpuApplied) && groupSupported(layer, objects);
        if (!canDefer) flushRotations(layer, deferred);
        const CCPoint center(static_cast<float>(centerObject->m_positionX - centerObject->m_positionXOffset),
                             static_cast<float>(centerObject->m_positionY - centerObject->m_positionYOffset));
        const CCPoint move = layer->claimMoveAction(action->m_targetGroupID, ignoreStatic);
        auto* transform = layer->m_areaTransformNode;
        transform->setPosition(center); transform->setScaleX(1.f); transform->setScaleY(1.f);
        layer->m_areaScaleNode->setScaleX(1.f); layer->m_areaScaleNode->setScaleY(1.f);
        transform->setSkewX(0.f); transform->setSkewY(0.f);
        layer->m_areaSkewNode->setSkewX(0.f); layer->m_areaSkewNode->setSkewY(0.f);
        transform->setRotation(rotation);
        layer->prepareTransformParent(false);
        const auto matrix = transform->nodeToWorldTransform();
        layer->m_areaSkewNode->nodeToWorldTransform();
        layer->m_areaScaleNode->nodeToWorldTransform();
        auto* translate = layer->m_areaTransformNode2;
        translate->setScaleX(1.f); translate->setScaleY(1.f);
        translate->setSkewX(0.f); translate->setSkewY(0.f); translate->setRotation(0.f);
        layer->m_rotatedCount += static_cast<int>(objects->count());
        if (auto* group = visualGroup(layer, objects); group && !group->visualObjects.empty()) {
            gpu::Action operation{};
            operation.kind = 1; operation.flags = 8u | 16u | (finished ? 64u : 0u);
            operation.centerX = center.x; operation.centerY = center.y;
            operation.dx = move.x; operation.dy = move.y; operation.rotationDelta = orientation;
            operation.matrixA = matrix.a; operation.matrixB = matrix.b;
            operation.matrixC = matrix.c; operation.matrixD = matrix.d;
            operation.matrixTx = matrix.tx; operation.matrixTy = matrix.ty;
            recordVisualAction(*group, operation);
            visual.group575RotationVisits+=group->group575Members;
            visits += group->visualObjects.size(); positionVisits += group->visualObjects.size();
            objects = group->cpu.data();
        }
        if (canDefer) {
            deferred.push_back({objects, RotationKernel(center, move, matrix), orientation, finished});
            visits += objects->count(); positionVisits += objects->count();
            continue;
        }
        std::vector<gpu::ObjectState> outputs;
        const bool useGpu = (mode == Mode::gpuProof || (mode == Mode::live && !liveGpuApplied && objects->count() > 0)) &&
            schedulerGpu(layer, objects, center, move, matrix, outputs);
        std::size_t index = 0;
        const RotationKernel kernel(center, move, matrix);
        if (mode == Mode::live && visual.owner == layer) { visual.cpuRotationVisits += objects->count(); visual.cpuRotationBodyVisits += objects->count(); if (useGpu) visual.legacyGpuSampleVisits += objects->count(); }
        for (auto* object : CCArrayExt<GameObject, false>(objects)) {
            if (!object) break;
            const bool sampleObject = transformCostDiagnostics() && (index % 128 == 0);
            if (sampleObject) {
                ++visual.diagObjects;
                if (object->m_objectType == GameObjectType::Decoration) ++visual.diagDecor;
                else if (object->m_objectType == GameObjectType::Solid) {
                    ++visual.diagSolid;
                    if (!object->m_canRotateFree || orientation == 0.f) ++visual.diagLockedSolid;
                    else ++visual.diagRotatableSolid;
                } else ++visual.diagOther;
            }
            object->m_unk4fb = finished;
            preserveTransformHistory(*object, layer->m_gameState.m_commandIndex);
            object->m_isDirty = true; object->m_isUnmodifiedPosDirty = true;
            const auto result = useGpu ? outputs[index] : kernel.position(object);
            object->m_positionX = result.x; object->m_positionY = result.y;
            if (orientation != 0.f && object->m_canRotateFree) applySchedulerOrientation(object, orientation);
            const auto sectionStart = sampleObject ? Clock::now() : Clock::time_point{};
            layer->updateObjectSection(object);
            if (sampleObject) { ++visual.diagSectionSamples; visual.diagSectionMs += ms(sectionStart); }
            ++index; ++visits; ++positionVisits;
        }
        layer->updateDisabledObjectsLastPos(objects);
        if (useGpu && mode == Mode::live) {
            liveGpuObjects += index;
            log::info("VULKANIZER_SCHEDULER_GPU_LIVE objects={} source=processRotationActions gpu_output_applied=true callbacks_completed=true wait_ms={:.3f} readback_ms={:.3f} cpu_math_reference_checked=true; independent visual work can enter the shared GPU stream",
                index, sampleGpuWaitMs, sampleGpuTransferMs);
        }
    }
    flushRotations(layer, deferred);
    root->setScaleX(scaleX); root->setScaleY(scaleY); root->setPosition(rootPosition);
    if (mode == Mode::live) {
        ++liveEntries; liveObjects += visits; liveMs += ms(start);
        livePositionObjects += positionVisits;
        recordSchedulerPositionVisits(positionVisits);
        if (liveEntries == 1 || liveEntries % 1024 == 0) {
            log::info("VULKANIZER_SCHEDULER_LIVE entries={} object_visits={} position_visits={} gpu_objects={} total_ms={:.3f} source=processRotationActions native_inline_loop_replaced=true removed=per_object_CCPointMake_and_PointApply_calls",
                liveEntries, liveObjects, livePositionObjects, liveGpuObjects, liveMs);
            log::info("VULKANIZER_TRANSFORM_BATCHING logical_visits={} unique_object_loads={} position_writes={} section_calls={} section_calls_avoided={} orientation_writes={} cache_hits={} cache_misses={} dependency_barriers={} batches={} batch_wall_ms={:.3f}",
                batchCounters.referenceVisits, batchCounters.objectLoads, batchCounters.positionWrites,
                batchCounters.sectionCalls, batchCounters.sectionCallsAvoided, batchCounters.orientationWrites,
                batchCounters.cacheHits, batchCounters.cacheMisses, batchCounters.barriers, batchCounters.batches,
                batchCounters.elapsedMs);
        }
    }
    return true;
}
}

bool tryProcessRotationActions(GJBaseGameLayer* layer) {
    if (mode == Mode::nativeProof) {
        if (++nativeProbeEntries > 1) {
            nativeProbeRecursed = true;
            log::error("Scheduler native probe recursively reentered the hook; aborting fixture comparison");
            return true;
        }
        return false;
    }
    if (mode != Mode::live) return execute(layer);
    if (nativeGameplayBaseline()) return false;
    auto& manager = RendererManager::get();
    if (!manager.gpuTransformAllRequested() || !manager.gpuTransformReady() || runtimeFailed) return false;
    if (verified == 0 && !runRotationSchedulerProof()) return false;
    return verified == 1 && execute(layer);
}

namespace {
auto objectState(GameObject* object) {
    return std::make_tuple(std::bit_cast<std::uint64_t>(object->m_positionX),
        std::bit_cast<std::uint64_t>(object->m_positionY), object->getRotationX(), object->getRotationY(),
        object->m_rotationXOffset, object->m_rotationYOffset, object->m_lastPosition.x,
        object->m_lastPosition.y, object->m_unk4C4, object->m_isDirty, object->m_isObjectPosDirty,
        object->m_isUnmodifiedPosDirty, object->m_isObjectRectDirty, object->m_isOrientedBoxDirty,
        object->m_shouldUseOuterOb, object->m_unk4fb);
}
struct Event {
    int id;
    bool finalizer;
    std::uint64_t x, y;
    float rotationX, rotationY;
    bool operator==(Event const&) const = default;
};
class SchedulerFixture : public GJBaseGameLayer {
public:
    std::vector<Event> events;
    std::vector<GameObject*> objects;
    bool record = true;
    bool emulateVisualFinalizer = false;
    void updateObjectSection(GameObject* object) override {
        if (emulateVisualFinalizer && object->m_outerSectionIndex >= 0) {
            object->m_outerSectionIndex = object->m_positionX <= 0 ? 0 : static_cast<int>(static_cast<double>(m_sectionXFactor) * object->m_positionX);
            object->m_middleSectionIndex = object->m_positionY <= 0 ? 0 : static_cast<int>(static_cast<double>(m_sectionYFactor) * object->m_positionY);
        }
        if (record) events.push_back({object->m_uniqueID, false,
            std::bit_cast<std::uint64_t>(object->m_positionX), std::bit_cast<std::uint64_t>(object->m_positionY),
            object->getRotationX(), object->getRotationY()});
    }
    void updateDisabledObjectsLastPos(CCArray* array) override {
        if (emulateVisualFinalizer) {
            for (auto* object : CCArrayExt<GameObject, false>(array)) {
                if (!object->m_isDecoration2) continue;
                object->m_unk4C4 = m_gameState.m_commandIndex;
                object->cocos2d::CCSprite::setPosition({static_cast<float>(object->m_positionX), static_cast<float>(object->m_positionY)});
            }
        }
        if (record) events.push_back({static_cast<int>(array->count()), true, 0, 0, 0, 0});
    }
};
SchedulerFixture* fixture(unsigned scenario, unsigned count = 64) {
    log::debug("Scheduler proof fixture start scenario={} count={}", scenario, count);
    auto* layer = new SchedulerFixture();
    layer->cocos2d::CCLayer::init();
    layer->m_effectManager = GJEffectManager::create(); layer->m_effectManager->retain();
    log::debug("Scheduler proof effect manager initialized");
    layer->m_groupDict = CCDictionary::create(); layer->m_groupDict->retain();
    layer->m_staticGroupDict = CCDictionary::create(); layer->m_staticGroupDict->retain();
    layer->m_optimizedGroupDict = CCDictionary::create(); layer->m_optimizedGroupDict->retain();
    layer->m_parentGroupsDict = CCDictionary::create(); layer->m_parentGroupsDict->retain();
    layer->m_parentGroupIDs = CCDictionary::create(); layer->m_parentGroupIDs->retain();
    layer->m_removedParentGroupIDs = CCDictionary::create(); layer->m_removedParentGroupIDs->retain();
    layer->m_groups.resize(10000, nullptr);
    layer->m_staticGroups.resize(10000, nullptr);
    layer->m_optimizedGroups.resize(10000, nullptr);
    layer->m_objectLayer = CCLayer::create(); layer->addChild(layer->m_objectLayer);
    auto node = [&] { auto* n = CCNode::create(); layer->m_objectLayer->addChild(n); return n; };
    layer->m_areaTransformNode = node(); layer->m_areaSkewNode = node();
    layer->m_areaScaleNode = node(); layer->m_areaRotateNode = node(); layer->m_areaTransformNode2 = node();
    layer->m_gameState.m_commandIndex = 19;
    layer->m_rotatedCount = 0;
    layer->m_movedCount = 0;
    layer->m_sectionXFactor = 0.01f; layer->m_sectionYFactor = 0.01f;
    layer->m_objectLayer->setPosition({7.25f, -4.5f});
    layer->m_objectLayer->setScaleX(1.25f); layer->m_objectLayer->setScaleY(0.75f);
    auto* group = layer->getGroup(7);
    auto* optimized = layer->getOptimizedGroup(7);
    log::debug("Scheduler proof group tables initialized");
    for (unsigned i = 0; i < count; ++i) {
        auto* object = GameObject::createWithKey(1757);
        object->m_isDecoration2 = scenario == 0 || i % 2 == 0;
        object->m_objectType = object->m_isDecoration2 || scenario >= 9 ? GameObjectType::Decoration : GameObjectType::Solid;
        object->m_isTrigger = object->m_isStartPos = object->m_hasGroupParent = object->m_hasAreaParent = false;
        object->m_parentMode = 0;
        object->m_linkedGroup = 0;
        object->m_useObjectRect = scenario == 1;
        if (scenario == 1) {
            object->m_hasContentSize = true;
            object->m_contentSize = CCSize(30.f, 8.f);
        }
        object->m_positionX = 10000.125 + i * 0.123456789;
        object->m_positionY = -7.25 + i * 2.125;
        object->m_positionXOffset = 3.25f; object->m_positionYOffset = -2.5f;
        object->m_canRotateFree = i % 3 != 0;
        object->m_isDontEnter = true; object->m_isDontFade = true;
        object->m_tempOffsetXRelated = i % 5 == 0;
        object->m_unk4C4 = 18; object->m_uniqueID = i + 1;
        object->m_outerSectionIndex = -1; object->m_middleSectionIndex = -1;
        object->setRotationX(7.25f); object->setRotationY(9.5f);
        group->addObject(object); optimized->addObject(object); layer->objects.push_back(object);
        if (scenario == 1 && i % 2) layer->getStaticGroup(7)->addObject(object);
        if (scenario == 4 || scenario == 8 || scenario == 10) {
            layer->getGroup(8)->addObject(object);
            layer->getOptimizedGroup(8)->addObject(object);
        }
        if (scenario == 10) {
            layer->getGroup(11)->addObject(object); layer->getOptimizedGroup(11)->addObject(object);
        }
    }
    log::debug("Scheduler proof fixture objects initialized");
    auto* center = GameObject::createWithKey(1757);
    center->m_positionX = 137.125; center->m_positionY = -33.75;
    center->m_positionXOffset = 1.5f; center->m_positionYOffset = -2.25f;
    layer->getGroup(9)->addObject(center); layer->getStaticGroup(9)->addObject(center);
    if (scenario == 7 || scenario == 10) {
        for (auto* object : layer->objects) {
            object->m_outerSectionIndex = 100; object->m_middleSectionIndex = 0;
        }
    }
    if (scenario == 8) layer->getGroup(10)->addObject(layer->objects.front());
    if(scenario==12){
        auto* object=GameObject::createWithKey(1757);
        object->m_objectType=GameObjectType::Solid;object->m_canRotateFree=false;
        object->m_positionX=123.25;object->m_positionY=-5.5;
        object->m_uniqueID=count+1;object->m_outerSectionIndex=-1;object->m_middleSectionIndex=-1;
        layer->getGroup(8)->addObject(object);layer->getOptimizedGroup(8)->addObject(object);
        layer->objects.push_back(object);
    }
    for (unsigned index = 0; index < (scenario == 10 ? 3u : scenario == 4 || scenario == 5 || scenario == 8 || scenario == 12 ? 2u : 1u); ++index) {
        auto* action = new GroupCommandObject2();
        action->m_targetGroupID = scenario == 10 ? (index == 0 ? 7 : index == 1 ? 8 : 11) : (scenario == 4 || scenario == 8) && index ? 8 : 7;
        action->m_centerGroupID = scenario == 2 ? 0 : scenario == 8 && index ? 10 : 9;
        if(scenario==12 && index){action->m_targetGroupID=8;action->m_centerGroupID=0;}
        action->m_someInterpValue1RelatedFalse = false; action->m_finishRelated = scenario == 3;
        action->m_lockObjectRotation = scenario == 6;
        writeAction<double>(action, 0xa0, scenario == 3 ? 0.5 : 17.75 + index * 3.25);
        writeAction<double>(action, 0xa8, scenario == 3 ? 0.5 : 11.25 + index * 2.5);
        writeAction<double>(action, 0x110, 0.5);
        writeAction<double>(action, 0x118, 0.5);
        layer->m_effectManager->m_unkVector5b0.push_back(action);
        layer->m_effectManager->m_unkMap5c8[action->m_targetGroupID].push_back(action);
        if (scenario == 5) layer->m_effectManager->m_unkMap770[{7, 9}].push_back(action);
    }
    auto* effectBytes = reinterpret_cast<unsigned char*>(layer->m_effectManager);
    auto* head = *reinterpret_cast<void**>(effectBytes + 0x688);
    auto* next = *reinterpret_cast<void**>(head);
    auto& typed = layer->m_effectManager->m_unkMap5c8.begin()->second;
    log::debug("Scheduler fixture native map head={} next={} node_vector_begin={} node_vector_end={} typed_begin={} typed_end={}",
        head, next, *reinterpret_cast<void**>(static_cast<unsigned char*>(next) + 0x18),
        *reinterpret_cast<void**>(static_cast<unsigned char*>(next) + 0x20),
        static_cast<void*>(typed.data()), static_cast<void*>(typed.data() + typed.size()));
    return layer;
}
bool same(SchedulerFixture* a, SchedulerFixture* b, bool consolidated = false) {
    if ((!consolidated && a->events != b->events) || a->m_rotatedCount != b->m_rotatedCount || a->m_movedCount != b->m_movedCount ||
        a->m_objectLayer->getPosition() != b->m_objectLayer->getPosition() ||
        a->m_objectLayer->getScaleX() != b->m_objectLayer->getScaleX() ||
        a->m_objectLayer->getScaleY() != b->m_objectLayer->getScaleY()) {
        for (std::size_t i = 0; i < std::min(a->events.size(), b->events.size()); ++i) {
            if (a->events[i] == b->events[i]) continue;
            const auto& x = a->events[i];
            const auto& y = b->events[i];
            log::error("Scheduler parity callback={} id={}/{} position_bits=({},{})/({},{}) rotation=({},{})/({},{})",
                i, x.id, y.id, x.x, x.y, y.x, y.y, x.rotationX, x.rotationY, y.rotationX, y.rotationY);
            break;
        }
        log::error("Scheduler parity outer state differs events={}/{} rotated={}/{} root_position=({},{})/({},{}) root_scale=({},{})/({},{})",
            a->events.size(), b->events.size(), a->m_rotatedCount, b->m_rotatedCount,
            a->m_objectLayer->getPositionX(), a->m_objectLayer->getPositionY(),
            b->m_objectLayer->getPositionX(), b->m_objectLayer->getPositionY(),
            a->m_objectLayer->getScaleX(), a->m_objectLayer->getScaleY(),
            b->m_objectLayer->getScaleX(), b->m_objectLayer->getScaleY());
        return false;
    }
    for (std::size_t i = 0; i < a->objects.size(); ++i) {
        auto* x = a->objects[i]; auto* y = b->objects[i];
        if (a->emulateVisualFinalizer && x->getPosition() != y->getPosition()) {
            log::error("Scheduler parity object={} sprite position differs", i);
            return false;
        }
        const auto nativeState = objectState(x);
        const auto replacementState = objectState(y);
        if (nativeState != replacementState) {
            static constexpr std::array fields{"position_x_bits", "position_y_bits", "rotation_x", "rotation_y",
                "rotation_x_offset", "rotation_y_offset", "history_x", "history_y", "history_stamp", "dirty",
                "object_position_dirty", "unmodified_position_dirty", "rect_dirty", "obb_dirty", "outer_obb", "finished"};
            [&]<std::size_t... I>(std::index_sequence<I...>) {
                ((std::get<I>(nativeState) != std::get<I>(replacementState) ?
                    (void)log::error("Scheduler parity object={} field={} native={} replacement={}",
                        i, fields[I], std::get<I>(nativeState), std::get<I>(replacementState)) : (void)0), ...);
            }(std::make_index_sequence<std::tuple_size_v<decltype(nativeState)>>{});
            return false;
        }
        if ((x->m_orientedBox == nullptr) != (y->m_orientedBox == nullptr)) {
            log::error("Scheduler parity object={} OBB presence differs", i);
            return false;
        }
        if (x->m_orientedBox && (x->m_orientedBox->m_corners != y->m_orientedBox->m_corners ||
            x->m_orientedBox->m_positions != y->m_orientedBox->m_positions ||
            x->m_orientedBox->m_center != y->m_orientedBox->m_center)) {
            log::error("Scheduler parity object={} OBB geometry differs", i);
            return false;
        }
    }
    for (std::size_t i = 0; i < a->m_effectManager->m_unkVector5b0.size(); ++i) {
        auto* x = a->m_effectManager->m_unkVector5b0[i];
        auto* y = b->m_effectManager->m_unkVector5b0[i];
        if (x->m_someInterpValue1RelatedFalse != y->m_someInterpValue1RelatedFalse || x->m_stepStamp != y->m_stepStamp) {
            log::error("Scheduler parity action={} claimed={}/{} stamp={}/{}", i,
                x->m_someInterpValue1RelatedFalse, y->m_someInterpValue1RelatedFalse, x->m_stepStamp, y->m_stepStamp);
            return false;
        }
    }
    return true;
}

bool runCullingBudgetProof() {
    auto* native = fixture(9), *candidate = fixture(9);
    native->emulateVisualFinalizer = candidate->emulateVisualFinalizer = true;
    cullingProofViewport = TransformBounds{-1'000'000, -1'000'000, -900'000, -900'000};
    for (unsigned step = 0; step < 12; ++step) {
        for (auto* layer : {native, candidate}) {
            layer->m_gameState.m_commandIndex = 19 + step;
            for (auto* action : layer->m_effectManager->m_unkVector5b0) action->m_someInterpValue1RelatedFalse = false;
        }
        mode = Mode::nativeProof; nativeProbeEntries = 0; nativeProbeRecursed = false;
        native->moveObjects(native->getOptimizedGroup(7), 2.25, -1.125, false);
        native->processRotationActions();
        mode = Mode::cullingProof;
        if (!tryVisualMoveObjects(candidate, candidate->getOptimizedGroup(7), 2.25, -1.125)) return false;
        if (!execute(candidate)) return false;
        flushVisualStream(false);
    }
    const bool budgetExercised = visual.culledInputs > 0 && visual.budgetResolutions > 0 && visual.gpuBatches > 0;
    flushVisualStream(true);
    for (auto* object : native->objects)
        object->cocos2d::CCSprite::setPosition({static_cast<float>(object->m_positionX), static_cast<float>(object->m_positionY)});
    const bool passed = budgetExercised && !visual.cullingFailed && !visual.failed && visual.actions.empty() && same(native, candidate, true);
    log::info("VULKANIZER_CULLING_BUDGET_PROOF result={} deferred_object_windows={} deferred_operations={} budget_resolutions={} gpu_batches={} queue_empty={}",
        passed ? "PASS" : "FAIL", visual.culledInputs, visual.deferredOperations, visual.budgetResolutions, visual.gpuBatches, visual.actions.empty());
    cullingProofViewport.reset();
    return passed;
}
}

bool runRotationSchedulerProof() {
    if (verified) return verified == 1;
    {
        AdaptiveCulling policy;
        std::uint64_t visits = 0;
        for (int i = 0; i < 120; ++i) { visits += 1000; policy.record(2.0, visits, true); }
        if (policy.enabled) return false;
        for (int i = 0; i < 120; ++i) { visits += 1000; policy.record(1.0, visits, true); }
        if (policy.enabled || !policy.baselineMeasured) return false;
        for (int i = 0; i < 840; ++i) { visits += 1000; policy.record(1.0, visits, true); }
        if (!policy.enabled) return false;
        for (int i = 0; i < 120; ++i) { visits += 1000; policy.record(0.5, visits, true); }
        if (policy.enabled) return false;
        for (int i = 0; i < 120; ++i) { visits += 1000; policy.record(1.0, visits, true); }
        if (!policy.enabled) return false;
        log::info("VULKANIZER_ADAPTIVE_CULLING_PROOF PASS switching=measured_cost hysteresis=10_percent reprobe_frames=960");
    }
    // Real process regression for the large-batch radix route: mixed actions,
    // original ordinals, maximum integer values and repeated scratch reuse.
    for (unsigned count : {31u, 4096u, 16385u}) {
        std::vector<SectionTransition> input, scratch;
        std::uint32_t seed = 0x91abcdu;
        for (unsigned i = 0; i < count; ++i) {
            seed = seed * 1664525u + 1013904223u;
            input.push_back({seed % 16384, i, i, {}, false});
        }
        input.front().action = UINT32_MAX; input.front().order = UINT32_MAX;
        auto expected = input;
        std::stable_sort(expected.begin(), expected.end(), [](auto const& a, auto const& b) {
            return std::tie(a.action, a.order) < std::tie(b.action, b.order);
        });
        sortSectionTransitions(input, scratch); sortSectionTransitions(input, scratch);
        for (std::size_t i = 0; i < input.size(); ++i)
            if (input[i].object != expected[i].object) return false;
    }
    if (verified) return verified == 1;
    verified = -1;
    log::info("VULKANIZER_SCHEDULER_PROOF begin actual_native_scheduler_comparison=true");
    for (unsigned scenario = 0; scenario < 13; ++scenario) {
        for (auto candidateMode : {Mode::cpuProof, Mode::gpuProof, Mode::batchProof, Mode::streamProof, Mode::cullingProof}) {
            const bool deferredMode = candidateMode == Mode::streamProof || candidateMode == Mode::cullingProof;
            if (scenario >= 7 && candidateMode != Mode::batchProof && !deferredMode) continue;
            if (candidateMode == Mode::cullingProof && scenario != 0 && scenario < 7) continue;
            auto* native = fixture(scenario);
            auto* candidate = fixture(scenario);
            native->emulateVisualFinalizer = candidate->emulateVisualFinalizer = deferredMode;
            cullingProofViewport = candidateMode == Mode::cullingProof ?
                std::optional<TransformBounds>{{-1'000'000, -1'000'000, -900'000, -900'000}} : std::nullopt;
            if (!same(native, candidate)) {
                log::error("VULKANIZER_SCHEDULER_PARITY FAIL scenario={} reason=fixture_inputs_differ_before_execution", scenario);
                mode = Mode::live;
                return false;
            }
            for (unsigned step = 0; step < 3; ++step) {
                for (auto* layer : {native, candidate}) {
                    layer->events.clear();
                    layer->m_gameState.m_commandIndex = 19 + step;
                    if (scenario == 1) {
                        // Emulate collision caches consumed after the previous
                        // tick. Default-dirty fixtures cannot expose a missing
                        // invalidation on an already-created oriented box.
                        for (auto* object : layer->objects) {
                            if (object->m_objectType == GameObjectType::Decoration) continue;
                            object->m_shouldUseOuterOb = true;
                            object->m_isObjectRectDirty = false;
                            object->m_isOrientedBoxDirty = false;
                        }
                    }
                    for (auto* action : layer->m_effectManager->m_unkVector5b0)
                        action->m_someInterpValue1RelatedFalse = false;
                    if (scenario == 4 && step == 1) {
                        auto* array = layer->getOptimizedGroup(8);
                        std::swap(array->data->arr[0], array->data->arr[1]);
                    }
                }
                mode = Mode::nativeProof;
                nativeProbeEntries = 0;
                nativeProbeRecursed = false;
                if (deferredMode) native->moveObjects(native->getOptimizedGroup(7), 2.25 - step * 1.5, -1.125, false);
                log::debug("Scheduler proof native enter scenario={} step={}", scenario, step);
                native->processRotationActions();
                log::debug("Scheduler proof native exit scenario={} step={}", scenario, step);
                mode = candidateMode;
                if (deferredMode && !tryVisualMoveObjects(candidate, candidate->getOptimizedGroup(7), 2.25 - step * 1.5, -1.125))
                    candidate->moveObjects(candidate->getOptimizedGroup(7), 2.25 - step * 1.5, -1.125, false);
                const auto beforeExecutions = proofExecutions;
                const auto beforeGpuBatches = proofGpuBatches;
                const auto beforeBatchWrites = batchCounters.positionWrites;
                const auto beforeBatchVisits = batchCounters.referenceVisits;
                // Inside the live processRotationActions hook, Geode suppresses
                // reentrant detours. Call our implementation directly so the
                // candidate cannot silently execute the native control again.
                const bool handled = execute(candidate);
                bool requiredStateMatches = true;
                if (scenario == 11 && deferredMode && step == 1) {
                    DynamicMoveCalculation calculation{};
                    calculation.m_gameObject = candidate->objects[2];
                    candidate->m_effectManager->m_unkVector708.push_back(calculation);
                    prepareVisualMoveDependencies(candidate);
                    candidate->m_effectManager->m_unkVector708.clear();
                    requiredStateMatches = candidate->objects[2]->m_positionX == native->objects[2]->m_positionX &&
                        candidate->objects[2]->m_positionY == native->objects[2]->m_positionY &&
                        candidate->objects[2]->m_rotationXOffset == native->objects[2]->m_rotationXOffset;
                }
                if (candidateMode == Mode::cullingProof && step < 2) flushVisualStream(false);
                const bool cullingDeferred = candidateMode != Mode::cullingProof || (scenario != 0 && scenario != 9) || step == 2 ||
                    (visual.gpuBatches == 0 && visual.culledInputs > 0);
                const bool compareNow = !deferredMode || step == 2;
                if (deferredMode && step == 2) {
                    if (candidateMode == Mode::cullingProof) {
                        // Move and zoom the actual Cocos viewport over the result.
                        const auto size = CCDirector::sharedDirector()->getWinSize();
                        for (auto* layer : {native, candidate}) {
                            layer->m_objectLayer->setScale(0.5f);
                            layer->m_objectLayer->setPosition({size.width / 2 - static_cast<float>(native->objects[0]->m_positionX) * 0.5f,
                                size.height / 2 - static_cast<float>(native->objects[0]->m_positionY) * 0.5f});
                        }
                        cullingProofViewport.reset();
                        flushVisualStream(false);
                    } else flushVisualStream();
                    // Model the normal visible-frame propagation for native and
                    // CPU-owned objects. GPU-owned sprites must already match.
                    for (auto* object : native->objects)
                        object->cocos2d::CCSprite::setPosition({static_cast<float>(object->m_positionX), static_cast<float>(object->m_positionY)});
                    for (auto* object : candidate->objects) {
                        if (visual.allowed && visual.objectIndices.contains(object)) continue;
                        object->cocos2d::CCSprite::setPosition({static_cast<float>(object->m_positionX), static_cast<float>(object->m_positionY)});
                    }
                }
                if (scenario == 0 && step == 0 && candidateMode == Mode::cpuProof) {
                    log::info("VULKANIZER_SCHEDULER_PROOF_CONTEXT native_hook_entries={} replacement_executions={} candidate_entry=direct_implementation",
                        nativeProbeEntries, proofExecutions - beforeExecutions);
                }
                log::debug("Scheduler proof candidate exit scenario={} step={}", scenario, step);
                const bool expectedGpu = candidateMode == Mode::gpuProof && scenario != 2;
                const bool batchingReducedWrites = candidateMode != Mode::batchProof || scenario != 4 ||
                    batchCounters.positionWrites - beforeBatchWrites < batchCounters.referenceVisits - beforeBatchVisits;
                const bool streamActive = !deferredMode || scenario != 0 || step != 2 ||
                    (visual.gpuBatches > 0 && visual.checking && !visual.failed && visual.stateWrites < visual.logicalVisits);
                const bool overflowCovered = !deferredMode || scenario != 10 || step != 2 || visual.replayedVisits > 0;
                const bool selectiveBarrierCovered = scenario!=12 || !deferredMode || visual.group575UnrelatedBarriersAvoided>=step+1;
                if (!handled || !selectiveBarrierCovered || !requiredStateMatches || !cullingDeferred || visual.cullingFailed ||
                    (compareNow && !same(native, candidate, candidateMode == Mode::batchProof || deferredMode)) || runtimeFailed || nativeProbeRecursed || proofExecutions != beforeExecutions + 1 ||
                    !overflowCovered || !streamActive || !batchingReducedWrites || (expectedGpu && proofGpuBatches == beforeGpuBatches)) {
                    log::error("VULKANIZER_SCHEDULER_PARITY FAIL scenario={} step={} mode={} native_events={} candidate_events={} native_rotated={} candidate_rotated={} handled={} executions={} native_recursed={} gpu_failed={}",
                        scenario, step, candidateMode == Mode::cpuProof ? "CPU" : candidateMode == Mode::batchProof ? "BATCH" : candidateMode == Mode::streamProof ? "STREAM" : candidateMode == Mode::cullingProof ? "CULL" : "GPU", native->events.size(), candidate->events.size(),
                        native->m_rotatedCount, candidate->m_rotatedCount, handled,
                        proofExecutions - beforeExecutions, nativeProbeRecursed, runtimeFailed);
                    mode = Mode::live;
                    return false;
                }
            }
        }
    }
    if (!runCullingBudgetProof()) {
        mode = Mode::live; visual = {}; cullingProofViewport.reset();
        return false;
    }
    mode = Mode::live;
    verified = 1;
    log::info("VULKANIZER_SCHEDULER_PARITY PASS source=actual_processRotationActions scenarios=13 steps=3 modes=CPU,GPU,BATCH,STREAM,CULL gpu_batches={} checks=positions,rotation,history,dirty_flags,callbacks,stamps,claims,counts,root_restore; static,optimized,overlap,aggregation,zero,lock,no_center,section_crossing,pivot_dependency,mixed_move_rotation,active_decoration_history,section_event_overflow,required_move_state,offscreen_to_visible,zoom,disjoint_cpu_rotation_barrier",
        proofGpuBatches);
    log::info("VULKANIZER_BATCH_PROOF logical_visits={} position_writes={} section_calls_avoided={} cache_hits={} cache_misses={} barriers={}",
        batchCounters.referenceVisits, batchCounters.positionWrites, batchCounters.sectionCallsAvoided,
        batchCounters.cacheHits, batchCounters.cacheMisses, batchCounters.barriers);
    batchCounters = {};
    plans.clear(); planOwner = nullptr;
    visual = {};
    cullingProofViewport.reset();
    return true;
}

void runRotationSchedulerBenchmarks() {
    if (!runRotationSchedulerProof()) return;
    for (unsigned count : {128u, 1024u, 8192u}) {
        for (auto selected : {Mode::nativeProof, Mode::cpuProof, Mode::gpuProof}) {
            auto* layer = fixture(0, count);
            layer->record = false;
            mode = selected;
            auto start = Clock::now();
            for (unsigned i = 0; i < 32; ++i) {
                nativeProbeEntries = 0;
                nativeProbeRecursed = false;
                for (auto* action : layer->m_effectManager->m_unkVector5b0) action->m_someInterpValue1RelatedFalse = false;
                layer->processRotationActions();
            }
            const double elapsed = ms(start);
            const bool valid = layer->m_rotatedCount == static_cast<int>(count * 32) && !nativeProbeRecursed && !runtimeFailed;
            log::info("VULKANIZER_SCHEDULER_BENCH mode={} objects={} calls=32 wall_ms={:.4f} position_visits={} valid={} source=actual_processRotationActions callbacks=scratch",
                selected == Mode::nativeProof ? "native" : selected == Mode::cpuProof ? "CPU" : "GPU", count, elapsed,
                layer->m_rotatedCount, valid);
        }
    }
    mode = Mode::live;
}

bool startSchedulerGameplayTest() {
    if (std::getenv("VULKANIZER_SCHEDULER_FIXED_INPUT")) {
        log::error("VULKANIZER_GAMEPLAY_TEST_REJECTED obsolete fixed-input override; no game timing was modified");
        return false;
    }
    if (!std::getenv("VULKANIZER_SCHEDULER_GAMEPLAY_TEST")) return false;
    if (!nativeGameplayBaseline() && verified != 1 && !std::getenv("VULKANIZER_SCHEDULER_DEFER_PROOF")) return false;
    auto* levels = LocalLevelManager::sharedState()->getCreatedLevels(0);
    if (!levels) return false;
    const char* requestedName = std::getenv("VULKANIZER_TEST_LEVEL_NAME");
    for (auto* level : CCArrayExt<GJGameLevel, false>(levels)) {
        auto name = level->m_levelName;
        std::transform(name.begin(), name.end(), name.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
        if (requestedName && *requestedName) {
            if (level->m_levelName != requestedName) continue;
        } else if (name.find("peaceful") == std::string::npos) continue;
        log::info("VULKANIZER_SCHEDULER_GAMEPLAY_TEST starting existing local level={} objects_created_by=PlayLayer::scene", level->m_levelName);
        gameplayTest = true; gameplayTestStart = Clock::now();
        gameplayPhysicsSteps = 0;
        if (auto* duration = std::getenv("VULKANIZER_SCHEDULER_TEST_SECONDS"))
            gameplayTestDurationMs = std::clamp(std::atof(duration), 5.0, 90.0) * 1000.0;
        liveEntries = liveObjects = liveGpuObjects = livePositionObjects = 0; liveMs = 0;
        liveGpuApplied = false;
        auto* scene = PlayLayer::scene(level, false);
        if (!scene) { gameplayTest = false; return false; }
        CCDirector::sharedDirector()->replaceScene(scene);
        // Level loading can consume most of a short test's wall-time budget.
        gameplayTestStart = Clock::now();
        return true;
    }
    log::error("VULKANIZER_SCHEDULER_GAMEPLAY_TEST requested local level not found; no gameplay activation claimed");
    return false;
}

void pollSchedulerGameplayTest() {
    if (!gameplayTest) return;
    const auto elapsed = ms(gameplayTestStart);
    struct FrameSample { double wall, level, delta; std::uint64_t ticks; };
    static std::vector<FrameSample> samples;
    static double previous = 0;
    if (auto* layer = PlayLayer::get()) {
        if (elapsed < previous) { samples.clear(); previous = 0; }
        if (previous) samples.push_back({elapsed, layer->m_gameState.m_levelTime, elapsed - previous, gameplayPhysicsSteps});
        previous = elapsed;
    }
    const bool activated = nativeGameplayBaseline() ? gameplayPhysicsSteps >= 240 : livePositionObjects > 0 && liveGpuObjects > 0 && liveEntries >= 8;
    if ((activated && elapsed > gameplayTestDurationMs) || elapsed > gameplayTestDurationMs + 30000) {
        const bool passed = PlayLayer::get() != nullptr && activated;
        log::info("VULKANIZER_SCHEDULER_GAMEPLAY_TEST result={} real_PlayLayer={} scheduler_entries={} object_visits={} position_visits={} gpu_objects={} elapsed_ms={:.1f}",
            passed ? "PASS" : "FAIL", PlayLayer::get() != nullptr,
            liveEntries, liveObjects, livePositionObjects, liveGpuObjects, elapsed);
        log::info("VULKANIZER_GAMEPLAY_TEST_MODE native_baseline={} physics_steps={} timing_override=false", nativeGameplayBaseline(), gameplayPhysicsSteps);
        if(transformCostDiagnostics()) logMoveFallbackAttribution();
        if (auto* path = std::getenv("VULKANIZER_BENCHMARK_FRAME_FILE")) {
            std::ofstream file(path);
            file << "wall_ms,level_time,frame_ms,physics_steps\n";
            for (auto const& sample : samples)
                file << fmt::format("{:.6f},{:.9f},{:.6f},{}\n", sample.wall, sample.level, sample.delta, sample.ticks);
        }
        gameplayTest = false;
        PostMessageW(WindowFromDC(wglGetCurrentDC()), WM_CLOSE, 0, 0);
    }
}
void resetRotationPlans() {
    plans.clear(); planOwner = nullptr;
    visual = {};
}
void enterNativeMoveAttribution(){++nativeMoveAttributionDepth;}
void leaveNativeMoveAttribution(){if(nativeMoveAttributionDepth)--nativeMoveAttributionDepth;}
void precompileLevelTransforms(GJBaseGameLayer* layer) {
    if (transformCostDiagnostics() && layer && layer->m_objects) {
        struct Bin { std::array<std::uint64_t, 5> categories{}; std::uint64_t touch=0, spawn=0, updates=0, dependencies=0; float maxDuration=0; };
        std::map<int, Bin> bins;
        for (auto* object : CCArrayExt<GameObject, false>(layer->m_objects)) {
            if (!object || !object->m_isTrigger || object->m_isStartPos) continue;
            auto* effect = typeinfo_cast<EffectGameObject*>(object);
            if (!std::isfinite(object->m_positionX) || std::abs(object->m_positionX) > 1e8) continue;
            auto& bin = bins[static_cast<int>(std::floor(object->m_positionX / 3000.0))];
            unsigned category = 4;
            if (effect) {
                bin.touch += effect->m_isTouchTriggered; bin.spawn += effect->m_isSpawnTriggered;
                if (std::isfinite(effect->m_duration)) bin.maxDuration=std::max(bin.maxDuration,effect->m_duration);
                const bool dependent = effect->m_isDynamicMode || effect->m_useMoveTarget || effect->m_targetPlayer1 || effect->m_targetPlayer2 ||
                    effect->m_lockToPlayerX || effect->m_lockToPlayerY || effect->m_lockToCameraX || effect->m_lockToCameraY;
                if (object->m_objectID == 901) category = dependent ? 3 : 0;
                else if (object->m_objectID == 1346) category = dependent ? 3 : 1;
                else if (object->m_objectID == 899 || object->m_objectID == 1006 || object->m_objectID == 1007) category = 2;
                else if (object->m_objectID == 1049 || object->m_objectID == 1268 || object->m_objectID == 1616) category = 3;
                bin.dependencies += effect->m_centerGroupID > 0 || effect->m_rotationTargetID > 0 || dependent;
                const int target=effect->m_targetGroupID;
                if (target > 0 && static_cast<std::size_t>(target) < layer->m_groups.size() && layer->m_groups[target])
                    bin.updates += layer->m_groups[target]->count();
            }
            ++bin.categories[category];
        }
        for (auto const& [index, bin] : bins)
            log::info("VULKANIZER_STATIC_CENSUS x_begin={} x_end={} A={} B={} C_potential={} D={} E={} touch={} spawn={} target_member_sum={} max_duration_s={} dependency_refs={} semantics=position_bins_not_native_timeline_or_activation_prediction",
                index*3000, (index+1)*3000, bin.categories[0],bin.categories[1],bin.categories[2],bin.categories[3],bin.categories[4],bin.touch,bin.spawn,bin.updates,bin.maxDuration,bin.dependencies);
    }
    if (!Mod::get()->getSettingValue<bool>("experimental-level-precompile") ||
        !RendererManager::get().gpuTransformAllRequested() || !RendererManager::get().gpuTransformReady() ||
        !layer || layer->m_loadingStartPosition || !layer->m_objects || !layer->m_effectManager ||
        layer->m_groups.size() < 10000 || layer->m_staticGroups.size() < 10000 || layer->m_optimizedGroups.size() < 10000) return;
    const auto started = Clock::now();
    precompilingVisual = true;
    auditVisualDependencies(layer);
    if (visual.allowed) {
        // Compile a bounded hot set first. Other targets retain the existing
        // lazy cache path, including touch/spawn-dependent activations.
        std::unordered_map<int, std::uint32_t> targetFrequency;
        for (auto* object : CCArrayExt<GameObject, false>(layer->m_objects)) {
            if (!object || !object->m_isTrigger || (object->m_objectID != 901 && object->m_objectID != 1346)) continue;
            if (auto* effect = typeinfo_cast<EffectGameObject*>(object); effect && effect->m_targetGroupID > 0 && effect->m_targetGroupID < 10000)
                ++targetFrequency[effect->m_targetGroupID];
        }
        std::vector<std::pair<int, std::uint64_t>> ranked;
        for (auto const& [id, frequency] : targetFrequency) {
            auto* statics = layer->m_staticGroups[id];
            auto* array = statics && statics->count() ? layer->m_groups[id] : layer->m_optimizedGroups[id];
            if (array && array->count()) ranked.emplace_back(id, static_cast<std::uint64_t>(frequency) * array->count());
        }
        std::sort(ranked.begin(), ranked.end(), [](auto const& a, auto const& b) {
            return a.second != b.second ? a.second > b.second : a.first < b.first;
        });
        constexpr std::size_t maxPreparedGroups = 64;
        const auto selected = std::min(ranked.size(), maxPreparedGroups);
        for (std::size_t i = 0; i < selected; ++i) {
            const int id = ranked[i].first;
            auto* statics = layer->m_staticGroups[id];
            auto* array = statics && statics->count() ? layer->m_groups[id] : layer->m_optimizedGroups[id];
            visualGroup(layer, array);
        }
        buildVisualCombinations();
        log::info("VULKANIZER_LEVEL_PRECOMPILE result=ready target_groups={} selected_groups={} cached_arrays={} objects={} combinations={} elapsed_ms={:.3f} dynamic_membership_validation=true remaining=lazy", targetFrequency.size(), selected, visual.groups.size(), visual.objects.size(), visual.combinations.size(), ms(started));
    } else log::info("VULKANIZER_LEVEL_PRECOMPILE result=fallback reason=unsupported_dependency elapsed_ms={:.3f}", ms(started));
    precompilingVisual = false;
}
void flushPendingVisualTransforms(GJBaseGameLayer* layer, bool force) {
    if (visual.owner == layer) flushVisualStream(force);
}
void prepareVisualMoveDependencies(GJBaseGameLayer* layer) {
    if (visual.owner != layer || !visual.allowed || !layer->m_effectManager) return;
    for (auto const& calculation : layer->m_effectManager->m_unkVector708) {
        auto* object = calculation.m_gameObject;
        if (!object || visual.anchors.contains(object)) continue;
        const auto found = visual.objectIndices.find(object);
        if (found == visual.objectIndices.end()) { visual.anchors.insert(object); continue; }
        // processMoveActions reads this object's authoritative rotation offset
        // before resolving the movement delta. Resolve before that read.
        flushVisualStream();
        visual.anchors.insert(object);
        const auto id = found->second;
        for (auto groupIndex : visual.memberships[id]) {
            auto& group = visual.groups[groupIndex];
            group.visualObjects.erase(std::remove(group.visualObjects.begin(), group.visualObjects.end(), id), group.visualObjects.end());
            group.order.erase(id);
            group.cpu = CCArray::create();
            group.rejectionCounts.clear();
            for (auto* member : group.snapshot)
                if(auto reason=visualObjectRejection(member);!reason.empty()){group.cpu->addObject(member);++group.rejectionCounts[rejectionCounterKey(member,reason)];}
        }
        visual.memberships[id].clear(); visual.dirtyObjects.push_back(id); visual.topologyDirty = true;
        log::info("VULKANIZER_VISUAL_DEPENDENCY resolved_dynamic_move_anchor object_id={}", object->m_objectID);
    }
}
namespace {
struct SpeedAudit {
    PlayLayer* layer = nullptr;
    GameplaySpeedWindow counts;
    Clock::time_point start;
    double levelStart = 0;
    unsigned musicStart = 0;
    bool active = false;
} speedAudit;
bool speedAuditRequested() {
    static const bool requested = std::getenv("VULKANIZER_GAMEPLAY_SPEED_AUDIT") ||
        std::getenv("VULKANIZER_SCHEDULER_GAMEPLAY_TEST") || Mod::get()->getSettingValue<bool>("transform-cost-diagnostics");
    return requested;
}
}
void recordGameplayFrameInput(float dt) {
    if (!speedAuditRequested()) return;
    auto* layer = PlayLayer::get();
    if (!layer || layer->m_loadingStartPosition || layer->m_isPaused) { speedAudit = {}; return; }
    if (!speedAudit.active || speedAudit.layer != layer) {
        speedAudit = {}; speedAudit.active = true; speedAudit.layer = layer;
        speedAudit.start = Clock::now(); speedAudit.levelStart = layer->m_gameState.m_levelTime;
        speedAudit.musicStart = FMODAudioEngine::sharedEngine()->getMusicTimeMS(0);
    }
    speedAudit.counts.frame(dt);
}
void recordGameplayPhysicsInput(GJBaseGameLayer* layer, float dt) {
    if (gameplayTest && static_cast<GJBaseGameLayer*>(PlayLayer::get()) == layer) ++gameplayPhysicsSteps;
    if (!speedAuditRequested() || !speedAudit.active || speedAudit.layer != layer) return;
    speedAudit.counts.tick(dt);
}
void recordGameplayFrameComplete() {
    if (!speedAuditRequested() || !speedAudit.active) return;
    auto* layer = PlayLayer::get();
    if (!layer || speedAudit.layer != layer || layer->m_loadingStartPosition || layer->m_isPaused) { speedAudit = {}; return; }
    const auto wall = ms(speedAudit.start) / 1000.0;
    if (wall < 2) return;
    const auto level = layer->m_gameState.m_levelTime - speedAudit.levelStart;
    const auto music = FMODAudioEngine::sharedEngine()->getMusicTimeMS(0);
    const double musicDelta = (static_cast<double>(music) - speedAudit.musicStart) / 1000.0;
    const auto& count = speedAudit.counts;
    const bool normalWindow = level >= 0 && level <= wall * 2 && layer->m_gameState.m_levelTime >= 61;
    const auto warp = layer->m_gameState.m_timeWarp;
    log::info("VULKANIZER_GAMEPLAY_SPEED level_time={:.9f} wall_s={:.6f} level_s={:.6f} level_per_wall={:.6f} frames={} ticks={} ticks_per_wall={:.3f} scheduler_input_s={:.6f} physics_input_s={:.6f} physics_dt_min={:.9f} physics_dt_max={:.9f} warp={:.6f} music0_delta_s={:.6f} audio_minus_level_s={:.6f} full_speed={} comparable_window={} invalid_inputs={} timing_override=false",
        layer->m_gameState.m_levelTime, wall, level, level / wall, count.frames, count.ticks, count.ticks / wall,
        count.frameSeconds, count.physicsSeconds, count.ticks ? count.minPhysicsDelta : 0, count.maxPhysicsDelta,
        warp, musicDelta, musicDelta - level, normalWindow && count.fullSpeed(wall, level, warp), normalWindow, count.invalidInputs);
    speedAudit = {};
}
void recordTransformCheckpoint(GJBaseGameLayer* layer) {
    static const bool requested = std::getenv("VULKANIZER_TRANSFORM_CHECKPOINTS") != nullptr;
    static std::uint64_t steps = 0;
    if (!requested || PlayLayer::get() != layer || !layer->m_objects || ++steps % 240 != 0) return;
    flushPendingVisualTransforms(layer, true);
    const auto count = layer->m_objects->count();
    const auto samples = std::min(count, 4096u);
    unsigned observed = 0;
    std::uint64_t hash = 14695981039346656037ull;
    std::ofstream snapshot;
    if (auto* directory = std::getenv("VULKANIZER_TRANSFORM_SNAPSHOT_DIR"); directory && (steps == 4080 || steps == 9600)) {
        snapshot.open(std::filesystem::path(directory) / fmt::format("transform-{}-{}.csv",
            std::getenv("VULKANIZER_TRANSFORM_BATCHING_BASELINE") ? "baseline" : "optimized", steps));
        snapshot << "index,id,x_bits,y_bits,rx_offset_bits,ry_offset_bits,node_rx_bits,node_ry_bits,history_x_bits,history_y_bits,stamp,type,history_skip\n";
    }
    auto mix = [&](std::uint64_t value) { hash = (hash ^ value) * 1099511628211ull; };
    for (unsigned i = 0; i < samples; ++i) {
        auto* object = static_cast<GameObject*>(layer->m_objects->data->arr[static_cast<std::uint64_t>(i) * count / samples]);
        if (object->m_classType != GameObjectClassType::Game ||
            (object->m_objectType != GameObjectType::Solid && object->m_objectType != GameObjectType::Decoration)) continue;
        ++observed;
        if (snapshot.is_open()) snapshot << fmt::format("{},{},{:016x},{:016x},{:08x},{:08x},{:08x},{:08x},{:08x},{:08x},{},{},{}\n",
            static_cast<std::uint64_t>(i) * count / samples, object->m_objectID,
            std::bit_cast<std::uint64_t>(object->m_positionX), std::bit_cast<std::uint64_t>(object->m_positionY),
            std::bit_cast<std::uint32_t>(object->m_rotationXOffset), std::bit_cast<std::uint32_t>(object->m_rotationYOffset),
            std::bit_cast<std::uint32_t>(object->m_fRotationX), std::bit_cast<std::uint32_t>(object->m_fRotationY),
            std::bit_cast<std::uint32_t>(object->m_lastPosition.x), std::bit_cast<std::uint32_t>(object->m_lastPosition.y),
            object->m_unk4C4, static_cast<int>(object->m_objectType), object->m_isDecoration2);
        mix(object->m_objectID); mix(std::bit_cast<std::uint64_t>(object->m_positionX));
        mix(std::bit_cast<std::uint64_t>(object->m_positionY)); mix(std::bit_cast<std::uint32_t>(object->m_rotationXOffset));
        mix(std::bit_cast<std::uint32_t>(object->m_rotationYOffset));
    }
    log::info("VULKANIZER_TRANSFORM_CHECKPOINT schema=2 step={} level_time={:.9f} samples={} hash={:016x} player=({:.9f},{:.9f})",
        steps, layer->m_gameState.m_levelTime, observed, hash, layer->m_player1 ? layer->m_player1->getPositionX() : 0,
        layer->m_player1 ? layer->m_player1->getPositionY() : 0);
    if(transformCostDiagnostics())
        log::info("VULKANIZER_GROUP575_WINDOW step={} level_time={:.9f} move_fallback_nominations={} cpu_move_member_visits={} cpu_rotation_member_visits={} gpu_final_state_applications={} section_events={} replay_member_visits={} group575_gpu_move_operations={} group575_gpu_rotation_operations={} group575_final_state_applications={} unrelated_barriers_avoided={}",
            steps,layer->m_gameState.m_levelTime,visual.cpuMoveFallbackVisits,visual.cpuMoveVisits,visual.cpuRotationVisits,
            visual.stateWrites,visual.sectionEvents,visual.replayedVisits,visual.group575MoveVisits,visual.group575RotationVisits,
            visual.group575StateWrites,visual.group575UnrelatedBarriersAvoided);
    if (auto* player = layer->m_player1)
        log::info("VULKANIZER_PLAYER_CHECKPOINT step={} level_time={:.9f} x={:.9f} y={:.9f} vx={:.12f} vy={:.12f} acceleration_or_speed_raw={:.12f} speed_portal={:.9f} speed_multiplier={:.12f} speed_ac={:.9f} warp={:.9f} mode={}{}{}{}{}{} upside_down={} dead={} physics_timing=native",
            steps, layer->m_gameState.m_levelTime, player->getPositionX(), player->getPositionY(),
            player->getCurrentXVelocity(), player->m_yVelocity, player->m_accelerationOrSpeed, player->m_playerSpeed,
            player->m_speedMultiplier, player->m_playerSpeedAC, layer->m_gameState.m_timeWarp,
            player->m_isShip, player->m_isBird, player->m_isBall, player->m_isDart, player->m_isRobot, player->m_isSpider,
            player->m_isUpsideDown, player->m_isDead);
}
bool tryVisualMoveObjects(GJBaseGameLayer* layer, CCArray* objects, double dx, double dy) {
    if (dx == 0 && dy == 0) return false;
    auto* group = visualGroup(layer, objects);
    if (!group || group->visualObjects.empty()) {
        if (mode == Mode::live && visual.owner == layer && objects) {
            visual.cpuMoveVisits += objects->count(); visual.cpuMoveFallbackVisits += objects->count();
            if(transformCostDiagnostics()) {
                int sourceGroup=-1;
                const auto caller=nativeMoveCaller(layer,objects,sourceGroup);
                if(group){
                    std::uint64_t attributed=0;
                    for(auto const& [reason,count]:group->rejectionCounts){auto& entry=moveFallbackAttribution[{caller,fmt::format("{}_source_group_{}",reason,sourceGroup)}];++entry.first;entry.second+=count;attributed+=count;}
                    if(attributed<objects->count()){auto& entry=moveFallbackAttribution[{caller,"unclassified_array_members"}];++entry.first;entry.second+=objects->count()-attributed;}
                } else {
                    std::string reason=!streamRequested()?"stream_not_requested_or_not_ready":layer->m_loadingStartPosition?"startpos_loading":!visual.allowed?"dependency_audit_rejected":visual.failed?"executor_failed":layer->m_gameState.m_commandIndex>=16777216u?"command_stamp_limit":"unclassified_route";
                    auto& entry=moveFallbackAttribution[{caller,reason}];++entry.first;entry.second+=objects->count();
                }
            }
        }
        return false;
    }
    gpu::Action action{};
    action.kind = 0; action.dx = dx; action.dy = dy;
    recordVisualAction(*group, action);
    visual.group575MoveVisits+=group->group575Members;
    layer->m_movedCount += static_cast<int>(objects->count());
    if (mode == Mode::live) { visual.cpuMoveVisits += group->cpu->count(); visual.cpuMoveMixedVisits += group->cpu->count(); }
    for (auto* object : CCArrayExt<GameObject, false>(group->cpu)) {
        if (!object) break;
        preserveTransformHistory(*object, layer->m_gameState.m_commandIndex);
        if (dx != 0 && !object->m_tempOffsetXRelated) object->m_positionX += dx;
        if (dy != 0) object->m_positionY += dy;
        object->dirtifyObjectPos(); layer->updateObjectSection(object);
    }
    layer->updateDisabledObjectsLastPos(group->cpu.data());
    return true;
}
}
