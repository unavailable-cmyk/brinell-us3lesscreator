#pragma once
class GJBaseGameLayer;
class GameObject;
namespace cocos2d { class CCArray; }
namespace vulkanizer {
bool tryProcessRotationActions(GJBaseGameLayer* layer);
bool runRotationSchedulerProof();
void runRotationSchedulerBenchmarks();
bool startSchedulerGameplayTest();
void pollSchedulerGameplayTest();
void resetRotationPlans();
void precompileLevelTransforms(GJBaseGameLayer* layer);
void flushPendingVisualTransforms(GJBaseGameLayer* layer, bool force = false);
void recordTransformCheckpoint(GJBaseGameLayer* layer);
void recordGameplayFrameInput(float dt);
void recordGameplayPhysicsInput(GJBaseGameLayer* layer, float dt);
void recordGameplayFrameComplete();
void prepareVisualMoveDependencies(GJBaseGameLayer* layer);
void enterNativeMoveAttribution();
void leaveNativeMoveAttribution();
bool tryVisualMoveObjects(GJBaseGameLayer* layer, cocos2d::CCArray* objects, double dx, double dy);
}
