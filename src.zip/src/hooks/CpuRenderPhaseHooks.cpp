#include "CpuRenderPhaseHooks.hpp"
#include "backend/HybridTransformPipeline.hpp"
#include "backend/RotationScheduler.hpp"
#include "core/RendererManager.hpp"
#include "diagnostics/CpuCallbackScope.hpp"

#include <Geode/modify/CCActionManager.hpp>
#include <Geode/modify/CCNode.hpp>
#include <Geode/modify/CCScheduler.hpp>
#include <Geode/modify/CCTimer.hpp>
#include <Geode/modify/CCSprite.hpp>
#include <Geode/modify/CCSpriteBatchNode.hpp>
#include <Geode/modify/CCTextureAtlas.hpp>
#include <Geode/modify/GameObject.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>

#include <Geode/binding/GJEffectManager.hpp>

#include <algorithm>
#include <chrono>
#include <cstdint>
#include <cstdlib>

using namespace geode::prelude;
using vulkanizer::RendererManager;

namespace {
using Clock = RendererManager::Clock;
constexpr auto timerPhase = vulkanizer::SchedulerCallbackPhase::timerUpdate;
constexpr std::size_t timerPhaseIndex = static_cast<std::size_t>(timerPhase);

vulkanizer::FramePhaseSample makeEmptySample() {
    vulkanizer::FramePhaseSample sample{};
    sample.callbacks[timerPhaseIndex].estimateWeight = 8;
    return sample;
}

thread_local vulkanizer::FramePhaseSample s_sample = makeEmptySample();
thread_local unsigned s_nodeVisitDepth = 0;
thread_local std::uint64_t s_nodeVisitCalls = 0;
thread_local std::uint64_t s_spriteTransformCallIndex = 0;
thread_local std::uint64_t s_spriteDrawCallIndex = 0;
thread_local std::uint64_t s_atlasDrawCallIndex = 0;
thread_local std::uint64_t s_timerUpdateCallIndex = 0;
thread_local std::uint64_t s_moveActionSampleIndex = 0;
thread_local std::uint64_t s_rotationActionSampleIndex = 0;
thread_local vulkanizer::CpuCallbackScopeRecorder s_callbackScopeRecorder;

enum class TransformContext : std::uint8_t { none, move, rotation };
thread_local TransformContext s_transformContext = TransformContext::none;
thread_local bool s_transformTimingSampled = false;

class TransformContextScope {
public:
    TransformContextScope(TransformContext context, bool timingSampled)
      : m_previousContext(s_transformContext), m_previousTimingSampled(s_transformTimingSampled) {
        s_transformContext = context;
        s_transformTimingSampled = timingSampled;
    }
    ~TransformContextScope() {
        s_transformContext = m_previousContext;
        s_transformTimingSampled = m_previousTimingSampled;
    }
    TransformContextScope(TransformContextScope const&) = delete;
    TransformContextScope& operator=(TransformContextScope const&) = delete;

private:
    TransformContext m_previousContext;
    bool m_previousTimingSampled;
};

class CallbackProfileScope {
public:
    CallbackProfileScope(vulkanizer::SchedulerCallbackPhase phase, std::uint32_t estimateWeight = 1,
                         bool countInvocation = true, std::uint32_t parentEstimateWeight = 1)
        { s_callbackScopeRecorder.begin(m_scope, phase, Clock::now(), s_sample,
                                        estimateWeight, countInvocation, parentEstimateWeight); }

    CallbackProfileScope(CallbackProfileScope const&) = delete;
    CallbackProfileScope& operator=(CallbackProfileScope const&) = delete;

    ~CallbackProfileScope() { s_callbackScopeRecorder.end(m_scope, Clock::now(), s_sample); }

private:
    vulkanizer::CpuCallbackScopeRecorder::Token m_scope{};
};

template <class Callback>
void profileSchedulerCallback(RendererManager& manager, vulkanizer::SchedulerCallbackPhase phase,
                              Callback&& callback) {
    if (!manager.diagnosticsEnabled()) {
        callback();
        return;
    }
    CallbackProfileScope scope(phase);
    callback();
}

template <class Callback>
void profileObjectArrayCallback(RendererManager& manager, vulkanizer::SchedulerCallbackPhase phase,
                                cocos2d::CCArray* objects, Callback&& callback) {
    if (!manager.diagnosticsEnabled()) {
        callback();
        return;
    }
    const auto objectCount = static_cast<std::uint64_t>(objects ? objects->count() : 0u);
    if ((phase == vulkanizer::SchedulerCallbackPhase::moveObjects &&
         s_transformContext == TransformContext::move) ||
        (phase == vulkanizer::SchedulerCallbackPhase::rotateObjects &&
         s_transformContext == TransformContext::rotation)) {
        auto& measured = s_sample.callbacks[static_cast<std::size_t>(phase)];
        ++measured.calls;
        measured.workItems += objectCount;
        measured.estimateWeight = 64;
        if (s_transformTimingSampled) {
            CallbackProfileScope scope(phase, 64, false, 1);
            callback();
        } else {
            callback();
        }
        return;
    }
    s_sample.callbacks[static_cast<std::size_t>(phase)].workItems += objectCount;
    CallbackProfileScope scope(phase);
    callback();
}

template <class Callback>
void profileTransformChild(RendererManager& manager, vulkanizer::SchedulerCallbackPhase phase,
                           std::uint64_t workItems, Callback&& callback) {
    if (!manager.diagnosticsEnabled() || s_transformContext == TransformContext::none) {
        callback();
        return;
    }
    auto& measured = s_sample.callbacks[static_cast<std::size_t>(phase)];
    ++measured.calls;
    measured.workItems += workItems;
    measured.estimateWeight = 64;
    if (s_transformTimingSampled) {
        CallbackProfileScope scope(phase, 64, false, 1);
        callback();
    } else {
        callback();
    }
}

template <class Callback>
void profileTransformAction(RendererManager& manager, vulkanizer::SchedulerCallbackPhase phase,
                            TransformContext context, std::uint64_t workItems,
                            std::uint64_t& sampleIndex, Callback&& callback) {
    if (!manager.diagnosticsEnabled()) {
        callback();
        return;
    }
    auto& measured = s_sample.callbacks[static_cast<std::size_t>(phase)];
    ++measured.calls;
    measured.workItems += workItems;
    measured.estimateWeight = 64;
    const bool sampled = (sampleIndex++ & 0x3f) == 0;
    TransformContextScope contextScope(context, sampled);
    if (sampled) {
        CallbackProfileScope scope(phase, 64, false, 64);
        callback();
    } else {
        callback();
    }
}

template <class Callback>
void countOnlyCallback(RendererManager& manager, vulkanizer::SchedulerCallbackPhase phase,
                       Callback&& callback) {
    if (manager.diagnosticsEnabled())
        ++s_sample.callbacks[static_cast<std::size_t>(phase)].calls;
    callback();
}

template <class Callback>
void profileSampledCallback(RendererManager& manager, vulkanizer::SchedulerCallbackPhase phase,
                           std::uint32_t weight, bool sampled, Callback&& callback) {
    if (!manager.diagnosticsEnabled()) {
        callback();
        return;
    }
    if (!sampled) {
        ++s_sample.callbacks[static_cast<std::size_t>(phase)].calls;
        callback();
        return;
    }
    CallbackProfileScope scope(phase, weight);
    callback();
}
} // namespace

namespace vulkanizer {
FramePhaseSample takeCpuRenderPhaseSample() {
    if (!s_callbackScopeRecorder.balanced()) ++s_sample.scopeStackErrors;
    auto result = s_sample;
    s_sample = makeEmptySample();
    return result;
}
} // namespace vulkanizer

class $modify(VulkanizerSchedulerPhase, cocos2d::CCScheduler) {
    void update(float dt) {
        vulkanizer::recordGameplayFrameInput(dt);
        auto& manager = RendererManager::get();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::schedulerUpdate,
            [&] { CCScheduler::update(dt); });
        vulkanizer::recordGameplayFrameComplete();
    }
};

class $modify(VulkanizerActionManagerPhase, cocos2d::CCActionManager) {
    void update(float dt) {
        auto& manager = RendererManager::get();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::actionManagerUpdate,
            [&] { CCActionManager::update(dt); });
    }
};

class $modify(VulkanizerTimerPhase, cocos2d::CCTimer) {
    void update(float dt) {
        auto& manager = RendererManager::get();
        if (manager.diagnosticsEnabled()) ++s_sample.timerUpdateCalls;
        const bool sampled = (s_timerUpdateCallIndex++ & 0x7) == 0;
        profileSampledCallback(manager, timerPhase, 8, sampled, [&] { CCTimer::update(dt); });
    }
};

class $modify(VulkanizerGameUpdatePhase, GJBaseGameLayer) {
    void update(float dt) {
        auto& manager = RendererManager::get();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::gameLayerUpdate,
            [&] { GJBaseGameLayer::update(dt); });
    }

    void processCommands(float dt, bool isHalfTick, bool isLastTick) {
        auto& manager = RendererManager::get();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::processCommands,
            [&] { GJBaseGameLayer::processCommands(dt, isHalfTick, isLastTick); });
    }

    void preUpdateVisibility(float dt) {
        auto& manager = RendererManager::get();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::preUpdateVisibility,
            [&] { GJBaseGameLayer::preUpdateVisibility(dt); });
    }

    void processMoveActions() {
        vulkanizer::enterNativeMoveAttribution();
        struct AttributionScope { ~AttributionScope(){vulkanizer::leaveNativeMoveAttribution();} } attributionScope;
        vulkanizer::prepareVisualMoveDependencies(this);
        auto& manager = RendererManager::get();
        if (!manager.diagnosticsEnabled()) {
            GJBaseGameLayer::processMoveActions();
            return;
        }
        const auto entries = this->m_effectManager
            ? static_cast<std::uint64_t>(this->m_effectManager->m_unkVector6c0.size()) : 0;
        profileTransformAction(manager, vulkanizer::SchedulerCallbackPhase::processMoveActions,
            TransformContext::move, entries, s_moveActionSampleIndex,
            [&] { GJBaseGameLayer::processMoveActions(); });
    }

    void processMoveActionsStep(float dt, bool visibleFrame) {
        vulkanizer::recordGameplayPhysicsInput(this, dt);
        auto& manager = RendererManager::get();
        vulkanizer::beginHybridTransformStep();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::processMoveActionsStep,
            [&] { GJBaseGameLayer::processMoveActionsStep(dt, visibleFrame); });
        vulkanizer::endHybridTransformStep();
        vulkanizer::recordTransformCheckpoint(this);
    }

    void moveObjects(cocos2d::CCArray* objects, double dx, double dy, bool lockPlayerY) {
        auto& manager = RendererManager::get();
        profileObjectArrayCallback(manager, vulkanizer::SchedulerCallbackPhase::moveObjects, objects,
            [&] {
                if (!vulkanizer::tryVisualMoveObjects(this, objects, dx, dy) &&
                    !vulkanizer::tryHybridMoveObjects(this, objects, dx, dy, lockPlayerY))
                    GJBaseGameLayer::moveObjects(objects, dx, dy, lockPlayerY);
            });
    }

    void processRotationActions() {
        auto& manager = RendererManager::get();
        if (!manager.diagnosticsEnabled()) {
            if (!vulkanizer::tryProcessRotationActions(this)) GJBaseGameLayer::processRotationActions();
            return;
        }
        const auto entries = this->m_effectManager
            ? static_cast<std::uint64_t>(this->m_effectManager->m_unkVector5b0.size()) : 0;
        profileTransformAction(manager, vulkanizer::SchedulerCallbackPhase::processRotationActions,
            TransformContext::rotation, entries, s_rotationActionSampleIndex,
            [&] { if (!vulkanizer::tryProcessRotationActions(this)) GJBaseGameLayer::processRotationActions(); });
    }

    void updateObjectSection(GameObject* object) {
        if (vulkanizer::hybridParityProbeActive()) {
            vulkanizer::recordHybridParityCallback(false);
            return;
        }
        auto& manager = RendererManager::get();
        if (s_transformContext == TransformContext::move) {
            profileTransformChild(manager, vulkanizer::SchedulerCallbackPhase::moveUpdateObjectSection,
                1, [&] { GJBaseGameLayer::updateObjectSection(object); });
        } else if (s_transformContext == TransformContext::rotation) {
            profileTransformChild(manager, vulkanizer::SchedulerCallbackPhase::rotationUpdateObjectSection,
                1, [&] { GJBaseGameLayer::updateObjectSection(object); });
        } else {
            GJBaseGameLayer::updateObjectSection(object);
        }
    }


    void rotateObjects(cocos2d::CCArray* objects, float rotation, cocos2d::CCPoint position,
                       cocos2d::CCPoint offset, bool finished, bool unused) {
        auto& manager = RendererManager::get();
        profileObjectArrayCallback(manager, vulkanizer::SchedulerCallbackPhase::rotateObjects, objects,
            [&] {
                if (!vulkanizer::tryHybridRotateObjects(this, objects, rotation, position, offset, finished, unused))
                    GJBaseGameLayer::rotateObjects(objects, rotation, position, offset, finished, unused);
            });
    }

    void rotateObject(GameObject* object, float rotation) {
        auto& manager = RendererManager::get();
        countOnlyCallback(manager, vulkanizer::SchedulerCallbackPhase::rotateObject,
            [&] { GJBaseGameLayer::rotateObject(object, rotation); });
    }

    void processTransformActions(bool visibleFrame) {
        auto& manager = RendererManager::get();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::processTransformActions,
            [&] { GJBaseGameLayer::processTransformActions(visibleFrame); });
    }

    void processAreaActions(float dt, bool visibleFrame) {
        auto& manager = RendererManager::get();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::processAreaActions,
            [&] { GJBaseGameLayer::processAreaActions(dt, visibleFrame); });
    }

    void processAreaEffects(std::vector<EnterEffectInstance>* effects, GJAreaActionType type,
                            float dt, bool visibleFrame) {
        auto& manager = RendererManager::get();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::processAreaEffects,
            [&] { GJBaseGameLayer::processAreaEffects(effects, type, dt, visibleFrame); });
    }

    void addToGroup(GameObject* object, int groupID, bool triggerGroup) {
        GJBaseGameLayer::addToGroup(object, groupID, triggerGroup);
        vulkanizer::invalidateHybridGroupAudit(this);
    }

    void removeFromGroup(GameObject* object, int groupID) {
        GJBaseGameLayer::removeFromGroup(object, groupID);
        vulkanizer::invalidateHybridGroupAudit(this);
    }

    void spawnGroup(int group, bool ordered, double delay, std::vector<int> const& remapKeys,
                    int triggerID, int controlID) {
        GJBaseGameLayer::spawnGroup(group, ordered, delay, remapKeys, triggerID, controlID);
        vulkanizer::invalidateHybridGroupAudit(this);
    }
};

class $modify(VulkanizerTransformObjectWork, GameObject) {
    void addRotation(float rotation) {
        auto& manager = RendererManager::get();
        if (s_transformContext == TransformContext::rotation) {
            profileTransformChild(manager, vulkanizer::SchedulerCallbackPhase::rotationAddRotation,
                1, [&] { GameObject::addRotation(rotation); });
        } else {
            GameObject::addRotation(rotation);
        }
    }

    void updateOrientedBox() {
        auto& manager = RendererManager::get();
        if (s_transformContext == TransformContext::rotation) {
            profileTransformChild(manager, vulkanizer::SchedulerCallbackPhase::rotationUpdateOrientedBox,
                1, [&] { GameObject::updateOrientedBox(); });
        } else {
            GameObject::updateOrientedBox();
        }
    }

};

class $modify(VulkanizerPlayLayerUpdatePhase, PlayLayer) {
    bool init(GJGameLevel* level, bool dontCreateObjects) {
        if (!PlayLayer::init(level, dontCreateObjects)) return false;
        if (!dontCreateObjects) vulkanizer::precompileLevelTransforms(this);
        return true;
    }
    void onExit() {
        vulkanizer::flushPendingVisualTransforms(this, true);
        vulkanizer::resetRotationPlans();
        vulkanizer::invalidateHybridGroupAudit(this);
        PlayLayer::onExit();
    }

    void updateVisibility(float dt) {
        vulkanizer::flushPendingVisualTransforms(this);
        auto& manager = RendererManager::get();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::playLayerUpdateVisibility,
            [&] { PlayLayer::updateVisibility(dt); });
    }
    void resetLevel() {
        vulkanizer::flushPendingVisualTransforms(this, true);
        vulkanizer::resetRotationPlans();
        PlayLayer::resetLevel();
    }

    void updateColor(cocos2d::ccColor3B& color, float fadeTime, int colorID, bool blending,
                     float opacity, cocos2d::ccHSVValue& copyHSV, int colorIDToCopy,
                     bool copyOpacity, EffectGameObject* callerObject, int unk1, int unk2) {
        auto& manager = RendererManager::get();
        profileSchedulerCallback(manager, vulkanizer::SchedulerCallbackPhase::playLayerUpdateColor,
            [&] { PlayLayer::updateColor(color, fadeTime, colorID, blending, opacity,
                                         copyHSV, colorIDToCopy, copyOpacity, callerObject, unk1, unk2); });
    }
};

class $modify(VulkanizerNodeVisitPhase, cocos2d::CCNode) {
    void visit() {
        auto& manager = RendererManager::get();
        if (!manager.diagnosticsEnabled()) {
            CCNode::visit();
            return;
        }
        const bool topLevel = s_nodeVisitDepth++ == 0;
        if (topLevel) s_nodeVisitCalls = 0;
        ++s_nodeVisitCalls;
        if (!topLevel) {
            CCNode::visit();
            --s_nodeVisitDepth;
            return;
        }
        ++s_sample.nodeVisitRoots;
        auto start = RendererManager::Clock::now();
        ++s_sample.clockPairs;
        CCNode::visit();
        const double elapsed = std::chrono::duration<double, std::milli>(RendererManager::Clock::now() - start).count();
        s_sample.nodeVisitMs += elapsed;
        s_sample.nodeVisitCalls += s_nodeVisitCalls;
        --s_nodeVisitDepth;
    }
};

class $modify(VulkanizerSpriteDrawPhase, cocos2d::CCSprite) {
    void updateTransform() {
        auto& manager = RendererManager::get();
        if (!manager.diagnosticsEnabled()) {
            CCSprite::updateTransform();
            return;
        }
        ++s_sample.spriteTransformCalls;
        const bool sampled = (s_spriteTransformCallIndex++ & 0x3f) == 0;
        if (!sampled) {
            CCSprite::updateTransform();
            return;
        }
        auto start = RendererManager::Clock::now();
        ++s_sample.clockPairs;
        CCSprite::updateTransform();
        const double elapsed = std::chrono::duration<double, std::milli>(RendererManager::Clock::now() - start).count();
        ++s_sample.spriteTransformTimedCalls;
        s_sample.spriteTransformEstimatedMs += elapsed * 64.0;
    }

    void draw() {
        auto& manager = RendererManager::get();
        if (!manager.diagnosticsEnabled()) {
            CCSprite::draw();
            return;
        }
        ++s_sample.spriteDrawCalls;
        const bool sampled = (s_spriteDrawCallIndex++ & 0x0f) == 0;
        if (!sampled) {
            CCSprite::draw();
            return;
        }
        auto start = RendererManager::Clock::now();
        ++s_sample.clockPairs;
        CCSprite::draw();
        const double elapsed = std::chrono::duration<double, std::milli>(RendererManager::Clock::now() - start).count();
        ++s_sample.spriteDrawTimedCalls;
        s_sample.spriteDrawMs += elapsed * 16.0;
    }
};

class $modify(VulkanizerBatchDrawPhase, cocos2d::CCSpriteBatchNode) {
    void draw() {
        auto& manager = RendererManager::get();
        if (!manager.diagnosticsEnabled()) {
            CCSpriteBatchNode::draw();
            return;
        }
        ++s_sample.batchDrawCalls;
        auto start = RendererManager::Clock::now();
        ++s_sample.clockPairs;
        CCSpriteBatchNode::draw();
        s_sample.batchDrawMs += std::chrono::duration<double, std::milli>(RendererManager::Clock::now() - start).count();
    }
};

class $modify(VulkanizerTextureAtlasPhase, cocos2d::CCTextureAtlas) {
    void drawNumberOfQuads(unsigned int count) {
        auto& manager = RendererManager::get();
        if (!manager.diagnosticsEnabled()) {
            CCTextureAtlas::drawNumberOfQuads(count);
            return;
        }
        ++s_sample.atlasDrawCalls;
        s_sample.atlasQuads += count;
        const bool sampled = (s_atlasDrawCallIndex++ & 0x07) == 0;
        if (!sampled) {
            CCTextureAtlas::drawNumberOfQuads(count);
            return;
        }
        auto start = RendererManager::Clock::now();
        ++s_sample.clockPairs;
        CCTextureAtlas::drawNumberOfQuads(count);
        const double elapsed = std::chrono::duration<double, std::milli>(RendererManager::Clock::now() - start).count();
        ++s_sample.atlasDrawTimedCalls;
        s_sample.atlasDrawMs += elapsed * 8.0;
    }

    void drawNumberOfQuads(unsigned int count, unsigned int startQuad) {
        auto& manager = RendererManager::get();
        if (!manager.diagnosticsEnabled()) {
            CCTextureAtlas::drawNumberOfQuads(count, startQuad);
            return;
        }
        ++s_sample.atlasDrawCalls;
        s_sample.atlasQuads += count;
        const bool sampled = (s_atlasDrawCallIndex++ & 0x07) == 0;
        if (!sampled) {
            CCTextureAtlas::drawNumberOfQuads(count, startQuad);
            return;
        }
        auto start = RendererManager::Clock::now();
        ++s_sample.clockPairs;
        CCTextureAtlas::drawNumberOfQuads(count, startQuad);
        const double elapsed = std::chrono::duration<double, std::milli>(RendererManager::Clock::now() - start).count();
        ++s_sample.atlasDrawTimedCalls;
        s_sample.atlasDrawMs += elapsed * 8.0;
    }
};
