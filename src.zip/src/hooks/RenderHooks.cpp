#include "core/RendererManager.hpp"
#include "backend/HybridTransformPipeline.hpp"
#include "backend/RotationScheduler.hpp"
#include <Geode/modify/CCDirector.hpp>
#include <Geode/modify/CCEGLView.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;
using vulkanizer::RendererManager;

class $modify(VulkanizerRotationSelfTestMenu, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;
        Loader::get()->queueInMainThread([] {
            vulkanizer::runRotationSelfTestIfRequested();
        });
        return true;
    }
};

class $modify(VulkanizerDirector, cocos2d::CCDirector) {
    void drawScene() {
        vulkanizer::beginHybridTransformFrame();
        auto& manager = RendererManager::get();
        if (!manager.diagnosticsEnabled()) {
            CCDirector::drawScene();
            manager.afterVanillaFrame();
            vulkanizer::pollSchedulerGameplayTest();
            return;
        }
        auto entry = RendererManager::Clock::now();
        manager.beforeFrame();
        auto originalStart = RendererManager::Clock::now();
        CCDirector::drawScene();
        auto originalEnd = RendererManager::Clock::now();
        manager.afterVanillaFrame();
        vulkanizer::pollSchedulerGameplayTest();
        manager.recordFrame(originalStart, originalEnd);
        auto exit = RendererManager::Clock::now();
        // Save completed wrapper work for the next sample, including summary logging.
        manager.finishFrame(std::chrono::duration<double, std::milli>(
            (originalStart - entry) + (exit - originalEnd)).count());
    }
    void purgeDirector() {
        RendererManager::get().shutdown();
        CCDirector::purgeDirector();
    }
};

class $modify(VulkanizerPresentation, cocos2d::CCEGLView) {
    void swapBuffers() {
        auto& manager = RendererManager::get();
        if (!manager.diagnosticsEnabled()) {
            CCEGLView::swapBuffers();
            return;
        }
        // Sample before presentation/reset. This is Cocos' counter, not every GL draw.
        manager.recordCocosDraws(::g_uNumberOfDraws);
        auto start = RendererManager::Clock::now();
        CCEGLView::swapBuffers();
        manager.recordSwapBuffers(std::chrono::duration<double, std::milli>(
            RendererManager::Clock::now() - start).count());
    }
};
