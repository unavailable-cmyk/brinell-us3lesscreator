#pragma once
#include "Scene.hpp"
#include <functional>
#include <memory>

namespace vulkanizer::v2 {
struct RenderSink {
    virtual ~RenderSink() = default;
    // Complete native material state is established at each ordered range.
    // Shared ranges support the standard texture * vertex-color shader.
    virtual void bindMaterial(MaterialId) = 0;
    virtual void drawNative(ObjectId) = 0;
};
struct RenderCounters {
    std::uint64_t initialUploadBytes = 0;
    std::uint64_t uploadBytes = 0;
    std::uint64_t paletteUploadBytes = 0;
    std::uint64_t drawUniformUploadBytes = 0;
    std::uint64_t drawCalls = 0;
    std::uint64_t dispatches = 0;
};
// Desktop adapter, requiring GL 3.3. The same vec4 palette layout and vertex
// operations can be expressed with GLES 3.0 UBOs and GLSL ES 300 on mobile.
// Owns one context's resources. Destroy before that context is released.
// The caller owns GL state during render and must restore/invalidate its cache
// before returning to an external renderer such as Cocos.
class GlRenderer {
public:
    using Resolve = std::function<void*(const char*)>;
    explicit GlRenderer(Resolve);
    ~GlRenderer();
    GlRenderer(const GlRenderer&) = delete;
    GlRenderer& operator=(const GlRenderer&) = delete;
    void attach(Scene&);
    void render(Scene&, const std::array<float, 16>& mvp, RenderSink&);
    // Live atlas integration supplies resolved contiguous ranges. Native ranges
    // are submitted by the host atlas, preserving its existing batching.
    void renderRanges(Scene&, std::span<const Draw>, const std::array<float, 16>& mvp, RenderSink&);
    void abandonContext();
    void clearCounters();
    const RenderCounters& counters() const;
private:
    struct Impl;
    std::unique_ptr<Impl> m_impl;
};
}
