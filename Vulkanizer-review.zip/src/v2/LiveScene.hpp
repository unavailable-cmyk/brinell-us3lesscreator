#pragma once
#include <functional>
#include <cstdint>

class GJBaseGameLayer;
class PlayLayer;
class GameObject;
namespace cocos2d { class CCArray; class CCSprite; class CCTextureAtlas; }

namespace vulkanizer::v2::live {
enum class CachedMoveSectionResult : std::uint8_t { notApplicable, skip, native };
enum class MovePolicyInvalidation : std::uint8_t {
    layerGroupAdd, layerGroupRemove, groupParentAdd, groupParentRemove,
    groupParentSet, groupParentRemoveOne, groupParentPromote, groupParentLoad,
    objectType, startPosition, objectGroupAdd, objectGroupRemove, objectReset,
    retirement, sceneDestroy, count
};
bool requested();
bool moveSectionsRequested();
bool cachedPoliciesRequested();
bool owns(cocos2d::CCSprite*);
bool owns(GameObject*);
bool ownsHeadlessMaterial(GameObject*);
void beforeHistoryRead(GameObject*);
bool retainVisibility(GameObject*, bool visible);
bool retainActivation(GameObject*);
bool activeFor(GJBaseGameLayer*);
void releaseArray(cocos2d::CCArray*, const char* reason);
void beginLevel(PlayLayer*);
void destroy(PlayLayer*, const char* reason);
void beforeVisibility(PlayLayer*);
void afterVisibility(PlayLayer*);
void beforeDependencies(GJBaseGameLayer*);
void beforeToggle(GJBaseGameLayer*, int group);
void release(GameObject*, const char* reason);
void releaseAll(const char* reason);
void atlasMutation(cocos2d::CCTextureAtlas*, const char* reason);
bool quadMutation(cocos2d::CCTextureAtlas*, unsigned slot, const void* quad);
bool move(GJBaseGameLayer*, cocos2d::CCArray*, double dx, double dy, bool lockPlayerY,
          const std::function<void(cocos2d::CCArray*)>& native);
bool drawAtlas(cocos2d::CCTextureAtlas*, unsigned count, unsigned first,
               const std::function<void(unsigned, unsigned)>& native);
void recordSpriteVisit(cocos2d::CCSprite*, bool suppressed);
void recordSectionCommit(GameObject*);
bool canSkipMoveSection(GJBaseGameLayer*, GameObject*);
CachedMoveSectionResult cachedMoveSection(GJBaseGameLayer*, GameObject*);
void invalidateMoveSectionPolicy(GameObject*, MovePolicyInvalidation);
void invalidateAllMoveSectionPolicies(MovePolicyInvalidation);
void beforeObjectRetirement(GameObject*);
void frameBegin();
void frameEnd();
void beforeSwap();
bool startTest();
void physicsStep(PlayLayer*);
}
