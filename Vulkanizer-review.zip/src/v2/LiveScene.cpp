#include "LiveScene.hpp"
#include "AtlasPlan.hpp"
#include "GlRenderer.hpp"
#include "FrameGpuTimer.hpp"
#include "TranslationPrecision.hpp"
#include "SharedHistoryPrototype.hpp"
#include "backend/RotationScheduler.hpp"
#include <Geode/Geode.hpp>
#include <Geode/binding/PlayLayer.hpp>
#include <Geode/binding/EffectGameObject.hpp>
#include <Geode/binding/SpawnTriggerGameObject.hpp>
#include <Geode/binding/GJEffectManager.hpp>
#include <Geode/binding/GroupCommandObject2.hpp>
#include <Geode/binding/DynamicMoveCalculation.hpp>
#include <Geode/binding/GJGameLevel.hpp>
#include <Geode/binding/LocalLevelManager.hpp>
#include <Geode/binding/PlayerObject.hpp>
#include <Geode/binding/GJSpriteColor.hpp>
#include <Geode/binding/ColorAction.hpp>
#include <Geode/cocos/kazmath/include/kazmath/GL/matrix.h>
#include <windows.h>
#include <GL/gl.h>
#include <algorithm>
#include <array>
#include <chrono>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <limits>
#include <map>
#include <memory>
#include <optional>
#include <set>
#include <unordered_map>
#include <unordered_set>

using namespace geode::prelude;
namespace vulkanizer::v2::live {
namespace {
using Clock = std::chrono::steady_clock;
constexpr double pixelBudget = .125;
struct EnvFlags {
    static bool isSet(const char* name) { return std::getenv(name) != nullptr; }
    static bool isOne(const char* name) {
        const auto* value = std::getenv(name);
        return value && std::strcmp(value, "1") == 0;
    }
    static std::optional<double> number(const char* name) {
        if (const auto* value = std::getenv(name)) return std::atof(value);
        return std::nullopt;
    }
    static std::optional<std::string> text(const char* name) {
        if (const auto* value = std::getenv(name)) return std::string(value);
        return std::nullopt;
    }

    bool v2 = isSet("VULKANIZER_V2");
    bool moveSections = isSet("VULKANIZER_V2_MOVE_SECTIONS");
    bool cachedPolicies = isOne("VULKANIZER_V2_CACHED_POLICIES");
    bool baseline = isSet("VULKANIZER_V2_BASELINE");
    bool census = isSet("VULKANIZER_V2_CENSUS");
    bool colorShakeFixture = isSet("VULKANIZER_V2_COLOR_SHAKE_FIXTURE");
    bool denseOwners = isSet("VULKANIZER_V2_DENSE_OWNERS");
    bool disabledCamera = isSet("VULKANIZER_V2_DISABLED_CAMERA");
    bool disabledHeadless = isSet("VULKANIZER_V2_DISABLED_HEADLESS");
    bool headless = isSet("VULKANIZER_V2_HEADLESS");
    bool headlessAlpha = isSet("VULKANIZER_V2_HEADLESS_ALPHA");
    bool headlessFixture = isSet("VULKANIZER_V2_HEADLESS_FIXTURE");
    bool headlessMaterial = isSet("VULKANIZER_V2_HEADLESS_MATERIAL");
    bool lateDependencies = isSet("VULKANIZER_V2_LATE_DEPENDENCIES");
    bool localColorShake = isSet("VULKANIZER_V2_LOCAL_COLOR_SHAKE");
    bool persistVisibility = isSet("VULKANIZER_V2_PERSIST_VISIBILITY");
    bool resolvedXlock = isSet("VULKANIZER_V2_RESOLVED_XLOCK");
    bool sharedHistory = isSet("VULKANIZER_V2_SHARED_HISTORY");
    bool staticTransforms = isSet("VULKANIZER_V2_STATIC_TRANSFORMS");
    bool structuralFixture = isSet("VULKANIZER_V2_STRUCTURAL_FIXTURE");
    bool test = isSet("VULKANIZER_V2_TEST");
    bool toggleFixture = isSet("VULKANIZER_V2_TOGGLE_FIXTURE");
    bool validate = isSet("VULKANIZER_V2_VALIDATE");
    bool xlockFixture = isSet("VULKANIZER_V2_XLOCK_FIXTURE");
    std::optional<double> captureTime = number("VULKANIZER_V2_CAPTURE_TIME");
    std::optional<double> testSeconds = number("VULKANIZER_V2_TEST_SECONDS");
    std::optional<std::string> capturePath = text("VULKANIZER_V2_CAPTURE");
    std::optional<std::string> reportPath = text("VULKANIZER_V2_REPORT");
    std::optional<std::string> levelName = text("VULKANIZER_TEST_LEVEL_NAME");
};

const EnvFlags& envFlags() {
    static const EnvFlags flags;
    return flags;
}

struct Entry {
    Ref<GameObject> object;
    Ref<CCSpriteBatchNode> batch;
    Ref<CCTextureAtlas> atlas;
    unsigned slot = 0;
    bool owned = false;
    bool headless = false;
    bool disabledHeadless = false;
    Translation reference;
    Translation historyBase, initialPrevious;
    std::optional<std::uint32_t> initialStamp;
    std::vector<std::pair<std::size_t, unsigned>> memberships;
};
struct Route {
    GroupId token = 0;
    Ref<CCArray> source;
    Ref<CCArray> native;
    std::vector<ObjectId> members;
    std::vector<ChainId> chains;
    std::vector<unsigned> nativeSlots;
    unsigned count = 0, owned = 0, ownedHeadless = 0;
    std::uint64_t censusCalls = 0;
};
struct Space {
    Ref<CCNode> batch;
    double left = 0, right = 0, bottom = 0, top = 0;
    bool headless = false;
};
struct Chain {
    std::vector<Handle> objects;
    std::vector<Space> spaces;
    double minDx = -std::numeric_limits<double>::infinity(), maxDx = std::numeric_limits<double>::infinity();
    double minDy = -std::numeric_limits<double>::infinity(), maxDy = std::numeric_limits<double>::infinity();
    TranslationPrecision precision;
    std::optional<SharedHistoryPrototype> history;
    unsigned owned = 0;
    bool disabledHeadless = false;
};
struct Atlas {
    Ref<CCSpriteBatchNode> batch;
    AtlasPlan plan;
    std::vector<ObjectId> objects;
};
struct Statistics {
    std::uint64_t translations = 0, eliminatedVisits = 0, nativeMoveVisits = 0;
    std::uint64_t nativeCommitCallbacks = 0, handoffCommits = 0, geometrySuppressed = 0, spriteVisits = 0;
    std::uint64_t nativeDraws = 0, v2Draws = 0, nativeQuads = 0, v2Quads = 0;
    std::uint64_t pageBreaks = 0, materialBoundaries = 0, ownershipBoundaries = 0;
    std::uint64_t chainCameraChecks = 0, validationVisits = 0, validationReadbackBytes = 0;
    std::uint64_t dependencyGuardVisits = 0;
    std::uint64_t nativeAtlasDirtyBytes = 0, nativeAtlasUploads = 0, ownershipCommitViolations = 0;
    std::uint64_t renderFailures = 0;
    std::uint64_t acquired = 0, released = 0, maxActiveChains = 0, maxDirty = 0;
    std::uint64_t headlessAcquired = 0, headlessReleased = 0, headlessEliminatedVisits = 0;
    std::uint64_t cachedPolicyHits = 0, cachedPolicyMisses = 0, structuralPredicatesAvoided = 0;
    std::uint64_t denseIdentityHits = 0, hashLookupFallbacks = 0, cacheInvalidations = 0;
    std::uint64_t dynamicSectionChecks = 0, precompiledRouteHits = 0, routeHashLookups = 0;
    std::uint64_t cacheInvalidationsAfterReady = 0;
    std::array<std::uint64_t, static_cast<std::size_t>(MovePolicyInvalidation::count)> cacheInvalidationsBySource{};
    std::uint64_t denseOwnershipCalls = 0, denseOwnershipSamples = 0, denseOwnershipMismatches = 0;
    double maxDivergence = 0, maxPixelBound = 0;
};
struct Live final : NativeSink, RenderSink {
    PlayLayer* layer = nullptr;
    std::optional<Scene> scene;
    std::unique_ptr<GlRenderer> renderer;
    std::unique_ptr<FrameGpuTimer> gpuTimer;
    HGLRC context = nullptr;
    std::vector<Entry> entries;
    std::vector<Route> routes;
    std::vector<Chain> chains;
    std::unordered_map<CCArray*, std::size_t> routeIndices;
    std::unordered_map<CCSprite*, ObjectId> ids;
    std::vector<ObjectId> denseIds;
    std::int64_t denseIdBase = 0;
    std::vector<std::uint8_t> moveSectionPolicies;
    std::uint64_t movePolicySceneGeneration = 0;
    CCArray* recentMoveArray = nullptr;
    std::size_t recentMoveRoute = std::numeric_limits<std::size_t>::max();
    std::uint64_t recentMoveSceneGeneration = 0;
    std::unordered_map<CCTextureAtlas*, Atlas> atlases;
    std::map<std::string, std::uint64_t> rejected, transitions;
    std::map<std::string, std::uint64_t> inactiveReadiness;
    std::map<int, std::uint64_t> unknownTriggers;
    std::vector<std::string> unknownMods;
    std::map<int, std::uint64_t> colorTargets, shakeTargets;
    std::uint64_t colorCopy = 0, triggeredBySpawn = 0, triggeredByTouch = 0;
    Statistics stats;
    bool compiling = false, internal = false, drawing = false, ready = false, visiblePass = false;
    bool assessed = false, baseline = false, validate = false, cachedPoliciesEnabled = false;
    std::uint64_t order = 0, frames = 0, ticks = 0, eligible = 0, total = 0;
    Clock::time_point frameStart;
    std::vector<double> cpuFrames;
    std::string levelName;
    std::optional<matjson::Value> capture;
    bool gpuStarted = false, frameCaptured = false;
    bool testCompleted = false;
    unsigned retainedAtCompletion = 0, headlessRetainedAtCompletion = 0;
    bool structuralHandoffTest = false, structuralHandoffOwned = false;
    std::vector<GameObject*> structuralHandoffObjects;
    unsigned toggleFixturePhase = 0;
    std::vector<Ref<GameObject>> toggleFixtureObjects;
    std::optional<matjson::Value> toggleFixtureTrace;
    Clock::time_point progressStart;
    std::vector<double> cpuOwnedFrames;
    std::vector<double> cpuBenchmarkFrames;
    Statistics benchmarkStart{}, benchmarkEnd{};
    bool benchmarkStarted = false, benchmarkFinished = false;
    std::vector<std::uint64_t> censusMasks;
    std::vector<std::string> initialMoveRejections;
    std::vector<std::uint16_t> censusProtectionCauses;
    std::uint64_t censusCandidateChains = 0;
    std::uint64_t censusV1ParentCandidateChains = 0;
    std::uint64_t censusStructuralParentChains = 0;
    std::string gpuStatus = "unavailable";
    CCTextureAtlas* drawingAtlas = nullptr;
    void translate(std::span<const ObjectId>, Translation, std::uint64_t) noexcept override {
        // Native callbacks run after Scene::translate returns so they can
        // request dependency handoff without re-entering the scene runtime.
    }
    void materialize(ObjectId id, Translation p, bool) noexcept override {
        auto& entry = entries[id];
        auto* object = entry.object.data();
        const auto transform = scene->nativeTransform(scene->handle(id));
        internal = true;
        if (object->getRotationX() != transform.rotationX) object->setRotationX(transform.rotationX);
        if (object->getRotationY() != transform.rotationY) object->setRotationY(transform.rotationY);
        if (object->getScaleX() != transform.scaleX) object->setScaleX(transform.scaleX);
        if (object->getScaleY() != transform.scaleY) object->setScaleY(transform.scaleY);
        if (object->getSkewX() != transform.skewX) object->setSkewX(transform.skewX);
        if (object->getSkewY() != transform.skewY) object->setSkewY(transform.skewY);
        if (object->isFlipX() != transform.flipX) object->setFlipX(transform.flipX);
        if (object->isFlipY() != transform.flipY) object->setFlipY(transform.flipY);
        if (object->getAnchorPoint().x != transform.anchorX || object->getAnchorPoint().y != transform.anchorY)
            object->setAnchorPoint({transform.anchorX, transform.anchorY});
        if (const auto& history = chains[scene->chainFor(scene->handle(id))].history) {
            const auto native = history->materialize(entry.historyBase, entry.initialPrevious);
            p = native.position;
            if (native.invalidateRect) {
                object->m_lastPosition = CCPoint(static_cast<float>(native.previous.x), static_cast<float>(native.previous.y));
                object->m_unk4C4 = static_cast<int>(native.stamp);
                object->dirtifyObjectRect();
            }
        }
        object->m_positionX = p.x;
        object->m_positionY = p.y;
        object->dirtifyObjectPos();
        layer->updateObjectSection(object);
        object->cocos2d::CCSprite::setPosition({static_cast<float>(p.x), static_cast<float>(p.y)});
        if (object->getBatchNode()) object->updateTransform();
        internal = false;
        entry.owned = false;
        if (entry.atlas) atlases.at(entry.atlas.data()).plan.release(entry.slot);
        for (auto [routeIndex, slot] : entry.memberships) {
            auto& route = routes[routeIndex];
            const auto at = std::lower_bound(route.nativeSlots.begin(), route.nativeSlots.end(), slot);
            const auto index = static_cast<unsigned>(at - route.nativeSlots.begin());
            route.nativeSlots.insert(at, slot);
            route.native->insertObject(object, index);
            --route.owned;
            if (entry.headless) --route.ownedHeadless;
        }
        ++stats.handoffCommits;
        ++stats.released;
        if (entry.headless) ++stats.headlessReleased;
    }
    void visibility(ObjectId, bool) noexcept override {}
    void reset(ObjectId, Translation, bool) noexcept override {}
    void bindMaterial(MaterialId) override {
        // Cocos normally binds the atlas texture inside drawNumberOfQuads.
        // A fully V2 range bypasses that body, so reproduce that material step.
        ccGLBindTexture2DN(0, drawingAtlas->getTexture()->getName());
    }
    void drawNative(ObjectId) override { throw std::logic_error("Live fallback requires an original atlas range"); }
    unsigned owned() const { return static_cast<unsigned>(stats.acquired - stats.released); }
    void rebuildNativeRoutes() {
        for (auto& route : routes) {
            route.native = CCArray::createWithCapacity(route.source->count());
            route.nativeSlots.clear();
            route.nativeSlots.reserve(route.source->count());
            route.owned = 0;
            route.ownedHeadless = 0;
            route.chains.clear();
            unsigned slot = 0;
            for (auto* object : CCArrayExt<GameObject, false>(route.source)) {
                auto found = ids.find(object);
                if (found != ids.end() && entries[found->second].owned) {
                    const auto id = found->second;
                    ++route.owned;
                    if (entries[id].headless) ++route.ownedHeadless;
                    route.chains.push_back(scene->chainFor(scene->handle(id)));
                } else { route.native->addObject(object); route.nativeSlots.push_back(slot); }
                ++slot;
            }
            std::sort(route.chains.begin(), route.chains.end());
            route.chains.erase(std::unique(route.chains.begin(), route.chains.end()), route.chains.end());
        }
    }
};
std::unique_ptr<Live> state;
bool testRunning = false, captured = false, testLaunched = false;
Clock::time_point testStarted;
std::uint64_t testTicks = 0;
double testInitialLevelTime = -1;
bool controlledToggleVisibility() {
    const auto& flags = envFlags();
    return flags.persistVisibility && flags.toggleFixture &&
        flags.test && !flags.levelName;
}

void* resolve(const char* name) {
    auto address = wglGetProcAddress(name);
    auto bits = reinterpret_cast<std::uintptr_t>(address);
    if (bits <= 3 || bits == ~std::uintptr_t{}) {
        address = reinterpret_cast<PROC>(GetProcAddress(GetModuleHandleW(L"opengl32.dll"), name));
    }
    return reinterpret_cast<void*>(address);
}
struct Camera {
    double left, right, bottom, top, scale;
};
std::optional<Camera> camera(CCNode* batch) {
    auto size = CCDirector::sharedDirector()->getWinSize();
    const auto a = batch->convertToNodeSpace({0, 0});
    const auto b = batch->convertToNodeSpace({size.width, 0});
    const auto c = batch->convertToNodeSpace({0, size.height});
    if (std::abs(b.y - a.y) > .01 || std::abs(c.x - a.x) > .01 || b.x <= a.x || c.y <= a.y) return {};
    GLint viewport[4]{};
    glGetIntegerv(GL_VIEWPORT, viewport);
    return Camera{a.x, b.x, a.y, c.y, std::max(viewport[2] / (b.x - a.x), viewport[3] / (c.y - a.y))};
}

struct CameraCache {
    std::unordered_map<CCNode*, std::optional<Camera>> entries;

    std::optional<Camera> get(CCNode* node) {
        auto it = entries.find(node);
        if (it != entries.end())
            return it->second;

        auto result = camera(node);
        entries.emplace(node, result);
        return result;
    }

    void clear() {
        entries.clear();
    }
};

const char* unsafe(
    ChainId id,
    Translation candidate,
    double error,
    CameraCache* cameras = nullptr
) {
    auto& live = *state;
    const auto& chain = live.chains[id];
    if (!std::isfinite(candidate.x) || !std::isfinite(candidate.y)) return "nonfinite_translation";
    if (candidate.x < chain.minDx || candidate.x >= chain.maxDx ||
        candidate.y < chain.minDy || candidate.y >= chain.maxDy) return "section_boundary";
    for (const auto& space : chain.spaces) {
        const auto view = cameras
    ? cameras->get(space.batch.data())
    : camera(space.batch.data());
        if (!view) return "camera_transform";
        constexpr double margin = 32;
        if (space.headless) {
            const auto left = std::min(space.left, space.left + candidate.x);
            const auto right = std::max(space.right, space.right + candidate.x);
            const auto bottom = std::min(space.bottom, space.bottom + candidate.y);
            const auto top = std::max(space.top, space.top + candidate.y);
            if (!(chain.disabledHeadless && std::all_of(chain.spaces.begin(), chain.spaces.end(),
                    [](const auto& value) { return value.headless; })) &&
                !(right < view->left - margin || left > view->right + margin ||
                  top < view->bottom - margin || bottom > view->top + margin)) return "headless_visibility_boundary";
            const auto pixels = chain.precision.pixelBound(candidate, view->scale, error);
            live.stats.maxPixelBound = std::max(live.stats.maxPixelBound, pixels);
            if (pixels > pixelBudget) return "numerical_pixel_budget";
            continue;
        }
        if (std::min(space.left, space.left + candidate.x) <= view->left + margin ||
            std::max(space.right, space.right + candidate.x) >= view->right - margin ||
            std::min(space.bottom, space.bottom + candidate.y) <= view->bottom + margin ||
            std::max(space.top, space.top + candidate.y) >= view->top - margin) return "visibility_boundary";
        const auto pixels = chain.precision.pixelBound(candidate, view->scale, error);
        live.stats.maxPixelBound = std::max(live.stats.maxPixelBound, pixels);
        if (pixels > pixelBudget) return "numerical_pixel_budget";
    }
    return nullptr;
}
void handoff(std::span<const Handle> handles, const char* reason) {
    auto& live = *state;
    if (handles.empty() || !live.scene) return;
    std::vector<Handle> owned;
    for (auto h : handles) if (live.entries[h.object].owned) owned.push_back(h);
    if (owned.empty()) return;
    live.scene->acquireNativeBatch(owned, live);
    for (auto h : owned) --live.chains[live.scene->chainFor(h)].owned;
    for (auto& route : live.routes)
        std::erase_if(route.chains, [&](auto id) { return !live.chains[id].owned; });
    live.transitions[reason] += owned.size();
    log::info("VULKANIZER_V2_OWNERSHIP scene={} transition=V2_to_Native objects={} reason={} remaining={} runtime_native_to_v2=0",
        live.scene->generation(), owned.size(), reason, live.owned());
}
void handoffChain(ChainId id, const char* reason) { handoff(state->chains[id].objects, reason); }

constexpr std::uint8_t movePolicyValid = 1u << 0;
constexpr std::uint8_t movePolicyStructurallyEligible = 1u << 1;
constexpr std::uint64_t cachedStructuralPredicateCount = 4;



bool stableMoveSectionEligibility(const GameObject* object) {
    return object &&
        object->m_objectType == GameObjectType::Decoration &&
        object->m_classType == GameObjectClassType::Game &&
        !object->m_isTrigger &&
        !object->m_isStartPos;
}

bool dynamicMoveSectionEligibility(GJBaseGameLayer* layer, GameObject* object) {
    if (!layer || !object ||
        object->m_hasGroupParent ||
        object->m_hasAreaParent ||
        object->m_hasGroupParentsString ||
        object->m_updateParents ||
        object->m_linkedGroup ||
        object->m_parentMode > 0 ||
        object->m_isUIObject ||
        object->m_hasExtendedCollision)
        return false;

    const double x = object->m_positionX;
    const double y = object->m_positionY;
    if (!std::isfinite(x) || !std::isfinite(y) ||
        x > 1'000'000.0 || y > 1'000'000.0 ||
        object->m_outerSectionIndex < 0 ||
        object->m_middleSectionIndex < 0)
        return false;

    const int sx = x <= 0 ? 0 : static_cast<int>(layer->m_sectionXFactor * x);
    const int sy = y <= 0 ? 0 : static_cast<int>(layer->m_sectionYFactor * y);
    return sx == object->m_outerSectionIndex && sy == object->m_middleSectionIndex;
}

void recordSectionCommitKnown(ObjectId id, GameObject* object) {
    if (!state || state->internal || !state->ready) return;
    ++state->stats.nativeCommitCallbacks;
    if (id >= state->entries.size()) return;
    auto& entry = state->entries[id];
    if (entry.object.data() != object || !entry.owned) return;
    ++state->stats.ownershipCommitViolations;
    const Handle h = state->scene->handle(id);
    handoff(std::span<const Handle>(&h, 1), "unexpected_authoritative_section_consumer");
}

std::string rejection(GameObject* o, const std::unordered_set<int>& protectedGroups, bool uncertainLevel) {
    const auto& flags = envFlags();
    if (o->m_objectType != GameObjectType::Decoration) return "non_decoration";
    if (o->m_classType != GameObjectClassType::Game || o->m_isTrigger || o->m_isStartPos) return "object_class";
    if (uncertainLevel) return "uncertain_level_dependency";
    if (!o->m_groups || !o->m_groupCount) return "no_translation_membership";
    for (short i = 0; i < o->m_groupCount; ++i)
        if (protectedGroups.contains((*o->m_groups)[i])) return "protected_dependency_group";
    // A real-game fixture exercises -1 with no group, area, or linked parent,
    // translation, and a subsequent native handoff. Keep all
    // other nonzero modes conservative until their native semantics are shown.
    if (o->m_hasGroupParent || o->m_hasAreaParent ||
        (o->m_parentMode != 0 && o->m_parentMode != -1) || o->m_linkedGroup) return "parent_dependency";
    if (o->m_particle || o->m_hasParticles || o->m_hasAnimatedChild || o->m_isUIObject) return "dynamic_visual";
    if (!o->m_isDontEnter) return "native_enter_effect";
    if (!o->m_isDontFade) return "native_fade_effect";
    if (o->m_tempOffsetXRelated || o->m_positionXOffset || o->m_positionYOffset) return "position_offset";
    if (o->m_colorSprite || o->m_glowSprite || o->getChildrenCount()) return "compound_sprite";
    const bool nonIdentity = o->getScaleX() != 1 || o->getScaleY() != 1 || o->getRotationX() || o->getRotationY() ||
        o->getSkewX() || o->getSkewY() || o->isFlipX() || o->isFlipY();
    if (nonIdentity && !flags.staticTransforms) return "unsupported_local_transform";
    const auto anchor = o->getAnchorPoint();
    if (!std::isfinite(o->getScaleX()) || !std::isfinite(o->getScaleY()) ||
        !std::isfinite(o->getRotationX()) || !std::isfinite(o->getRotationY()) ||
        !std::isfinite(o->getSkewX()) || !std::isfinite(o->getSkewY()) ||
        !std::isfinite(anchor.x) || !std::isfinite(anchor.y)) return "nonfinite_local_transform";
    const bool headless = flags.headless && !o->isVisible() && !o->getBatchNode() && !o->getTextureAtlas();
    if (!o->m_isDecoration2 && !(headless && flags.sharedHistory)) return "native_command_history";
    const bool disabledHeadless =
    flags.disabledHeadless &&
    headless &&
    o->m_isGroupDisabled &&
    !o->m_isHide &&
    !o->getParent();

if ((o->m_isGroupDisabled ||
     o->m_isGroupDisabledTemp ||
     o->m_isHide ||
     (!o->isVisible() && !headless)) &&
    !disabledHeadless)
    return "native_inactive";
    if ((!o->getBatchNode() || !o->getTextureAtlas()) && !headless) return "unbatched";
    if (headless) {
        if (o->getParent()) return "headless_unexpected_parent";
        if (!std::isfinite(o->m_positionX) || !std::isfinite(o->m_positionY) ||
            o->m_outerSectionIndex < 0 || o->m_middleSectionIndex < 0) return "invalid_spatial_state";
        const auto bounds = o->boundingBox();
        if (!std::isfinite(bounds.origin.x) || !std::isfinite(bounds.origin.y) ||
            !std::isfinite(bounds.size.width) || !std::isfinite(bounds.size.height) ||
            bounds.size.width <= 0 || bounds.size.height <= 0) return "headless_invalid_bounds";
        return {};
    }
    if (o->getBatchNode()->getShaderProgram() != CCShaderCache::sharedShaderCache()->programForKey(kCCShader_PositionTextureColor)) return "custom_shader";
    if (!std::isfinite(o->m_positionX) || !std::isfinite(o->m_positionY) ||
        o->m_outerSectionIndex < 0 || o->m_middleSectionIndex < 0) return "invalid_spatial_state";
    const auto slot = o->getAtlasIndex();
    auto* descendants = o->getBatchNode()->getDescendants();
    if (slot >= descendants->count() || descendants->objectAtIndex(slot) != o) return "unresolved_atlas_order";
    return {};
}
void compile() {
    const auto& flags = envFlags();
    auto& live = *state;
    live.compiling = true;
    live.assessed = true;
    flushPendingVisualTransforms(live.layer, true);
    resetRotationPlans();
    std::unordered_set<int> protectedGroups;
    std::unordered_set<int> alphaTargets;
    std::unordered_map<int, std::uint16_t> protectionCauses;
    const bool collectCensus = flags.census;
    // Opt-in: direct, unresolved and inherited color consumers stay native.
    // Native owns camera shake; the renderer consumes GD's current view matrix.
    const bool localizedMaterials = flags.localColorShake;
    std::unordered_set<int> mutableColorChannels;
    bool uncertain = false;
    enum : std::uint16_t { centerReference = 1, xLockRecipient = 2, otherMoveTarget = 4,
        nonMoveTarget = 8, targetMapping = 16, dynamicReference = 32,
        target1346 = 64, target1007 = 128, target1049 = 256, target1006 = 512 };
    auto protect = [&](int group, std::uint16_t cause, bool required = true) {
        if (group <= 0) return;
        if (collectCensus) protectionCauses[group] |= cause;
        if (required) protectedGroups.insert(group);
    };
    std::vector<GameObject*> inputObjects;
    for (auto* object : CCArrayExt<GameObject, false>(live.layer->m_objects)) {
        inputObjects.push_back(object);
        if (!object->m_isTrigger || object->m_isStartPos) continue;
        auto* effect = typeinfo_cast<EffectGameObject*>(object);
        if (!effect) { uncertain = true; ++live.unknownTriggers[object->m_objectID]; continue; }
        if (object->m_objectID == 899) {
            ++live.colorTargets[object->m_targetColor];
            if (effect->m_copyColorID) ++live.colorCopy;
            if (object->m_targetColor > 0) mutableColorChannels.insert(object->m_targetColor);
            else if (localizedMaterials) uncertain = true;
        }
        if (object->m_objectID == 1006 && localizedMaterials) {
            // Pulse target modes use different identifiers. Treat both as
            // potentially mutable channels in addition to group protection.
            if (object->m_targetColor > 0) mutableColorChannels.insert(object->m_targetColor);
            if (effect->m_targetGroupID > 0) mutableColorChannels.insert(effect->m_targetGroupID);
            if (object->m_targetColor <= 0 && effect->m_targetGroupID <= 0) uncertain = true;
        }
        if (object->m_objectID == 1520) ++live.shakeTargets[effect->m_targetGroupID];
        if (object->m_objectID == 899 || object->m_objectID == 1520) {
            live.triggeredBySpawn += effect->m_isSpawnTriggered;
            live.triggeredByTouch += effect->m_isTouchTriggered;
        }
        protect(effect->m_centerGroupID, centerReference);
        protect(effect->m_rotationTargetID, centerReference);
        protect(effect->m_targetModCenterID, centerReference);
        if (auto* spawn = typeinfo_cast<SpawnTriggerGameObject*>(object);
            spawn && (!spawn->m_remapObjects.empty() || !spawn->m_remapKeys.empty())) uncertain = true;
        switch (object->m_objectID) {
            case 31: break;
            case 899: case 1520:
                if (!localizedMaterials) { uncertain = true; ++live.unknownTriggers[object->m_objectID]; }
                break;
            case 901:
                if (effect->m_lockToPlayerX)
                    protect(effect->m_targetGroupID, xLockRecipient, !flags.resolvedXlock);
                if (effect->m_useMoveTarget || effect->m_isDynamicMode || effect->m_specialTarget ||
                    effect->m_targetPlayer1 || effect->m_targetPlayer2 ||
                    effect->m_lockToPlayerY || effect->m_lockToCameraX || effect->m_lockToCameraY)
                    protect(effect->m_targetGroupID, otherMoveTarget);
                break;
            case 1346: protect(effect->m_targetGroupID, nonMoveTarget | target1346,
                !flags.lateDependencies); break;
            case 1007:
                protect(effect->m_targetGroupID, nonMoveTarget | target1007, !flags.headlessAlpha);
                alphaTargets.insert(effect->m_targetGroupID);
                break;
            case 1049: protect(effect->m_targetGroupID, nonMoveTarget | target1049,
                !controlledToggleVisibility() && !flags.lateDependencies); break;
            case 1006: protect(effect->m_targetGroupID, nonMoveTarget | target1006); break;
            case 1268: case 1616: case 1612: case 1613: case 1812: case 1814: case 1818: case 1819:
                break;
            default: uncertain = true; ++live.unknownTriggers[object->m_objectID]; break;
        }
    }
    for (auto* mod : Loader::get()->getAllMods()) {
        if (!mod->isLoaded() || mod == Mod::get() || mod->getID() == "geode.loader") continue;
        uncertain = true;
        live.unknownMods.emplace_back(mod->getID().view());
    }
    for (const auto& [group, target] : live.layer->m_targetGroups) {
        protect(group, targetMapping); protect(target.first, targetMapping); protect(target.second, targetMapping);
    }
    for (const auto& calculation : live.layer->m_effectManager->m_unkVector708) {
        auto* object = calculation.m_gameObject;
        if (object && object->m_groups) for (short i = 0; i < object->m_groupCount; ++i) protect((*object->m_groups)[i], dynamicReference);
    }
    // Native getters prepare the lazy optimized arrays before ownership is
    // compiled. Trigger activation and action ordering remain native.
    std::unordered_set<int> membershipGroups;
    for (auto* object : inputObjects) if (object->m_groups)
        for (short i = 0; i < object->m_groupCount; ++i) membershipGroups.insert((*object->m_groups)[i]);
    for (auto group : membershipGroups) {
        if (group <= 0 || static_cast<std::size_t>(group) >= live.layer->m_groups.size()) continue;
        live.layer->getGroup(group);
        live.layer->getOptimizedGroup(group);
        live.layer->getStaticGroup(group);
    }
    // Resolve atlas order from native descendants. The host's atlas call order
    // remains authoritative across materials, clipping nodes and batch nodes.
    std::unordered_set<GameObject*> all(inputObjects.begin(), inputObjects.end()), inserted;
    std::vector<GameObject*> ordered;
    std::unordered_set<CCSpriteBatchNode*> batches;
    for (auto* object : inputObjects) {
        auto* batch = object->getBatchNode();
        if (!batch || !batches.insert(batch).second) continue;
        for (auto* sprite : CCArrayExt<CCSprite, false>(batch->getDescendants())) {
            auto* candidate = typeinfo_cast<GameObject*>(sprite);
            if (all.contains(candidate) && inserted.insert(candidate).second) ordered.push_back(candidate);
        }
    }
    for (auto* object : inputObjects) if (inserted.insert(object).second) ordered.push_back(object);
    live.total = ordered.size();
    live.entries.resize(ordered.size());
    std::vector<Decoration> decorations(ordered.size());
    std::vector<std::string> rejectionReasons(ordered.size());
    std::map<std::tuple<int, int, std::optional<std::uint32_t>, bool>, std::uint32_t> headlessPartitions;
    auto independentColor = [&](GJSpriteColor* color) {
        if (!color) return false;
        const int id = color->getColorMode();
        if (id <= 0 || mutableColorChannels.contains(id) ||
            (color->m_defaultColorID > 0 && mutableColorChannels.contains(color->m_defaultColorID)) ||
            color->m_usesHSV || color->m_usesCustomBlend) return false;
        auto* action = live.layer->m_effectManager->getColorAction(id);
        return action && action->m_copyID == 0 && !action->m_inheritanceNode && action->m_playerColor <= 0;
    };
    for (ObjectId id = 0; id < ordered.size(); ++id) {
        auto* object = ordered[id];
        if (id < 4 && flags.colorShakeFixture) {
            auto* color = object->m_baseColor;
            auto* action = color && color->getColorMode() > 0 ? live.layer->m_effectManager->getColorAction(color->getColorMode()) : nullptr;
            log::info("VULKANIZER_V2_COLOR_FIXTURE base_present={} id={} default_id={} action_present={} copy={} inheritance={} player={} hsv={} custom_blend={} detail_present={}",
                color != nullptr, color ? color->m_colorID : -1, color ? color->m_defaultColorID : -1,
                action != nullptr, action ? action->m_copyID : -1, action && action->m_inheritanceNode,
                action ? action->m_playerColor : -1, color && color->m_usesHSV,
                color && color->m_usesCustomBlend, object->m_detailColor != nullptr);
        }
        auto& entry = live.entries[id];
        entry.object = object;
        entry.reference = {object->m_positionX, object->m_positionY};
        live.ids[object] = id;
        decorations[id].position = entry.reference;
        const auto anchor = object->getAnchorPoint();
        decorations[id].nativeTransform = {entry.reference, object->getRotationX(), object->getRotationY(),
            object->getScaleX(), object->getScaleY(), object->getSkewX(), object->getSkewY(),
            anchor.x, anchor.y, object->isFlipX(), object->isFlipY()};
        decorations[id].dependency = Dependency::authoritativeCpu;
        auto reason = rejection(object, protectedGroups, uncertain);
        const bool headlessMaterial = flags.headlessMaterial &&
            flags.headless && !object->isVisible() && !object->getBatchNode() && !object->getTextureAtlas();
        if (reason.empty() && !headlessMaterial && flags.headlessAlpha)
            for (short i = 0; i < object->m_groupCount; ++i)
                if (alphaTargets.contains((*object->m_groups)[i])) { reason = "native_alpha_render_state"; break; }
        if (reason.empty() && localizedMaterials && !headlessMaterial && !mutableColorChannels.empty() &&
            (!independentColor(object->m_baseColor) || (object->m_detailColor && !independentColor(object->m_detailColor))))
            reason = "mutable_or_unresolved_color_channel";
        if (reason == "native_inactive") {
            if (!object->isVisible()) ++live.inactiveReadiness["invisible"];
            if (object->m_isGroupDisabled || object->m_isGroupDisabledTemp || object->m_isHide)
                ++live.inactiveReadiness["logically_disabled_or_hidden"];
            if (object->getBatchNode() && object->getTextureAtlas()) {
                ++live.inactiveReadiness["batched"];
                if (!object->isVisible() && !object->m_isGroupDisabled && !object->m_isGroupDisabledTemp && !object->m_isHide)
                    ++live.inactiveReadiness["batched_invisible_logically_active"];
            }
        }
        if (!reason.empty()) { rejectionReasons[id] = reason; continue; }
        if (!object->isVisible() && !object->getBatchNode() && !object->getTextureAtlas()) {
            entry.headless = true;
            entry.disabledHeadless = flags.disabledCamera && object->m_isGroupDisabled;
            if (!object->m_isDecoration2) {
                entry.initialStamp = static_cast<std::uint32_t>(object->m_unk4C4);
                entry.historyBase = entry.reference;
                entry.initialPrevious = {object->m_lastPosition.x, object->m_lastPosition.y};
            }
            decorations[id].visible = false;
            decorations[id].dependency = Dependency::decorativeTranslation;
            const auto key = std::make_tuple(object->m_outerSectionIndex, object->m_middleSectionIndex, entry.initialStamp, entry.disabledHeadless);
            auto [partition, added] = headlessPartitions.try_emplace(key, static_cast<std::uint32_t>(headlessPartitions.size() + 1));
            decorations[id].chainPartition = partition->second;
            continue;
        }
        object->updateTransform();
        const auto quad = object->getQuad();
        const ccV3F_C4B_T2F corners[]{quad.bl, quad.br, quad.tl, quad.tr};
        bool finiteQuad = true;
        for (const auto& corner : corners)
            finiteQuad &= std::isfinite(corner.vertices.x) && std::isfinite(corner.vertices.y) &&
                std::isfinite(corner.vertices.z) && std::isfinite(corner.texCoords.u) && std::isfinite(corner.texCoords.v);
        if (!finiteQuad) { rejectionReasons[id] = "nonfinite_baked_quad"; continue; }
        entry.batch = object->getBatchNode();
        entry.atlas = object->getTextureAtlas();
        entry.slot = object->getAtlasIndex();
        auto& atlas = live.atlases[entry.atlas.data()];
        atlas.batch = entry.batch;
        atlas.objects.push_back(id);
        decorations[id].material = static_cast<MaterialId>(std::distance(batches.begin(), batches.find(entry.batch.data())));
        decorations[id].dependency = Dependency::decorativeTranslation;
        for (unsigned corner = 0; corner < 4; ++corner) {
            const auto& value = corners[corner];
            decorations[id].quad[corner] = {value.vertices.x, value.vertices.y, value.vertices.z,
                value.texCoords.u, value.texCoords.v, {value.colors.r, value.colors.g, value.colors.b, value.colors.a}};
        }
    }
    if (collectCensus) {
        live.censusMasks.resize(ordered.size());
        live.censusProtectionCauses.resize(ordered.size());
        std::set<std::vector<short>> candidateChains;
        std::set<std::vector<short>> v1ParentChains;
        std::set<std::vector<short>> structuralParentChains;
        for (ObjectId id = 0; id < ordered.size(); ++id) {
            auto* o = ordered[id];
            std::uint64_t mask = 0;
            auto flag = [&](unsigned bit, bool value) { if (value) mask |= 1ull << bit; };
            flag(0, o->m_objectType != GameObjectType::Decoration);
            flag(1, o->m_classType != GameObjectClassType::Game || o->m_isTrigger || o->m_isStartPos);
            flag(2, !o->m_groups || !o->m_groupCount);
            bool protectedMember = false;
            std::uint16_t causes = 0;
            std::vector<short> groups;
            if (o->m_groups) for (short j = 0; j < o->m_groupCount; ++j) {
                const auto group = (*o->m_groups)[j];
                groups.push_back(group);
                protectedMember |= protectedGroups.contains(group);
                auto found = protectionCauses.find(group);
                if (found != protectionCauses.end()) causes |= found->second;
            }
            flag(3, protectedMember);
            flag(4, o->m_hasGroupParent || o->m_hasAreaParent || (o->m_parentMode != 0 && o->m_parentMode != -1) || o->m_linkedGroup);
            flag(5, o->m_particle || o->m_hasParticles || o->m_hasAnimatedChild || o->m_isUIObject);
            flag(6, !o->m_isDecoration2 || !o->m_isDontEnter || !o->m_isDontFade);
            flag(7, o->m_tempOffsetXRelated || o->m_positionXOffset || o->m_positionYOffset);
            flag(8, o->m_colorSprite || o->m_glowSprite || o->getChildrenCount());
            flag(9, o->getScaleX() != 1 || o->getScaleY() != 1 || o->getRotationX() || o->getRotationY() || o->getSkewX() || o->getSkewY() || o->isFlipX() || o->isFlipY());
            flag(10, !o->isVisible() || o->m_isGroupDisabled || o->m_isGroupDisabledTemp || o->m_isHide);
            flag(11, !o->getBatchNode() || !o->getTextureAtlas());
            flag(12, o->getBatchNode() && o->getBatchNode()->getShaderProgram() != CCShaderCache::sharedShaderCache()->programForKey(kCCShader_PositionTextureColor));
            flag(13, !std::isfinite(o->m_positionX) || !std::isfinite(o->m_positionY) || o->m_outerSectionIndex < 0 || o->m_middleSectionIndex < 0);
            flag(14, uncertain);
            flag(15, (o->m_baseColor && live.colorTargets.contains(o->m_baseColor->m_colorID)) ||
                     (o->m_detailColor && live.colorTargets.contains(o->m_detailColor->m_colorID)));
            flag(16, !live.shakeTargets.empty());
            flag(17, o->m_hasGroupParent); flag(18, o->m_hasAreaParent); flag(19, o->m_parentMode > 0);
            flag(20, o->m_linkedGroup != 0); flag(21, o->m_particle != nullptr); flag(22, o->m_hasParticles);
            flag(23, o->m_hasAnimatedChild); flag(24, o->m_isUIObject); flag(25, !o->m_isDecoration2);
            flag(26, !o->m_isDontEnter); flag(27, !o->m_isDontFade); flag(28, o->m_tempOffsetXRelated);
            flag(29, o->m_positionXOffset != 0); flag(30, o->m_positionYOffset != 0);
            flag(31, o->m_colorSprite != nullptr); flag(32, o->m_glowSprite != nullptr); flag(33, o->getChildrenCount() != 0);
            flag(34, o->getScaleX() != 1 || o->getScaleY() != 1); flag(35, o->getRotationX() != 0 || o->getRotationY() != 0);
            flag(36, o->getSkewX() != 0 || o->getSkewY() != 0); flag(37, o->isFlipX() || o->isFlipY());
            flag(38, o->m_parentMode < 0);
            live.censusMasks[id] = mask;
            live.censusProtectionCauses[id] = causes;
            if (!(mask & (0x3ffu & ~(1u << 4) & ~(1u << 9))) && !(mask & ((1ull<<17)|(1ull<<18)|(1ull<<19)|(1ull<<20)))) {
                auto chainGroups = groups;
                std::sort(chainGroups.begin(), chainGroups.end());
                chainGroups.erase(std::unique(chainGroups.begin(), chainGroups.end()), chainGroups.end());
                structuralParentChains.insert(std::move(chainGroups));
            }
            // Visibility and atlas readiness are observations at capture time.
            // Exclude them and the unresolved level-wide veto from this upper bound.
            constexpr std::uint32_t ignored = (1u << 10) | (1u << 11) | (1u << 13) | (1u << 14);
            if (!(mask & 0x3ffu)) {
                std::sort(groups.begin(), groups.end());
                groups.erase(std::unique(groups.begin(), groups.end()), groups.end());
                candidateChains.insert(groups);
            }
            if (!(mask & (0x3ffu & ~(1u << 4))) && !(mask & ((1ull<<17)|(1ull<<18)|(1ull<<19)|(1ull<<20)))) {
                std::sort(groups.begin(), groups.end());
                groups.erase(std::unique(groups.begin(), groups.end()), groups.end());
                v1ParentChains.insert(std::move(groups));
            }
        }
        live.censusCandidateChains = candidateChains.size();
        live.censusV1ParentCandidateChains = v1ParentChains.size();
        live.censusStructuralParentChains = structuralParentChains.size();
    }
    // Every actual native array gets a token. Optimized/static variants may
    // contain different members, so a numeric GD group ID is insufficient.
    auto routeArray = [&](CCArray* array) {
        if (!array || !array->count() || live.routeIndices.contains(array)) return;
        Route route;
        route.token = static_cast<GroupId>(live.routes.size() + 1);
        route.source = array;
        route.native = CCArray::createWithCapacity(array->count());
        route.count = array->count();
        std::unordered_set<ObjectId> unique;
        bool unknownMember = false;
        unsigned slot = 0;
        for (auto* object : CCArrayExt<GameObject, false>(array)) {
            const auto sourceSlot = slot++;
            auto found = live.ids.find(object);
            if (found == live.ids.end()) { unknownMember = true; continue; }
            if (!unique.insert(found->second).second) {
                decorations[found->second].dependency = Dependency::authoritativeCpu;
                if (rejectionReasons[found->second].empty()) rejectionReasons[found->second] = "duplicate_native_array_member";
                continue;
            }
            route.members.push_back(found->second);
            live.entries[found->second].memberships.emplace_back(live.routes.size(), sourceSlot);
            decorations[found->second].groups.push_back(route.token);
        }
        if (unknownMember) for (auto id : route.members) {
            decorations[id].dependency = Dependency::authoritativeCpu;
            if (rejectionReasons[id].empty()) rejectionReasons[id] = "unknown_array_member";
        }
        live.routeIndices[array] = live.routes.size();
        live.routes.push_back(std::move(route));
    };
    for (auto* array : live.layer->m_groups) routeArray(array);
    for (auto* array : live.layer->m_optimizedGroups) routeArray(array);
    for (auto* array : live.layer->m_staticGroups) routeArray(array);
    for (ObjectId id = 0; id < decorations.size(); ++id) {
        if (decorations[id].dependency == Dependency::decorativeTranslation && decorations[id].groups.empty()) {
            decorations[id].dependency = Dependency::authoritativeCpu;
            rejectionReasons[id] = "unresolved_native_group";
        }
    }
    live.scene.emplace(Scene::compile(decorations));
    live.chains.resize(live.scene->chainCount());
    for (ObjectId id = 0; id < live.entries.size(); ++id) {
        auto h = live.scene->handle(id);
        if (live.scene->path(h) != ExecutionPath::sharedChain) continue;
        auto& entry = live.entries[id];
        auto& chain = live.chains[live.scene->chainFor(h)];
        chain.disabledHeadless = entry.disabledHeadless;
        if (entry.initialStamp && !chain.history)
            chain.history.emplace(SharedHistoryPrototype::RouteEvidence{decorations[id].groups, *entry.initialStamp, false});
        chain.objects.push_back(h);
        auto* spaceNode = entry.headless ? static_cast<CCNode*>(live.layer->m_objectLayer) : static_cast<CCNode*>(entry.batch.data());
        auto space = std::find_if(chain.spaces.begin(), chain.spaces.end(), [&](const auto& value) { return value.batch.data() == spaceNode && value.headless == entry.headless; });
        const auto& quad = decorations[id].quad;
        double left = quad[0].x, right = left, bottom = quad[0].y, top = bottom;
        if (entry.headless) {
            auto bounds = entry.object->boundingBox();
            left = bounds.origin.x + entry.reference.x - entry.object->getPositionX();
            bottom = bounds.origin.y + entry.reference.y - entry.object->getPositionY();
            right = left + bounds.size.width;
            top = bottom + bounds.size.height;
        } else {
            for (const auto& corner : quad) {
                left = std::min<double>(left, corner.x); right = std::max<double>(right, corner.x);
                bottom = std::min<double>(bottom, corner.y); top = std::max<double>(top, corner.y);
            }
        }
        if (space == chain.spaces.end()) chain.spaces.push_back({spaceNode, left, right, bottom, top, entry.headless});
        else { space->left = std::min(space->left, left); space->right = std::max(space->right, right);
            space->bottom = std::min(space->bottom, bottom); space->top = std::max(space->top, top); }
        chain.precision.coordinateMagnitude = std::max({chain.precision.coordinateMagnitude,
            std::abs(left), std::abs(right), std::abs(bottom), std::abs(top), std::abs(entry.reference.x), std::abs(entry.reference.y)});
        auto* object = entry.object.data();
        const double fx = live.layer->m_sectionXFactor, fy = live.layer->m_sectionYFactor;
        if (fx < 0 || fy < 0 || (fx == 0 && object->m_outerSectionIndex != 0) ||
            (fy == 0 && object->m_middleSectionIndex != 0)) { chain.minDx = 1; chain.maxDx = -1; }
        if (fx > 0) {
            if (object->m_outerSectionIndex > 0)
                chain.minDx = std::max(chain.minDx, object->m_outerSectionIndex / fx - entry.reference.x);
            chain.maxDx = std::min(chain.maxDx, (object->m_outerSectionIndex + 1) / fx - entry.reference.x);
        }
        if (fy > 0) {
            if (object->m_middleSectionIndex > 0)
                chain.minDy = std::max(chain.minDy, object->m_middleSectionIndex / fy - entry.reference.y);
            chain.maxDy = std::min(chain.maxDy, (object->m_middleSectionIndex + 1) / fy - entry.reference.y);
        }
        if (live.validate && id < 2) log::info("VULKANIZER_V2_BASE object={} native=({},{}) node=({},{}) section=({},{}) factors=({},{}) quad=({},{})",
            id, object->m_positionX, object->m_positionY, object->getPositionX(), object->getPositionY(),
            object->m_outerSectionIndex, object->m_middleSectionIndex, fx, fy, left, bottom);
    }
    std::vector<Handle> nativeOnly;
    for (ChainId id = 0; id < live.chains.size(); ++id) {
        auto& chain = live.chains[id];
        const auto* reason = unsafe(id, {}, 0);
        if (live.validate && reason && id < 8) {
            const auto view = chain.spaces.empty() ? std::optional<Camera>{} : camera(chain.spaces.front().batch.data());
            log::info("VULKANIZER_V2_ADMISSION chain={} reason={} section_delta=({},{},{},{}) camera=({},{},{},{})",
                id, reason, chain.minDx, chain.maxDx, chain.minDy, chain.maxDy,
                view ? view->left : 0, view ? view->right : 0, view ? view->bottom : 0, view ? view->top : 0);
        }
        if (reason || live.baseline) {
            if (reason) for (auto h : chain.objects) rejectionReasons[h.object] = reason;
            else live.eligible += chain.objects.size();
            nativeOnly.insert(nativeOnly.end(), chain.objects.begin(), chain.objects.end());
        } else {
            live.eligible += chain.objects.size();
            for (auto h : chain.objects) {
                auto& entry = live.entries[h.object];
                entry.owned = true;
                ++chain.owned;
                ++live.stats.acquired;
                if (entry.headless) ++live.stats.headlessAcquired;
                if (entry.atlas) live.atlases.at(entry.atlas.data()).plan.insert(entry.slot, live.scene->drawFor(h));
            }
        }
    }
    // Rejected candidates have never been owned. The sink performs no writes.
    struct AdmissionSink : NativeSink {
        void translate(std::span<const ObjectId>, Translation, std::uint64_t) noexcept override {}
        void materialize(ObjectId, Translation, bool) noexcept override {}
        void visibility(ObjectId, bool) noexcept override {}
        void reset(ObjectId, Translation, bool) noexcept override {}
    } admission;
    live.scene->acquireNativeBatch(nativeOnly, admission);
    for (const auto& reason : rejectionReasons) if (!reason.empty()) ++live.rejected[reason];
    if (collectCensus) {
    live.initialMoveRejections = rejectionReasons;

    for (std::size_t id = 0; id < live.entries.size(); ++id) {
        if (live.initialMoveRejections[id].empty()) {
            live.initialMoveRejections[id] =
                live.entries[id].owned
                    ? "initially_admitted"
                    : "native_without_recorded_reason";
        }
    }
}
    live.rebuildNativeRoutes();
    if (!ordered.empty() &&
        (flags.denseOwners || live.cachedPoliciesEnabled)) {

    int minId = ordered.front()->m_uniqueID;
    int maxId = minId;

    for (auto* object : ordered) {
        minId = std::min(minId, object->m_uniqueID);
        maxId = std::max(maxId, object->m_uniqueID);
    }

    const auto span =
        static_cast<std::int64_t>(maxId) - minId + 1;

    constexpr ObjectId invalid =
    std::numeric_limits<ObjectId>::max();

    if (span > 0 && span <= 4000000) {
        live.denseIdBase = minId;
        live.denseIds.assign(static_cast<std::size_t>(span), invalid);
        if (live.cachedPoliciesEnabled) live.moveSectionPolicies.assign(static_cast<std::size_t>(span), 0);
        std::vector<std::uint8_t> duplicateIds(live.cachedPoliciesEnabled ? static_cast<std::size_t>(span) : 0, 0);

        for (ObjectId id = 0; id < ordered.size(); ++id) {
            const auto denseIndex = static_cast<std::size_t>(static_cast<std::int64_t>(ordered[id]->m_uniqueID) - minId);
            auto& slot = live.denseIds[denseIndex];

            if (slot == invalid)
                slot = id;
            else if (live.cachedPoliciesEnabled)
                duplicateIds[denseIndex] = 1;
        }

        if (live.cachedPoliciesEnabled) {
            live.movePolicySceneGeneration = live.scene->generation();
            if (live.unknownMods.empty()) {
                for (std::size_t denseIndex = 0; denseIndex < live.denseIds.size(); ++denseIndex) {
                    const auto id = live.denseIds[denseIndex];
                    if (id == invalid || duplicateIds[denseIndex]) continue;
                    auto flags = movePolicyValid;
                    if (stableMoveSectionEligibility(live.entries[id].object.data()))
                        flags |= movePolicyStructurallyEligible;
                    live.moveSectionPolicies[denseIndex] = flags;
                }
            }
            log::info("VULKANIZER_V2_CACHED_POLICIES enabled=true slots={} scene_generation={} third_party_mods={} stable_predicates=4",
                live.moveSectionPolicies.size(), live.movePolicySceneGeneration, live.unknownMods.size());
        }

        if (flags.denseOwners)
            log::info("VULKANIZER_DENSE_OWNERS objects={} slots={}", ordered.size(), live.denseIds.size());
    }
}
    live.context = wglGetCurrentContext();
    if (live.owned()) {
        live.renderer = std::make_unique<GlRenderer>(resolve);
        live.renderer->attach(*live.scene);
    }
    try { live.gpuTimer = std::make_unique<FrameGpuTimer>(resolve); live.gpuStatus = "async_timestamps_first_atlas_to_swap"; }
    catch (const std::exception& error) { live.gpuStatus = error.what(); }
    live.ready = true;
    live.compiling = false;
    log::info("VULKANIZER_V2_COMPILE scene={} level={} total={} eligible={} owned={} chains={} native_arrays={} atlas_materials={} native_order=atlas_ranges baseline={}",
        live.scene->generation(), live.levelName, live.total, live.eligible, live.owned(), live.scene->chainCount(), live.routes.size(), live.atlases.size(), live.baseline);
    for (const auto& [reason, count] : live.rejected) log::info("VULKANIZER_V2_REJECT reason={} objects={}", reason, count);
    if (live.owned()) log::info("VULKANIZER_V2_OWNERSHIP scene={} transition=Native_to_V2 objects={} reason=level_compilation", live.scene->generation(), live.owned());
}
double percentile(std::span<const double> input, double fraction) {
    std::vector<double> values(input.begin(), input.end());
    if (values.empty()) return 0;
    std::sort(values.begin(), values.end());
    return values[static_cast<std::size_t>(std::ceil(values.size() * fraction)) - 1];
}
void report(const char* reason) {
    if (!state || !state->scene) return;
    const auto& live = *state;
    auto json = matjson::makeObject({{"schema", 2}, {"kind", "v2_live"}, {"reason", reason}, {"level", live.levelName},
        {"total", live.total}, {"eligible", live.eligible}, {"actually_owned", live.owned()}, {"peak_owned", live.stats.acquired},
        {"headless_acquired", live.stats.headlessAcquired}, {"headless_retained", live.stats.headlessAcquired - live.stats.headlessReleased},
        {"headless_eliminated_native_move_member_visits", live.stats.headlessEliminatedVisits},
        {"retained_at_test_completion", live.retainedAtCompletion},
        {"headless_retained_at_test_completion", live.headlessRetainedAtCompletion},
        {"chains", live.scene->chainCount()}, {"max_active_chains", live.stats.maxActiveChains}, {"max_dirty_palette_entries", live.stats.maxDirty},
        {"frames", live.frames}, {"native_move_member_visits", live.stats.nativeMoveVisits}, {"native_section_commit_callbacks", live.stats.nativeCommitCallbacks},
        {"eliminated_native_move_member_visits", live.stats.eliminatedVisits}, {"handoff_cpu_commits", live.stats.handoffCommits},
        {"sprite_transform_entry_visits", live.stats.spriteVisits}, {"native_sprite_geometry_evaluations_suppressed", live.stats.geometrySuppressed},
        {"native_atlas_draws", live.stats.nativeDraws}, {"v2_draws", live.stats.v2Draws}, {"native_atlas_quads", live.stats.nativeQuads}, {"v2_quads", live.stats.v2Quads},
        {"palette_page_boundaries", live.stats.pageBreaks}, {"material_boundaries", live.stats.materialBoundaries}, {"ownership_boundaries", live.stats.ownershipBoundaries},
        {"camera_chain_checks", live.stats.chainCameraChecks}, {"validation_object_visits", live.stats.validationVisits},
        {"dependency_guard_member_visits", live.stats.dependencyGuardVisits},
        {"cached_policies_enabled", live.cachedPoliciesEnabled},
        {"cached_policy_hits", live.stats.cachedPolicyHits}, {"cached_policy_misses", live.stats.cachedPolicyMisses},
        {"structural_predicate_evaluations_avoided", live.stats.structuralPredicatesAvoided},
        {"dense_identity_hits", live.stats.denseIdentityHits}, {"hash_lookup_fallbacks", live.stats.hashLookupFallbacks},
        {"cache_invalidations", live.stats.cacheInvalidations}, {"dynamic_section_checks", live.stats.dynamicSectionChecks},
        {"precompiled_route_hits", live.stats.precompiledRouteHits}, {"route_hash_lookups", live.stats.routeHashLookups},
        {"native_atlas_dirty_payload_bytes", live.stats.nativeAtlasDirtyBytes}, {"native_atlas_upload_events", live.stats.nativeAtlasUploads},
        {"v2_native_commit_violations", live.stats.ownershipCommitViolations},
        {"render_failures", live.stats.renderFailures}, {"test_completed", live.testCompleted},
        {"reference_validation_enabled", live.validate},
        {"validation_readback_bytes", live.stats.validationReadbackBytes}, {"routine_transform_readback_bytes", 0},
        {"routine_v2_cpu_position_commits", 0}, {"routine_geometry_upload_bytes", 0}, {"max_reference_position_error", live.stats.maxDivergence},
        {"max_conservative_pixel_error_bound", live.stats.maxPixelBound}, {"pixel_error_budget", pixelBudget},
        {"cpu_frame_p50_ms", percentile(live.cpuFrames, .5)}, {"cpu_frame_p95_ms", percentile(live.cpuFrames, .95)}, {"cpu_frame_p99_ms", percentile(live.cpuFrames, .99)},
        {"gpu_timing_status", live.gpuStatus},
        {"native_fallback_drawing", "original_contiguous_atlas_ranges"}, {"runtime_native_to_v2", 0}});
    static constexpr std::array invalidationNames{
        "layer_group_add", "layer_group_remove", "group_parent_add", "group_parent_remove",
        "group_parent_set", "group_parent_remove_one", "group_parent_promote", "group_parent_load",
        "object_type", "start_position", "object_group_add", "object_group_remove", "object_reset",
        "retirement", "scene_destroy"
    };
    static_assert(invalidationNames.size() == static_cast<std::size_t>(MovePolicyInvalidation::count));
    auto invalidations = matjson::Value::object();
    for (std::size_t i = 0; i < invalidationNames.size(); ++i)
        invalidations[invalidationNames[i]] = live.stats.cacheInvalidationsBySource[i];
    json["cache_invalidations_by_source"] = std::move(invalidations);
    json["cache_invalidations_after_ready"] = live.stats.cacheInvalidationsAfterReady;
    if (live.validate) {
        json["dense_ownership_validation_samples"] = live.stats.denseOwnershipSamples;
        json["dense_ownership_validation_mismatches"] = live.stats.denseOwnershipMismatches;
    }
    json["level_time"] = live.layer->m_gameState.m_levelTime;
    json["native_progress_wall_s"] = live.progressStart == Clock::time_point{} ? 0 : std::chrono::duration<double>(Clock::now() - live.progressStart).count();
    json["cpu_while_owned_samples"] = live.cpuOwnedFrames.size();
    if (!live.cpuOwnedFrames.empty()) {
        json["cpu_while_owned_p50_ms"] = percentile(live.cpuOwnedFrames, .5);
        json["cpu_while_owned_p95_ms"] = percentile(live.cpuOwnedFrames, .95);
        json["cpu_while_owned_p99_ms"] = percentile(live.cpuOwnedFrames, .99);
    }
    if (live.renderer) {
        const auto& counters = live.renderer->counters();
        json["initial_geometry_and_palette_upload_bytes"] = counters.initialUploadBytes;
        json["palette_upload_bytes"] = counters.paletteUploadBytes;
        json["draw_uniform_upload_bytes"] = counters.drawUniformUploadBytes;
    }
    if (live.gpuTimer && !live.gpuTimer->samples().empty()) {
        json["gpu_frame_p50_ms"] = percentile(live.gpuTimer->samples(), .5);
        json["gpu_frame_p95_ms"] = percentile(live.gpuTimer->samples(), .95);
        json["gpu_frame_p99_ms"] = percentile(live.gpuTimer->samples(), .99);
        json["gpu_samples"] = live.gpuTimer->samples().size();
        json["gpu_samples_skipped_without_waiting"] = live.gpuTimer->skipped();
    }
    if (live.capture) json["capture"] = *live.capture;
    if (live.toggleFixtureTrace) json["native_toggle_fixture"] = *live.toggleFixtureTrace;
    if (live.benchmarkFinished && !live.cpuBenchmarkFrames.empty()) {
        json["level_80_90"] = matjson::makeObject({
            {"level_start", 80}, {"level_end", 90}, {"frames", live.cpuBenchmarkFrames.size()},
            {"cpu_frame_p50_ms", percentile(live.cpuBenchmarkFrames, .5)},
            {"cpu_frame_p95_ms", percentile(live.cpuBenchmarkFrames, .95)},
            {"cpu_frame_p99_ms", percentile(live.cpuBenchmarkFrames, .99)},
            {"native_move_member_visits", live.benchmarkEnd.nativeMoveVisits - live.benchmarkStart.nativeMoveVisits},
            {"eliminated_native_move_member_visits", live.benchmarkEnd.eliminatedVisits - live.benchmarkStart.eliminatedVisits},
            {"gpu_timing", "not isolated for this interval"}});
    }
    if (live.structuralHandoffTest) {
        json["structural_handoff_fixture"] = matjson::makeObject({{"applied", true}, {"all_were_v2_owned", live.structuralHandoffOwned}});
        json["structural_handoff_fixture"]["objects"] = matjson::Value::array();
        for (auto* o : live.structuralHandoffObjects) json["structural_handoff_fixture"]["objects"].push(matjson::makeObject({
            {"position_x", o->m_positionX}, {"position_y", o->m_positionY},
            {"rotation_x", o->getRotationX()}, {"rotation_y", o->getRotationY()},
            {"scale_x", o->getScaleX()}, {"scale_y", o->getScaleY()},
            {"skew_x", o->getSkewX()}, {"skew_y", o->getSkewY()},
            {"anchor_x", o->getAnchorPoint().x}, {"anchor_y", o->getAnchorPoint().y},
            {"flip_x", o->isFlipX()}, {"flip_y", o->isFlipY()}}));
    }
    json["rejections"] = matjson::Value::object();
    for (const auto& [key, value] : live.rejected) json["rejections"][key] = value;
    json["inactive_readiness"] = matjson::Value::object();
    for (const auto& [key, value] : live.inactiveReadiness) json["inactive_readiness"][key] = value;
    json["ownership_handoffs"] = matjson::Value::object();
    for (const auto& [key, value] : live.transitions) json["ownership_handoffs"][key] = value;
    json["unsupported_trigger_ids"] = matjson::Value::object();
    for (const auto& [key, value] : live.unknownTriggers) json["unsupported_trigger_ids"][std::to_string(key)] = value;
    json["unreviewed_loaded_mods"] = matjson::Value::array();
    for (const auto& name : live.unknownMods) json["unreviewed_loaded_mods"].push(name);
    if (!live.censusMasks.empty() && (std::string_view(reason) == "test_complete" || std::string_view(reason) == "director_purge")) {
        auto triggers = matjson::makeObject({{"color_copy_references", live.colorCopy}, {"spawn_triggered", live.triggeredBySpawn}, {"touch_triggered", live.triggeredByTouch}});
        triggers["color_channel_targets"] = matjson::Value::object();
        for (auto [id, count] : live.colorTargets) triggers["color_channel_targets"][std::to_string(id)] = count;
        triggers["shake_target_group_field"] = matjson::Value::object();
        for (auto [id, count] : live.shakeTargets) triggers["shake_target_group_field"][std::to_string(id)] = count;
        json["trigger_899_1520"] = std::move(triggers);
    }
    if (!live.censusMasks.empty() && (std::string_view(reason) == "test_complete" || std::string_view(reason) == "director_purge")) {
        static constexpr const char* labels[]{"non_decoration", "object_class", "no_membership", "protected_group", "parent_or_linked", "animated_particle_or_ui", "history_enter_fade", "position_offset", "compound_sprite", "local_transform", "initially_inactive", "initially_unbatched", "custom_shader_observed", "spatial_state_unavailable", "unresolved_level_dependency", "direct_color_channel_target", "camera_shake_level", "group_parent", "area_parent", "parent_mode_positive", "linked_group", "particle_pointer", "has_particles", "animated_child", "ui_object", "non_decoration2", "enter_effect", "fade_effect", "temporary_x_offset", "position_x_offset", "position_y_offset", "color_sprite", "glow_sprite", "children", "scale", "rotation", "skew", "flip", "parent_mode_negative"};
        std::array<std::uint64_t, 39> objects{}, visits{};
        std::array<std::uint64_t, 10> causeObjects{}, causeVisits{};
        std::array<std::uint64_t, 4> stageObjects{}, stageVisits{};
        // These are cumulative hypothetical screens over known compile-time
        // attributes, not ownership or predictions of speedup.
        constexpr std::uint64_t core = (1ull << 15) - 1;
        constexpr std::uint64_t readinessAndVeto = (1ull << 10) | (1ull << 11) | (1ull << 13) | (1ull << 14);
        const std::array<std::uint64_t, 4> ignoredStages{
            readinessAndVeto,
            readinessAndVeto | (1ull << 9),
            readinessAndVeto | (1ull << 9) | (1ull << 6),
            readinessAndVeto | (1ull << 9) | (1ull << 6) | (1ull << 3)};
        std::uint64_t candidateObjects = 0, v1ParentCandidates = 0, v1ParentCandidateVisits = 0, fullyCompatible = 0, coveredVisits = 0;
        std::uint64_t structuralParentCandidates = 0, structuralParentVisits = 0;
        std::uint64_t fundamental = 0, functionality = 0, implementation = 0;
        constexpr std::uint32_t ignored = (1u << 10) | (1u << 11) | (1u << 13) | (1u << 14);
        for (std::size_t id = 0; id < live.censusMasks.size(); ++id) {
            const auto mask = live.censusMasks[id];
            for (unsigned bit = 0; bit < objects.size(); ++bit) if (mask & (1ull << bit)) ++objects[bit];
            for (unsigned bit = 0; bit < causeObjects.size(); ++bit)
                if (live.censusProtectionCauses[id] & (1u << bit)) ++causeObjects[bit];
            for (unsigned stage = 0; stage < ignoredStages.size(); ++stage)
                if (!(mask & core & ~ignoredStages[stage])) ++stageObjects[stage];
            if (!(mask & 0x3ffu)) ++candidateObjects;
            if (!(mask & (0x3ffu & ~(1u << 4))) && !(mask & ((1ull<<17)|(1ull<<18)|(1ull<<19)|(1ull<<20)))) ++v1ParentCandidates;
            if (!(mask & (0x3ffu & ~(1u << 4) & ~(1u << 9))) && !(mask & ((1ull<<17)|(1ull<<18)|(1ull<<19)|(1ull<<20)))) ++structuralParentCandidates;
            if (!mask) ++fullyCompatible;
            if (mask & 3u) ++fundamental;
            else if (mask & ((1u<<3)|(1u<<4)|(1u<<5)|(1u<<7)|(1u<<8)|(1u<<12))) ++functionality;
            else if (mask) ++implementation;
        }
        std::map<std::string, std::uint64_t> rejectionVisits;
        for (const auto& route : live.routes) if (route.censusCalls) {
            for (auto id : route.members) {
                coveredVisits += route.censusCalls;
                rejectionVisits[live.initialMoveRejections[id]]
                += route.censusCalls;
                const auto mask = live.censusMasks[id];
                for (unsigned bit = 0; bit < causeVisits.size(); ++bit)
                    if (live.censusProtectionCauses[id] & (1u << bit)) causeVisits[bit] += route.censusCalls;
                for (unsigned stage = 0; stage < ignoredStages.size(); ++stage)
                    if (!(mask & core & ~ignoredStages[stage])) stageVisits[stage] += route.censusCalls;
                if (!(mask & (0x3ffu & ~(1u << 4))) && !(mask & ((1ull<<17)|(1ull<<18)|(1ull<<19)|(1ull<<20))))
                    v1ParentCandidateVisits += route.censusCalls;
                if (!(mask & (0x3ffu & ~(1u << 4) & ~(1u << 9))) && !(mask & ((1ull<<17)|(1ull<<18)|(1ull<<19)|(1ull<<20))))
                    structuralParentVisits += route.censusCalls;
                for (unsigned bit = 0; bit < visits.size(); ++bit) if (mask & (1ull << bit)) visits[bit] += route.censusCalls;
            }
        }
        auto census = matjson::makeObject({{"scope", "all_loaded_objects_independent_overlapping_reasons"},
            {"potential_candidates_excluding_transient_readiness_and_unresolved_level_veto", candidateObjects},
            {"potential_membership_chains", live.censusCandidateChains}, {"fully_compatible_now", fullyCompatible},
            {"potential_candidates_with_v1_nonpositive_parent_mode", v1ParentCandidates},
            {"potential_chains_with_v1_nonpositive_parent_mode", live.censusV1ParentCandidateChains},
            {"potential_v1_parent_candidate_move_visits", v1ParentCandidateVisits},
            {"prospective_structural_and_nonpositive_parent_objects", structuralParentCandidates},
            {"prospective_structural_and_nonpositive_parent_membership_chains", live.censusStructuralParentChains},
            {"prospective_structural_and_nonpositive_parent_observed_move_visits", structuralParentVisits},
            {"prospective_scope", "upper bound only: ignores transient readiness and unresolved level veto; structural and parent compatibility not proven generally"},
            {"fundamental_priority_category", fundamental}, {"additional_functionality_priority_category", functionality},
            {"implementation_limitations_priority_category", implementation}, {"covered_native_move_visits", coveredVisits},
            {"native_move_visits_total", live.stats.nativeMoveVisits}, {"work_scope", "observed_compiled_array_move_calls_only_overlapping_reasons"}});
        census["reasons"] = matjson::Value::object();
        for (unsigned bit = 0; bit < objects.size(); ++bit)
            census["reasons"][labels[bit]] = matjson::makeObject({{"objects", objects[bit]}, {"observed_move_visits", visits[bit]}});
        static constexpr const char* causeLabels[]{"center_or_rotation_reference", "player_x_lock_recipient",
            "other_dynamic_move_target", "non_move_target", "target_group_mapping", "dynamic_reference",
            "trigger_1346_target", "trigger_1007_target", "trigger_1049_target", "trigger_1006_target"};
        census["protection_causes_overlapping"] = matjson::Value::object();
        for (unsigned bit = 0; bit < causeObjects.size(); ++bit)
            census["protection_causes_overlapping"][causeLabels[bit]] = matjson::makeObject({{"objects", causeObjects[bit]}, {"observed_move_visits", causeVisits[bit]}});
        static constexpr const char* stageLabels[]{"ignore_unresolved_veto_and_initial_readiness", "plus_static_transforms",
            "plus_history_enter_fade", "plus_protected_groups"};
        census["cumulative_hypothetical_screens"] = matjson::Value::object();
        for (unsigned stage = 0; stage < ignoredStages.size(); ++stage)
            census["cumulative_hypothetical_screens"][stageLabels[stage]] = matjson::makeObject({
                {"objects", stageObjects[stage]}, {"observed_move_visits", stageVisits[stage]}});
        census["hypothetical_screen_scope"] = "upper bounds, not eligibility: ignores only named blockers; unknown shader and indirect material dependencies remain unresolved; reasons overlap";
        json["move_rejection_workload"] = matjson::Value::object();

for (const auto& [reason, visits] : rejectionVisits) {
    json["move_rejection_workload"][reason] = visits;
}
        json["eligibility_census"] = std::move(census);
    }
    log::info("VULKANIZER_V2_REPORT {}", json.dump(matjson::NO_INDENTATION));
    if (const auto& file = envFlags().reportPath) { std::ofstream stream(*file); stream << json.dump(); }
}
}
bool requested() {
    static const bool enabled = envFlags().v2 || Mod::get()->getSettingValue<bool>("experimental-v2-shared-chains");
    return enabled;
}
bool moveSectionsRequested() { return envFlags().moveSections && !envFlags().baseline; }
bool cachedPoliciesRequested() { return envFlags().cachedPolicies; }
bool canSkipMoveSection(GJBaseGameLayer* layer, GameObject* object) {
    return stableMoveSectionEligibility(object) && dynamicMoveSectionEligibility(layer, object);
}
CachedMoveSectionResult cachedMoveSection(GJBaseGameLayer* layer, GameObject* object) {
    if (!state || state->layer != layer || !state->ready || state->internal || !state->cachedPoliciesEnabled)
        return CachedMoveSectionResult::notApplicable;

    auto& live = *state;
    constexpr ObjectId invalid = std::numeric_limits<ObjectId>::max();
    ObjectId id = invalid;
    std::size_t denseIndex = 0;
    if (object) {
        const auto candidate = static_cast<std::int64_t>(object->m_uniqueID) - live.denseIdBase;
        if (candidate >= 0 && static_cast<std::size_t>(candidate) < live.denseIds.size()) {
            denseIndex = static_cast<std::size_t>(candidate);
            const auto mapped = live.denseIds[denseIndex];
            if (mapped < live.entries.size() && live.entries[mapped].object.data() == object) {
                id = mapped;
                ++live.stats.denseIdentityHits;
            }
        }
    }

    if (id == invalid) {
        ++live.stats.cachedPolicyMisses;
        ++live.stats.hashLookupFallbacks;
        if (object) {
            const auto found = live.ids.find(object);
            if (found != live.ids.end() && found->second < live.entries.size() &&
                live.entries[found->second].object.data() == object) {
                recordSectionCommitKnown(found->second, object);
                return CachedMoveSectionResult::native;
            }
        }
        ++live.stats.nativeCommitCallbacks;
        return CachedMoveSectionResult::native;
    }

    if (live.movePolicySceneGeneration != live.scene->generation() ||
        denseIndex >= live.moveSectionPolicies.size() ||
        !(live.moveSectionPolicies[denseIndex] & movePolicyValid)) {
        ++live.stats.cachedPolicyMisses;
        recordSectionCommitKnown(id, object);
        return CachedMoveSectionResult::native;
    }

    ++live.stats.cachedPolicyHits;
    live.stats.structuralPredicatesAvoided += cachedStructuralPredicateCount;
    if (!(live.moveSectionPolicies[denseIndex] & movePolicyStructurallyEligible) || live.entries[id].owned) {
        recordSectionCommitKnown(id, object);
        return CachedMoveSectionResult::native;
    }

    ++live.stats.dynamicSectionChecks;
    if (dynamicMoveSectionEligibility(layer, object))
        return CachedMoveSectionResult::skip;

    recordSectionCommitKnown(id, object);
    return CachedMoveSectionResult::native;
}
void invalidateMoveSectionPolicy(GameObject* object, MovePolicyInvalidation source) {
    if (!state || !state->cachedPoliciesEnabled) return;
    auto& live = *state;
    ++live.stats.cacheInvalidations;
    ++live.stats.cacheInvalidationsBySource[static_cast<std::size_t>(source)];
    if (live.ready) ++live.stats.cacheInvalidationsAfterReady;
    live.recentMoveArray = nullptr;
    live.recentMoveRoute = std::numeric_limits<std::size_t>::max();
    live.recentMoveSceneGeneration = 0;
    if (!object || live.moveSectionPolicies.empty()) return;
    const auto found = live.ids.find(object);
    if (found == live.ids.end() || found->second >= live.entries.size() ||
        live.entries[found->second].object.data() != object) return;
    const auto denseIndex = static_cast<std::int64_t>(object->m_uniqueID) - live.denseIdBase;
    if (denseIndex < 0 || static_cast<std::size_t>(denseIndex) >= live.denseIds.size() ||
        live.denseIds[denseIndex] != found->second) return;
    live.moveSectionPolicies[denseIndex] = 0;
}
void invalidateAllMoveSectionPolicies(MovePolicyInvalidation source) {
    if (!state || !state->cachedPoliciesEnabled) return;
    auto& live = *state;
    ++live.stats.cacheInvalidations;
    ++live.stats.cacheInvalidationsBySource[static_cast<std::size_t>(source)];
    if (live.ready) ++live.stats.cacheInvalidationsAfterReady;
    live.recentMoveArray = nullptr;
    live.recentMoveRoute = std::numeric_limits<std::size_t>::max();
    live.recentMoveSceneGeneration = 0;
    std::fill(live.moveSectionPolicies.begin(), live.moveSectionPolicies.end(), 0);
}
void beforeObjectRetirement(GameObject* object) {
    if (!object) return;
    release(object, "native_object_retirement");
    invalidateMoveSectionPolicy(object, MovePolicyInvalidation::retirement);
}
namespace {
constexpr ObjectId invalidObjectId = std::numeric_limits<ObjectId>::max();

ObjectId hashObjectId(const Live& live, CCSprite* sprite) {
    const auto found = live.ids.find(sprite);
    return found == live.ids.end() ? invalidObjectId : found->second;
}

ObjectId ownedLookupId(Live& live, GameObject* object) {
    if (!object) return invalidObjectId;
    const auto index = static_cast<std::int64_t>(object->m_uniqueID) - live.denseIdBase;
    if (index >= 0 && static_cast<std::size_t>(index) < live.denseIds.size()) {
        const auto id = live.denseIds[index];
        if (id < live.entries.size() && live.entries[id].object.data() == object) {
            if (live.validate && (live.stats.denseOwnershipCalls++ & 1023) == 0) {
                ++live.stats.denseOwnershipSamples;
                if (hashObjectId(live, object) != id) {
                    ++live.stats.denseOwnershipMismatches;
                    return hashObjectId(live, object);
                }
            }
            return id;
        }
    }
    return hashObjectId(live, object);
}
}
bool owns(CCSprite* sprite) {
    if (!state || state->internal || !state->ready || !state->owned()) return false;
    // Plain Cocos sprites have no GD object ID.
    const auto id = hashObjectId(*state, sprite);
    return id != invalidObjectId && state->entries[id].owned;
}

bool owns(GameObject* object) {
    if (!object || !state || state->internal || !state->ready || !state->owned()) return false;
    const auto id = ownedLookupId(*state, object);
    return id != invalidObjectId && state->entries[id].owned;
}

bool ownsHeadlessMaterial(GameObject* object) {
    if (!object || !envFlags().headlessMaterial || !owns(object)) return false;
    auto found = state->ids.find(object);
    return found != state->ids.end() && state->entries[found->second].headless && !object->getBatchNode() && !object->getTextureAtlas();
}
void beforeHistoryRead(GameObject* object) {
    if (object && !object->m_isDecoration2 && owns(object))
        release(object, "native_rectangle_history_read");
}
bool retainVisibility(GameObject* object, bool visible) {
    if (!object || !controlledToggleVisibility() || !owns(object)) return false;
    auto found = state->ids.find(object);
    if (found == state->ids.end()) return false;
    auto& entry = state->entries[found->second];
    try { return state->atlases.at(entry.atlas.data()).plan.setVisible(entry.slot, visible); }
    catch (...) { release(object, "visibility_plan_failure"); return false; }
}
bool retainActivation(GameObject* object) {
    return object && controlledToggleVisibility() && owns(object);
}
bool activeFor(GJBaseGameLayer* layer) { return state && state->layer == layer && state->ready; }
void releaseArray(CCArray* objects, const char* reason) {
    if (!state || state->internal || !state->ready || !state->owned() || !objects) return;
    std::vector<Handle> affected;
    for (auto* object : CCArrayExt<GameObject, false>(objects)) {
        ++state->stats.dependencyGuardVisits;
        auto id = state->ids.find(object);
        if (id != state->ids.end() && state->entries[id->second].owned) affected.push_back(state->scene->handle(id->second));
    }
    handoff(affected, reason);
}
void beginLevel(PlayLayer* layer) {
    const auto& flags = envFlags();
    if (!requested()) return;
    if (state) destroy(state->layer, "level_replacement");
    static bool fixturePrepared = false;
    if (flags.headlessFixture && flags.sharedHistory &&
        flags.test && !flags.levelName) {
        for (auto* object : CCArrayExt<GameObject, false>(layer->m_objects))
            if (object->m_objectType == GameObjectType::Decoration) object->m_isDecoration2 = false;
    }
    if (flags.toggleFixture && flags.test &&
        !flags.levelName && layer->m_objects) {
        unsigned found = 0;
        for (auto* object : CCArrayExt<GameObject, false>(layer->m_objects)) {
            if (object->m_objectID != 1757 || !object->m_groups) continue;
            bool member = false;
            for (short i = 0; i < object->m_groupCount; ++i) member |= (*object->m_groups)[i] == 9998;
            if (!member) continue;
            if (++found == 2) { object->m_isDecoration2 = false; break; }
        }
    }
    if (flags.xlockFixture && flags.test &&
        !flags.levelName && layer->m_objects) {
        for (auto* object : CCArrayExt<GameObject, false>(layer->m_objects)) {
            auto* effect = typeinfo_cast<EffectGameObject*>(object);
            if (effect && object->m_objectID == 901) {
                effect->m_lockToPlayerX = true;
                log::info("VULKANIZER_V2_XLOCK_FIXTURE native_move_trigger_enabled");
                break;
            }
        }
    }
    if (flags.structuralFixture && flags.test &&
        !flags.levelName && !fixturePrepared && layer->m_objects && layer->m_objects->count() >= 64) {
        unsigned i = 0;
        for (auto* object : CCArrayExt<GameObject, false>(layer->m_objects)) {
            if (object->m_objectID != 1757) continue;
            object->m_parentMode = -1;
            switch (i++ % 4) {
                case 0: object->setRotation(27); object->setAnchorPoint({.25f, .75f}); break;
                case 1: object->setScaleX(1.3f); object->setScaleY(.75f); break;
                case 2: object->setSkewX(12); object->setSkewY(-7); break;
                case 3: object->setFlipX(true); object->setFlipY(true); break;
            }
        }
        fixturePrepared = i > 0;
        log::info("VULKANIZER_V2_STRUCTURAL_FIXTURE objects={}", i);
    }
    state = std::make_unique<Live>();
    state->layer = layer;
    state->baseline = flags.baseline;
    state->cachedPoliciesEnabled = flags.cachedPolicies && !state->baseline;
    state->validate = flags.validate;
    state->levelName = layer->m_level->m_levelName;
    state->cpuFrames.reserve(4096);
    state->cpuOwnedFrames.reserve(4096);
}
void release(GameObject* object, const char* reason) {
    if (!state || state->internal || state->compiling || !state->ready) return;
    if (!state->owned()) return;
    const auto id = ownedLookupId(*state, object);
    if (id == invalidObjectId || !state->entries[id].owned) return;
    const Handle h = state->scene->handle(id);
    handoff(std::span<const Handle>(&h, 1), reason);
}
void releaseAll(const char* reason) {
    if (!state || state->internal || state->compiling || !state->scene || !state->owned()) return;
    std::vector<Handle> handles;
    for (ObjectId id = 0; id < state->entries.size(); ++id)
        if (state->entries[id].owned) handles.push_back(state->scene->handle(id));
    handoff(handles, reason);
}
void destroy(PlayLayer* layer, const char* reason) {
    if (!state || state->layer != layer) return;
    releaseAll(reason);
    invalidateAllMoveSectionPolicies(MovePolicyInvalidation::sceneDestroy);
    report(reason);
    if (state->renderer && state->context != wglGetCurrentContext()) state->renderer->abandonContext();
    if (state->gpuTimer && state->context != wglGetCurrentContext()) state->gpuTimer->abandonContext();
    state.reset();
}
void beforeVisibility(PlayLayer* layer) {
    if (!state || state->layer != layer || !state->ready || !state->owned()) return;
    if (state->context != wglGetCurrentContext()) {
        releaseAll("context_replacement");
        if (state->renderer) state->renderer->abandonContext();
        if (state->gpuTimer) state->gpuTimer->abandonContext();
        state->renderer.reset();
        state->gpuTimer.reset();
        return;
    }
    CameraCache cameras;

for (ChainId id = 0; id < state->chains.size(); ++id) {
    const auto& chain = state->chains[id];
    if (!chain.owned) continue;

    ++state->stats.chainCameraChecks;

    if (auto* reason = unsafe(
        id,
        state->scene->chainTranslation(id),
        chain.precision.accumulatedError,
        &cameras
    )) {
        handoffChain(id, reason);
        cameras.clear();
    }
}
}
void afterVisibility(PlayLayer* layer) { if (state && state->layer == layer) state->visiblePass = true; }
void beforeDependencies(GJBaseGameLayer* layer) {
    if (!state || state->layer != layer || !state->ready || !state->owned()) return;
    for (const auto& calculation : layer->m_effectManager->m_unkVector708) release(calculation.m_gameObject, "dynamic_move_anchor");
    for (auto* action : layer->m_effectManager->m_unkVector5b0) {
        if (!action) continue;
        auto releaseGroup = [&](int group) {
            if (group <= 0 || static_cast<std::size_t>(group) >= layer->m_groups.size()) return;
            auto found = state->routeIndices.find(layer->m_groups[group]);
            if (found == state->routeIndices.end()) return;
            const auto chains = state->routes[found->second].chains;
            for (auto id : chains) handoffChain(id, "runtime_rotation_dependency");
        };
        releaseGroup(action->m_targetGroupID);
        releaseGroup(action->m_centerGroupID);
    }
}
void beforeToggle(GJBaseGameLayer* layer, int group) {
    if (!state || state->layer != layer || !state->ready || state->internal || !state->owned() || controlledToggleVisibility()) return;
    // GD clamps negative IDs to 0 and IDs above 9999 to 9999. Compilation
    // prepares every positive membership array; an absent array has no owned
    // members. Membership changes already force a handoff before mutation.
    if (group <= 0) return;
    const auto normalized = static_cast<std::size_t>(std::min(group, 9999));
    if (normalized >= layer->m_groups.size()) { releaseAll("unresolved_native_toggle_group"); return; }
    auto* objects = layer->m_groups[normalized];
    if (!objects) return;
    releaseArray(objects, "native_toggle_dependency");
}
void atlasMutation(CCTextureAtlas* atlas, const char* reason) {
    if (!state || state->internal || state->compiling || !state->ready || !state->owned()) return;
    auto found = state->atlases.find(atlas);
    if (found == state->atlases.end()) return;
    std::vector<Handle> handles;
    for (auto id : found->second.objects) if (state->entries[id].owned) handles.push_back(state->scene->handle(id));
    handoff(handles, reason);
}
bool quadMutation(CCTextureAtlas* atlas, unsigned slot, const void* quad) {
    if (!state || state->internal || state->compiling || !state->ready || !state->owned()) return false;
    auto found = state->atlases.find(atlas);
    if (found == state->atlases.end()) return false;
    auto* descendants = found->second.batch->getDescendants();
    if (slot >= descendants->count()) return false;
    auto* object = typeinfo_cast<GameObject*>(descendants->objectAtIndex(slot));
    if (!object || !owns(object)) return false;
    if (slot < atlas->getTotalQuads() && std::memcmp(&atlas->getQuads()[slot], quad, sizeof(ccV3F_C4B_T2F_Quad)) == 0) return false;
    release(object, "quad_material_mutation");
    return true;
}
bool move(GJBaseGameLayer* layer, CCArray* objects, double dx, double dy, bool lockPlayerY,
          const std::function<void(CCArray*)>& native) {
    if (!state || state->layer != layer || !state->ready || state->internal || !objects) return false;
    if (!objects->count()) { native(objects); return true; }
    auto& live = *state;
    std::size_t routeIndex = std::numeric_limits<std::size_t>::max();
    const auto generation = live.scene->generation();
    if (live.cachedPoliciesEnabled && live.recentMoveArray == objects &&
        live.recentMoveSceneGeneration == generation &&
        live.recentMoveRoute < live.routes.size() &&
        live.routes[live.recentMoveRoute].source.data() == objects) {
        routeIndex = live.recentMoveRoute;
        ++live.stats.precompiledRouteHits;
    } else {
        if (live.cachedPoliciesEnabled) ++live.stats.routeHashLookups;
        auto found = live.routeIndices.find(objects);
        if (found != live.routeIndices.end()) {
            routeIndex = found->second;
            if (live.cachedPoliciesEnabled) {
                live.recentMoveArray = objects;
                live.recentMoveRoute = routeIndex;
                live.recentMoveSceneGeneration = generation;
            }
        }
    }
    if (routeIndex == std::numeric_limits<std::size_t>::max()) {
        releaseArray(objects, "uncompiled_native_array");
        live.stats.nativeMoveVisits += objects->count();
        native(objects);
        return true;
    }
    auto& route = live.routes[routeIndex];
    if (!live.censusMasks.empty()) ++route.censusCalls;
    if (!route.owned) { live.stats.nativeMoveVisits += objects->count(); native(objects); return true; }
    // The pinned 2.2091 moveObjects body does not read lockPlayerY. The native
    // action processor has already resolved its translation parameters.
    (void)lockPlayerY;
    if (objects->count() != route.count) {
        releaseAll("native_array_or_lock_changed");
        live.stats.nativeMoveVisits += objects->count(); native(objects); return true;
    }
    const Translation delta{dx, dy};
    const auto active = route.chains;
CameraCache cameras;

for (auto id : active) {
    const auto offset = live.scene->chainTranslation(id);
    const auto error = live.chains[id].precision.nextError(
        offset, delta
    );

    if (auto* reason = unsafe(
        id,
        {offset.x + dx, offset.y + dy},
        error,
        &cameras
    )) {
        handoffChain(id, reason);
        cameras.clear();
    }
}
    if (!route.owned) { live.stats.nativeMoveVisits += objects->count(); native(objects); return true; }
    for (auto id : route.chains) {
        auto& chain = live.chains[id];
        chain.precision.accumulatedError = chain.precision.nextError(live.scene->chainTranslation(id), delta);
    }
    const auto owned = route.owned;
    const Ref<CCArray> nativeSubset = route.native;
    for (auto id : route.chains)
        if (auto& history = live.chains[id].history)
            history->move(route.token, delta, live.order + 1, layer->m_gameState.m_commandIndex);
    live.scene->translate(route.token, delta, ++live.order, live);
    layer->m_movedCount += owned;
    live.stats.eliminatedVisits += owned;
    live.stats.headlessEliminatedVisits += route.ownedHeadless;
    ++live.stats.translations;
    live.stats.maxActiveChains = std::max<std::uint64_t>(live.stats.maxActiveChains, route.chains.size());
    live.stats.maxDirty = std::max<std::uint64_t>(live.stats.maxDirty, live.scene->updates().size());
    if (live.validate) {
        for (auto id : route.members) {
            auto& entry = live.entries[id];
            if (!entry.owned) continue;
            entry.reference.x += dx;
            entry.reference.y += dy;
            const auto actual = live.scene->position(live.scene->handle(id));
            live.stats.maxDivergence = std::max({live.stats.maxDivergence,
                std::abs(actual.x - entry.reference.x), std::abs(actual.y - entry.reference.y)});
            ++live.stats.validationVisits;
        }
    }
    if (nativeSubset->count()) { live.stats.nativeMoveVisits += nativeSubset->count(); native(nativeSubset.data()); }
    return true;
}
bool drawAtlas(CCTextureAtlas* atlas, unsigned count, unsigned first, const std::function<void(unsigned, unsigned)>& native) {
    if (!state || state->internal || state->drawing || !state->visiblePass) return false;
    auto& live = *state;
    if (live.gpuTimer && !live.gpuStarted && live.context == wglGetCurrentContext()) {
        live.gpuTimer->begin(); live.gpuStarted = true;
    }
    live.drawing = true;
    struct DrawingScope { Live& live; ~DrawingScope() { live.drawing = false; } } drawingScope{live};
    // GD 2.2091 uploads only [start, start + count) on a dirty atlas draw,
    // then clears the atlas-wide dirty flag. A split mixed-ownership draw
    // must carry that original dirty state to every native subrange.
    const bool originalAtlasDirty = atlas->isDirty();
    auto nativeRange = [&](unsigned n, unsigned start) {
        if (!n) return;
        ++live.stats.nativeDraws;
        live.stats.nativeQuads += n;
        if (originalAtlasDirty) atlas->setDirty(true);
        const bool dirty = atlas->isDirty();
        native(n, start);
        if (dirty && !atlas->isDirty()) {
            ++live.stats.nativeAtlasUploads;
            live.stats.nativeAtlasDirtyBytes += static_cast<std::uint64_t>(n) * sizeof(ccV3F_C4B_T2F_Quad);
        }
    };
    if (!live.ready || !live.renderer || !live.owned()) { nativeRange(count, first); return true; }
    auto found = live.atlases.find(atlas);
    if (found == live.atlases.end()) { nativeRange(count, first); return true; }
    if (live.context != wglGetCurrentContext()) {
        releaseAll("draw_context_replacement");
        live.renderer->abandonContext(); live.renderer.reset();
        nativeRange(count, first); return true;
    }
    kmMat4 projection, view, mvp;
    kmGLGetMatrix(KM_GL_PROJECTION, &projection); kmGLGetMatrix(KM_GL_MODELVIEW, &view);
    kmMat4Multiply(&mvp, &projection, &view);
    std::array<float, 16> matrix;
    std::copy_n(mvp.mat, 16, matrix.begin());
    std::optional<std::uint32_t> previousPage;
    live.drawingAtlas = atlas;
    unsigned nativeRanges = 0, sharedRanges = 0;
    unsigned completed = first;
    try { found->second.plan.submit(first, count, [&](unsigned n, unsigned start) { ++nativeRanges; nativeRange(n, start); completed = start + n; },
        [&](const Draw& draw) {
            const auto original = live.scene->drawFor(live.scene->handle(draw.nativeObject));
            // Once a range has been attempted, recovery continues after it.
            // This prevents duplicate blending if a driver reports a late error.
            completed = live.entries[draw.nativeObject].slot + (draw.firstVertex - original.firstVertex + draw.vertexCount) / 6;
            live.renderer->renderRanges(*live.scene, std::span<const Draw>(&draw, 1), matrix, live);
            ++live.stats.v2Draws;
            live.stats.v2Quads += draw.vertexCount / 6;
            ++sharedRanges;
            if (previousPage && *previousPage != draw.page) ++live.stats.pageBreaks;
            previousPage = draw.page;
        }); } catch (const std::exception& error) {
        ++live.stats.renderFailures;
        log::error("VULKANIZER_V2_RENDER recovery={} attempted_range_not_replayed=true", error.what());
        releaseAll("renderer_failure");
        live.renderer.reset();
        if (completed < first + count) nativeRange(first + count - completed, completed);
    }
    if (sharedRanges) ++live.stats.materialBoundaries;
    if (nativeRanges && sharedRanges) live.stats.ownershipBoundaries += nativeRanges + sharedRanges - 1;
    return true;
}
void recordSpriteVisit(CCSprite*, bool suppressed) {
    if (!state || !state->ready || state->internal) return;
    ++state->stats.spriteVisits;
    if (suppressed) ++state->stats.geometrySuppressed;
}
void recordSectionCommit(GameObject* object) {
    if (!state || !state->ready || state->internal) return;
    ++state->stats.nativeCommitCallbacks;
    if (owns(object)) {
        ++state->stats.ownershipCommitViolations;
        release(object, "unexpected_authoritative_section_consumer");
    }
}
void frameBegin() {
    if (!state) return;
    state->frameStart = Clock::now();
    state->frameCaptured = false;
    state->gpuStarted = false;
    if (state->gpuTimer && state->context == wglGetCurrentContext()) state->gpuTimer->collect();
}
void beforeSwap() {
    const auto& flags = envFlags();
    if (!state) return;
    auto& live = *state;
    if (live.gpuTimer && live.context == wglGetCurrentContext()) live.gpuTimer->end();
    const auto& path = flags.capturePath;
    const auto captureTime = flags.captureTime.value_or(.75);
    if (!path || captured || live.layer->m_gameState.m_levelTime < captureTime) return;
    GLint viewport[4]{};
    glGetIntegerv(GL_VIEWPORT, viewport);
    if (viewport[2] <= 0 || viewport[3] <= 0) return;
    std::vector<unsigned char> pixels(static_cast<std::size_t>(viewport[2]) * viewport[3] * 4);
    glReadPixels(viewport[0], viewport[1], viewport[2], viewport[3], GL_RGBA, GL_UNSIGNED_BYTE, pixels.data());
    std::ofstream file(*path, std::ios::binary);
    file << "P6\n" << viewport[2] << ' ' << viewport[3] << "\n255\n";
    for (int row = viewport[3] - 1; row >= 0; --row)
        for (int column = 0; column < viewport[2]; ++column)
            file.write(reinterpret_cast<const char*>(pixels.data() + (static_cast<std::size_t>(row) * viewport[2] + column) * 4), 3);
    live.stats.validationReadbackBytes += pixels.size();
    live.capture = matjson::makeObject({{"level_time", live.layer->m_gameState.m_levelTime}, {"ticks", testTicks},
        {"player_x", live.layer->m_player1->getPositionX()}, {"player_y", live.layer->m_player1->getPositionY()},
        {"owned", live.owned()}, {"width", viewport[2]}, {"height", viewport[3]}});
    if (flags.colorShakeFixture && flags.test &&
        !flags.levelName) {
        for (const auto& entry : live.entries) if (entry.batch) {
            const auto p = entry.batch->convertToWorldSpace({0, 0});
            const auto x = entry.batch->convertToWorldSpace({1, 0});
            const auto y = entry.batch->convertToWorldSpace({0, 1});
            (*live.capture)["fixture_camera"] = matjson::makeObject({{"x", p.x}, {"y", p.y},
                {"xx", x.x - p.x}, {"xy", x.y - p.y}, {"yx", y.x - p.x}, {"yy", y.y - p.y}});
            break;
        }
    }
    if ((flags.xlockFixture || flags.headlessFixture) && flags.test &&
        !flags.levelName) {
        (*live.capture)["fixture_positions"] = matjson::Value::array();
        for (ObjectId id = 0; id < live.entries.size(); ++id) {
            auto& entry = live.entries[id];
            if (!entry.batch && !entry.headless) continue;
            auto p = entry.owned ? live.scene->position(live.scene->handle(id)) :
                Translation{entry.object->m_positionX, entry.object->m_positionY};
            const auto quad = entry.object->getQuad();
            auto sample = matjson::makeObject({
                {"id", id}, {"x", p.x}, {"y", p.y}, {"owned", entry.owned},
                {"quad_bl_x", quad.bl.vertices.x}, {"quad_bl_y", quad.bl.vertices.y},
                {"quad_tr_x", quad.tr.vertices.x}, {"quad_tr_y", quad.tr.vertices.y},
                {"color_r", quad.bl.colors.r}, {"color_g", quad.bl.colors.g},
                {"color_b", quad.bl.colors.b}, {"color_a", quad.bl.colors.a},
                {"history_x", entry.object->m_lastPosition.x}, {"history_y", entry.object->m_lastPosition.y},
                {"stamp", entry.object->m_unk4C4},
                {"visible", entry.object->isVisible()}, {"atlas_index", entry.object->getAtlasIndex()}});
            const auto slot = entry.object->getAtlasIndex();
            if (entry.atlas && slot < entry.atlas->getTotalQuads()) {
                const auto atlasQuad = entry.atlas->getQuads()[slot];
                sample["atlas_bl_x"] = atlasQuad.bl.vertices.x;
                sample["atlas_bl_y"] = atlasQuad.bl.vertices.y;
                sample["atlas_tr_x"] = atlasQuad.tr.vertices.x;
                sample["atlas_tr_y"] = atlasQuad.tr.vertices.y;
            }
            (*live.capture)["fixture_positions"].push(std::move(sample));
        }
    }
    auto size = CCDirector::sharedDirector()->getWinSize();
    double left = viewport[2], right = 0, bottom = viewport[3], top = 0;
    for (ObjectId id = 0; id < live.entries.size(); ++id) {
        const auto& entry = live.entries[id];
        if (!entry.batch) continue;
        const auto offset = entry.owned ? live.scene->chainTranslation(live.scene->chainFor(live.scene->handle(id))) : Translation{};
        const auto quad = entry.object->getQuad();
        for (auto corner : {quad.bl, quad.br, quad.tl, quad.tr}) {
            const auto point = entry.batch->convertToWorldSpace({corner.vertices.x + static_cast<float>(offset.x), corner.vertices.y + static_cast<float>(offset.y)});
            const double x = point.x / size.width * viewport[2], y = viewport[3] - point.y / size.height * viewport[3];
            left = std::min(left, x); right = std::max(right, x); bottom = std::min(bottom, y); top = std::max(top, y);
        }
    }
    (*live.capture)["roi_left"] = std::max(0, static_cast<int>(std::floor(left)) - 4);
    (*live.capture)["roi_top"] = std::max(0, static_cast<int>(std::floor(bottom)) - 4);
    (*live.capture)["roi_right"] = std::min(viewport[2], static_cast<int>(std::ceil(right)) + 4);
    (*live.capture)["roi_bottom"] = std::min(viewport[3], static_cast<int>(std::ceil(top)) + 4);
    captured = true;
    live.frameCaptured = true;
}
void physicsStep(PlayLayer* layer) {
    if (state && state->layer == layer) ++state->ticks;
    if (testRunning) ++testTicks;
}
void frameEnd() {
    const auto& flags = envFlags();
    if (!state) return;
    auto& live = *state;
    if (!live.ready && !live.assessed && live.visiblePass) {
        try { compile(); }
        catch (const std::exception& error) {
            log::error("VULKANIZER_V2_COMPILE failure={} native_recovery=true", error.what());
            live.compiling = false;
            live.ready = true;
            releaseAll("compilation_failure");
        }
    }
    if (live.ready && flags.toggleFixture &&
        flags.test && !flags.levelName) {
        if (!live.toggleFixtureTrace) {
            live.toggleFixtureTrace = matjson::Value::array();
            if (live.layer->m_groups.size() > 9998 && live.layer->m_groups[9998])
                for (auto* object : CCArrayExt<GameObject, false>(live.layer->m_groups[9998])) {
                    if (object->m_objectType != GameObjectType::Decoration) continue;
                    live.toggleFixtureObjects.push_back(object);
                    if (live.toggleFixtureObjects.size() == 2) break;
                }
        }
        const auto time = live.layer->m_gameState.m_levelTime;
        const double thresholds[]{.20, .45, .70};
        if (live.toggleFixturePhase < 3 && time >= thresholds[live.toggleFixturePhase] && live.toggleFixtureObjects.size() == 2) {
            auto event = matjson::makeObject({{"phase", live.toggleFixturePhase}, {"level_time", time},
                {"command_index", live.layer->m_gameState.m_commandIndex}});
            event["objects"] = matjson::Value::array();
            for (auto& ref : live.toggleFixtureObjects) {
                auto* o = ref.data();
                auto p = Translation{o->m_positionX, o->m_positionY};
                auto id = live.ids.find(o);
                const bool owned = id != live.ids.end() && live.entries[id->second].owned;
                if (owned) p = live.scene->position(live.scene->handle(id->second));
                event["objects"].push(matjson::makeObject({{"x", p.x}, {"y", p.y}, {"v2_owned", owned},
                    {"history_x", o->m_lastPosition.x}, {"history_y", o->m_lastPosition.y},
                    {"stamp", o->m_unk4C4}, {"decoration2", o->m_isDecoration2},
                    {"group_disabled", o->m_isGroupDisabled}, {"visible", o->isVisible()}}));
            }
            live.toggleFixtureTrace->push(std::move(event));
            if (live.toggleFixturePhase == 0) live.layer->toggleGroup(9998, false);
            if (live.toggleFixturePhase == 1) live.layer->toggleGroup(9998, true);
            ++live.toggleFixturePhase;
        }
    }
    if (live.ready && !live.structuralHandoffTest && flags.structuralFixture && flags.test &&
        !flags.levelName && live.layer->m_gameState.m_levelTime >= .4) {
        live.structuralHandoffOwned = true;
        for (auto& entry : live.entries) {
            auto* object = entry.object.data();
            if (object->m_objectID != 1757 || !entry.batch) continue;
            live.structuralHandoffTest = true;
            live.structuralHandoffOwned &= entry.owned;
            live.structuralHandoffObjects.push_back(object);
            object->setRotation(object->getRotation() + 19.f);
            if (live.structuralHandoffObjects.size() == 4) break;
        }
    }
    ++live.frames;
    if (flags.test && live.layer->m_gameState.m_levelTime >= 80 && !live.benchmarkStarted) {
        live.benchmarkStarted = true;
        live.benchmarkStart = live.stats;
    }
    if (live.benchmarkStarted && !live.benchmarkFinished && live.layer->m_gameState.m_levelTime >= 90) {
        live.benchmarkFinished = true;
        live.benchmarkEnd = live.stats;
    }
    if (live.progressStart == Clock::time_point{} && live.layer->m_gameState.m_levelTime > 0) live.progressStart = Clock::now();
    if (live.frameStart != Clock::time_point{} && !live.frameCaptured) {
        if (live.cpuFrames.size() == 4096) live.cpuFrames.erase(live.cpuFrames.begin(), live.cpuFrames.begin() + 2048);
        const auto elapsed = std::chrono::duration<double, std::milli>(Clock::now() - live.frameStart).count();
        if (live.benchmarkStarted && !live.benchmarkFinished) live.cpuBenchmarkFrames.push_back(elapsed);
        live.cpuFrames.push_back(elapsed);
        if (live.owned() && live.layer->m_gameState.m_levelTime > 0) {
            if (live.cpuOwnedFrames.size() == 4096) live.cpuOwnedFrames.erase(live.cpuOwnedFrames.begin(), live.cpuOwnedFrames.begin() + 2048);
            live.cpuOwnedFrames.push_back(elapsed);
        }
    }
    if (live.frames % 240 == 0) report("frame_window");
    const auto duration = flags.testSeconds.value_or(8);
    if (testRunning && testInitialLevelTime < 0) testInitialLevelTime = live.layer->m_gameState.m_levelTime;
    if (testRunning && (live.layer->m_gameState.m_levelTime - testInitialLevelTime >= duration ||
        std::chrono::duration<double>(Clock::now() - testStarted).count() > duration + 40)) {
        live.testCompleted = true;
        live.retainedAtCompletion = live.owned();
        live.headlessRetainedAtCompletion = static_cast<unsigned>(live.stats.headlessAcquired - live.stats.headlessReleased);
        report("test_complete");
        log::info("VULKANIZER_V2_TEST complete native_ticks={} level_time={} player=({},{})", testTicks,
            live.layer->m_gameState.m_levelTime, live.layer->m_player1->getPositionX(), live.layer->m_player1->getPositionY());
        testRunning = false;
        PostMessageW(WindowFromDC(wglGetCurrentDC()), WM_CLOSE, 0, 0);
    }
}
bool startTest() {
    const auto& flags = envFlags();
    if (!requested() || !flags.test) return false;
    if (testLaunched) return true;
    testLaunched = true;
    GJGameLevel* level = nullptr;
    if (const auto& name = flags.levelName) {
        for (auto* item : CCArrayExt<GJGameLevel, false>(LocalLevelManager::sharedState()->getCreatedLevels(0)))
            if (item->m_levelName == name->c_str()) { level = item; break; }
    } else {
        level = GJGameLevel::create();
        level->m_levelName = "V2 Translation Control";
        std::string setup = "kS38,1,kA13,0,kA15,0,kA16,0,kA6,1;";
        for (unsigned i = 0; i < 64; ++i) {
            const auto groups = i % 3 == 0 ? "9998.9997" : i % 3 == 1 ? "9998" : "9997";
            const auto originX = flags.headlessFixture ? 900 : 230;
            setup += fmt::format("1,1757,2,{},3,{},57,{},64,1,67,1", originX + i % 8 * 6, 140 + i / 8 * 6, groups);
            if (flags.colorShakeFixture && i % 2 == 0) setup += ",21,42";
            setup += ";";
        }
        // Real native triggers and a gameplay solid share the group in the
        // controlled level. The solid must keep native transformation/drawing.
        setup += "1,1,2,6000,3,15,57,9998;1,901,2,15,3,15,51,9998,28,16,29,0,10,4;1,901,2,20,3,15,51,9997,28,-8,29,4,10,4;";
        if (flags.colorShakeFixture)
            setup += "1,899,2,15,3,15,23,42,7,255,8,10,9,10,10,2;1,1520,2,15,3,15,10,2,75,1,84,0.2;";
        if (flags.headlessFixture && flags.headlessAlpha)
            setup += "1,1007,2,16,3,15,51,9998,35,0.4,10,1;";
        if (flags.toggleFixture)
            setup += "1,1049,2,6000,3,15,51,9998,56,1;";
        level->m_levelString = setup;
    }
    if (!level) { log::error("VULKANIZER_V2_TEST requested level missing"); return true; }
    if (flags.colorShakeFixture && !flags.levelName) std::srand(314159);
    auto* scene = PlayLayer::scene(level, false);
    if (!scene) { log::error("VULKANIZER_V2_TEST PlayLayer scene creation failed"); return true; }
    CCDirector::sharedDirector()->replaceScene(scene);
    testRunning = true; testTicks = 0; testInitialLevelTime = -1; captured = false; testStarted = Clock::now();
    log::info("VULKANIZER_V2_TEST started level={} baseline={} native_gameplay_timing=true", level->m_levelName, flags.baseline);
    return true;
}
}
