#include "GlRenderer.hpp"
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <GL/gl.h>
#include <algorithm>
#include <cstddef>
#include <cstring>
#include <limits>
#include <stdexcept>
#include <string>

namespace vulkanizer::v2 {
namespace {
constexpr GLenum arrayBuffer = 0x8892, uniformBuffer = 0x8a11;
constexpr std::size_t pageBytes = paletteSize * sizeof(PaletteEntry);
const char* vertexSource = R"(#version 330 core
layout(location=0) in vec3 position;
layout(location=1) in vec2 texcoord;
layout(location=2) in vec4 color;
layout(location=3) in float chain;
layout(std140) uniform Chains { vec4 translation[256]; };
uniform mat4 mvp;
out vec2 uv;
out vec4 tint;
void main() {
    vec3 p = position;
    p.xy += translation[int(chain)].xy;
    gl_Position = mvp * vec4(p, 1.0);
    uv = texcoord;
    tint = color;
})";
const char* fragmentSource = R"(#version 330 core
in vec2 uv;
in vec4 tint;
uniform sampler2D texture0;
out vec4 outputColor;
void main() { outputColor = texture(texture0, uv) * tint; }
)";
}
struct GlRenderer::Impl {
#define PROC(R, N, A) R(APIENTRY* N)A = nullptr
    PROC(GLuint, CreateShader, (GLenum));
    PROC(void, ShaderSource, (GLuint, GLsizei, const char* const*, const GLint*));
    PROC(void, CompileShader, (GLuint));
    PROC(void, GetShaderiv, (GLuint, GLenum, GLint*));
    PROC(void, GetShaderInfoLog, (GLuint, GLsizei, GLsizei*, char*));
    PROC(void, DeleteShader, (GLuint));
    PROC(GLuint, CreateProgram, ());
    PROC(void, AttachShader, (GLuint, GLuint));
    PROC(void, LinkProgram, (GLuint));
    PROC(void, GetProgramiv, (GLuint, GLenum, GLint*));
    PROC(void, GetProgramInfoLog, (GLuint, GLsizei, GLsizei*, char*));
    PROC(void, DeleteProgram, (GLuint));
    PROC(void, UseProgram, (GLuint));
    PROC(GLint, GetUniformLocation, (GLuint, const char*));
    PROC(void, Uniform1i, (GLint, GLint));
    PROC(void, UniformMatrix4fv, (GLint, GLsizei, GLboolean, const float*));
    PROC(GLuint, GetUniformBlockIndex, (GLuint, const char*));
    PROC(void, UniformBlockBinding, (GLuint, GLuint, GLuint));
    PROC(void, GenBuffers, (GLsizei, GLuint*));
    PROC(void, DeleteBuffers, (GLsizei, const GLuint*));
    PROC(void, BindBuffer, (GLenum, GLuint));
    PROC(void, BufferData, (GLenum, std::ptrdiff_t, const void*, GLenum));
    PROC(void, BufferSubData, (GLenum, std::ptrdiff_t, std::ptrdiff_t, const void*));
    PROC(void, BindBufferRange, (GLenum, GLuint, GLuint, std::ptrdiff_t, std::ptrdiff_t));
    PROC(void, GenVertexArrays, (GLsizei, GLuint*));
    PROC(void, DeleteVertexArrays, (GLsizei, const GLuint*));
    PROC(void, BindVertexArray, (GLuint));
    PROC(void, EnableVertexAttribArray, (GLuint));
    PROC(void, VertexAttribPointer, (GLuint, GLint, GLenum, GLboolean, GLsizei, const void*));
    PROC(void, GetIntegerv, (GLenum, GLint*));
    PROC(void, GetIntegeri_v, (GLenum, GLuint, GLint*));
    PROC(void, GetInteger64i_v, (GLenum, GLuint, std::int64_t*));
    PROC(void, BindBufferBase, (GLenum, GLuint, GLuint));
    PROC(void, DrawArrays, (GLenum, GLint, GLsizei));
    PROC(GLenum, GetError, ());
#undef PROC
    GLuint program = 0, geometry = 0, palette = 0, vao = 0;
    GLint mvpLocation = -1, textureLocation = -1;
    std::size_t stride = pageBytes;
    std::uint64_t generation = 0;
    RenderCounters counters;

    explicit Impl(const Resolve& resolve) {
#define LOAD(N) N = reinterpret_cast<decltype(N)>(resolve("gl" #N)); if (!N) throw std::runtime_error("Missing GL entry point gl" #N)
        LOAD(CreateShader); LOAD(ShaderSource); LOAD(CompileShader); LOAD(GetShaderiv);
        LOAD(GetShaderInfoLog); LOAD(DeleteShader); LOAD(CreateProgram); LOAD(AttachShader);
        LOAD(LinkProgram); LOAD(GetProgramiv); LOAD(GetProgramInfoLog); LOAD(DeleteProgram);
        LOAD(UseProgram); LOAD(GetUniformLocation); LOAD(Uniform1i); LOAD(UniformMatrix4fv);
        LOAD(GetUniformBlockIndex); LOAD(UniformBlockBinding); LOAD(GenBuffers); LOAD(DeleteBuffers);
        LOAD(BindBuffer); LOAD(BufferData); LOAD(BufferSubData); LOAD(BindBufferRange);
        LOAD(GenVertexArrays); LOAD(DeleteVertexArrays); LOAD(BindVertexArray);
        LOAD(EnableVertexAttribArray); LOAD(VertexAttribPointer); LOAD(GetIntegerv); LOAD(DrawArrays); LOAD(GetError);
        LOAD(GetIntegeri_v); LOAD(GetInteger64i_v); LOAD(BindBufferBase);
#undef LOAD
    }
    void check(const char* operation) {
        const auto error = GetError();
        if (error) throw std::runtime_error(std::string(operation) + " GL error " + std::to_string(error));
    }
    struct StateGuard {
        Impl& gl;
        GLint program = 0, vao = 0, array = 0, uniform = 0, indexed = 0;
        std::int64_t start = 0, size = 0;
        explicit StateGuard(Impl& api) : gl(api) {
            gl.GetIntegerv(0x8b8d, &program);
            gl.GetIntegerv(0x85b5, &vao);
            gl.GetIntegerv(0x8894, &array);
            gl.GetIntegerv(0x8a28, &uniform);
            gl.GetIntegeri_v(0x8a28, 0, &indexed);
            gl.GetInteger64i_v(0x8a29, 0, &start);
            gl.GetInteger64i_v(0x8a2a, 0, &size);
        }
        ~StateGuard() {
            gl.UseProgram(program);
            gl.BindVertexArray(vao);
            gl.BindBuffer(arrayBuffer, array);
            if (indexed && size > 0) gl.BindBufferRange(uniformBuffer, 0, indexed, start, size);
            else gl.BindBufferBase(uniformBuffer, 0, indexed);
            gl.BindBuffer(uniformBuffer, uniform);
        }
    };
    GLuint shader(GLenum type, const char* source) {
        const auto id = CreateShader(type);
        ShaderSource(id, 1, &source, nullptr);
        CompileShader(id);
        GLint success = 0;
        GetShaderiv(id, 0x8b81, &success);
        if (!success) {
            char log[4096]{};
            GetShaderInfoLog(id, sizeof(log), nullptr, log);
            DeleteShader(id);
            throw std::runtime_error(std::string("V2 shader compilation failed ") + log);
        }
        return id;
    }
    void createProgram() {
        GLuint vertex = 0, fragment = 0;
        try {
            vertex = shader(0x8b31, vertexSource);
            fragment = shader(0x8b30, fragmentSource);
            program = CreateProgram();
            AttachShader(program, vertex);
            AttachShader(program, fragment);
            LinkProgram(program);
            GLint success = 0;
            GetProgramiv(program, 0x8b82, &success);
            if (!success) {
                char log[4096]{};
                GetProgramInfoLog(program, sizeof(log), nullptr, log);
                throw std::runtime_error(std::string("V2 program linking failed ") + log);
            }
            UniformBlockBinding(program, GetUniformBlockIndex(program, "Chains"), 0);
            mvpLocation = GetUniformLocation(program, "mvp");
            textureLocation = GetUniformLocation(program, "texture0");
        } catch (...) {
            if (vertex) DeleteShader(vertex);
            if (fragment) DeleteShader(fragment);
            throw;
        }
        DeleteShader(vertex);
        DeleteShader(fragment);
    }
    ~Impl() {
        if (vao) DeleteVertexArrays(1, &vao);
        if (geometry) DeleteBuffers(1, &geometry);
        if (palette) DeleteBuffers(1, &palette);
        if (program) DeleteProgram(program);
    }
};
GlRenderer::GlRenderer(Resolve resolve) : m_impl(std::make_unique<Impl>(resolve)) {
    m_impl->createProgram();
}
GlRenderer::~GlRenderer() = default;
void GlRenderer::attach(Scene& scene) {
    auto& gl = *m_impl;
    Impl::StateGuard preserve(gl);
    gl.generation = 0;
    GLint alignment = 0, maxBlock = 0;
    gl.GetIntegerv(0x8a34, &alignment);
    gl.GetIntegerv(0x8a30, &maxBlock);
    if (alignment <= 0 || maxBlock < pageBytes) throw std::runtime_error("V2 palette UBO unavailable");
    gl.stride = ((pageBytes + alignment - 1) / alignment) * alignment;
    if (!gl.geometry) gl.GenBuffers(1, &gl.geometry);
    if (!gl.palette) gl.GenBuffers(1, &gl.palette);
    if (!gl.vao) gl.GenVertexArrays(1, &gl.vao);
    gl.BindVertexArray(gl.vao);
    gl.BindBuffer(arrayBuffer, gl.geometry);
    const auto vertices = scene.geometry();
    gl.BufferData(arrayBuffer, vertices.size_bytes(), vertices.data(), 0x88e4);
    gl.EnableVertexAttribArray(0);
    gl.EnableVertexAttribArray(1);
    gl.EnableVertexAttribArray(2);
    gl.EnableVertexAttribArray(3);
    gl.VertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, x)));
    gl.VertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, u)));
    gl.VertexAttribPointer(2, 4, GL_UNSIGNED_BYTE, GL_TRUE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, color)));
    gl.VertexAttribPointer(3, 1, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(offsetof(Vertex, chain)));
    // Bring the retained palette up to date even when this is a recovery attach.
    scene.updates();
    const auto palette = scene.palette();
    const auto pages = (palette.size() + paletteSize - 1) / paletteSize;
    std::vector<std::byte> initial(std::max<std::size_t>(pages, 1) * gl.stride);
    for (std::size_t id = 0; id < palette.size(); ++id)
        std::memcpy(initial.data() + (id / paletteSize) * gl.stride + (id % paletteSize) * sizeof(PaletteEntry),
            &palette[id], sizeof(PaletteEntry));
    gl.BindBuffer(uniformBuffer, gl.palette);
    gl.BufferData(uniformBuffer, initial.size(), initial.data(), 0x88e8);
    scene.draws();
    gl.check("V2 scene upload");
    scene.acknowledgeUpdates();
    gl.counters.initialUploadBytes += vertices.size_bytes() + initial.size();
    gl.generation = scene.generation();
}
void GlRenderer::render(Scene& scene, const std::array<float, 16>& mvp, RenderSink& sink) {
    renderRanges(scene, scene.draws(), mvp, sink);
}
void GlRenderer::renderRanges(Scene& scene, std::span<const Draw> draws,
                             const std::array<float, 16>& mvp, RenderSink& sink) {
    auto& gl = *m_impl;
    Impl::StateGuard preserve(gl);
    if (gl.generation != scene.generation()) throw std::logic_error("Attach the V2 scene before rendering");
    gl.BindBuffer(uniformBuffer, gl.palette);
    for (const auto& update : scene.updates()) {
        const auto offset = (update.chain / paletteSize) * gl.stride + (update.chain % paletteSize) * sizeof(PaletteEntry);
        gl.BufferSubData(uniformBuffer, offset, sizeof(PaletteEntry), &update.value);
        gl.counters.uploadBytes += sizeof(PaletteEntry);
        gl.counters.paletteUploadBytes += sizeof(PaletteEntry);
    }
    gl.check("V2 palette update");
    scene.acknowledgeUpdates();
    for (const auto& draw : draws) {
        if (draw.path == ExecutionPath::nativeCpu) { sink.drawNative(draw.nativeObject); continue; }
        sink.bindMaterial(draw.material);
        // A native range can mutate GL state, so each shared range establishes
        // all state owned by this backend again at its original draw position.
        gl.UseProgram(gl.program);
        gl.BindVertexArray(gl.vao);
        gl.UniformMatrix4fv(gl.mvpLocation, 1, GL_FALSE, mvp.data());
        gl.Uniform1i(gl.textureLocation, 0);
        gl.counters.drawUniformUploadBytes += sizeof(float) * 16 + sizeof(GLint);
        gl.counters.uploadBytes += sizeof(float) * 16 + sizeof(GLint);
        gl.BindBufferRange(uniformBuffer, 0, gl.palette, draw.page * gl.stride, pageBytes);
        if (draw.vertexCount > std::numeric_limits<GLsizei>::max()) throw std::length_error("V2 draw range too large");
        gl.DrawArrays(GL_TRIANGLES, draw.firstVertex, draw.vertexCount);
        ++gl.counters.drawCalls;
    }
    gl.check("V2 ordered rendering");
}
void GlRenderer::abandonContext() {
    auto& gl = *m_impl;
    // Resources belong to the lost context. Calling its deletion functions in
    // a replacement context could delete unrelated names owned by the host.
    gl.program = gl.geometry = gl.palette = gl.vao = 0;
    gl.generation = 0;
}
void GlRenderer::clearCounters() { m_impl->counters = {}; }
const RenderCounters& GlRenderer::counters() const { return m_impl->counters; }
}
