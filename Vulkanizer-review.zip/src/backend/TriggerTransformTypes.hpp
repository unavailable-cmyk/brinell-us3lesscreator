#pragma once

#include <cstddef>
#include <cstdint>

namespace vulkanizer::gpu {

struct alignas(8) SectionEvent {
    double x = 0, y = 0;
    std::uint32_t actionIndex = 0, reserved = 0;
};

struct alignas(8) ObjectState {
    double x;
    double y;
    float rotation;
    float padding = 0;
    float offsetX = 0, offsetY = 0;
    float rotationOffsetX = 0, rotationOffsetY = 0;
    std::uint32_t options = 0, commandStamp = 0;
    std::int32_t sectionX = -1, sectionY = -1;
    float sectionFactorX = 0, sectionFactorY = 0;
    float historyX = 0, historyY = 0;
    std::uint32_t eventCount = 0, reserved = 0;
    SectionEvent events[4]{};
};

struct alignas(8) Action {
    std::uint32_t kind;  // 0 = move, 1 = rotate
    std::uint32_t flags; // bit 0 = lock rotation, bit 1 = resolved affine, bit 2 = lock X move
    double dx;
    double dy;
    double centerX;
    double centerY;
    float cosine;
    float sine;
    float rotationDelta;
    float padding = 0;
    float matrixA = 0;
    float matrixB = 0;
    float matrixC = 0;
    float matrixD = 0;
    float matrixTx = 0;
    float matrixTy = 0;
    float objectOffsetX = 0;
    float objectOffsetY = 0;
};

struct Span {
    std::uint32_t offset;
    std::uint32_t count;
};

static_assert(sizeof(SectionEvent) == 24);
static_assert(sizeof(ObjectState) == 176 && offsetof(ObjectState, rotation) == 16 && offsetof(ObjectState, events) == 80);
static_assert(sizeof(Action) == 88 && offsetof(Action, cosine) == 40 && offsetof(Action, matrixA) == 56);
static_assert(sizeof(Span) == 8);

} // namespace vulkanizer::gpu
