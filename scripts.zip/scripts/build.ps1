param(
    [string]$Configuration = 'RelWithDebInfo',
    [string]$Generator = 'Visual Studio 18 2026'
)
$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path $PSScriptRoot -Parent
$previousSdk = $env:GEODE_SDK
$previousPath = $env:PATH
$previousParallel = $env:CMAKE_BUILD_PARALLEL_LEVEL
Push-Location $projectRoot
try {
    $env:GEODE_SDK = Join-Path $projectRoot '.tools\geode-v6.0.0-alpha.1'
    if (!(Test-Path "$env:GEODE_SDK\VERSION")) { throw 'Install the pinned SDK as described in README.md first.' }
    if ((Get-Content "$env:GEODE_SDK\VERSION" -Raw).Trim() -ne '6.0.0-alpha.1') { throw 'Wrong SDK version.' }
    $env:PATH = "$(Join-Path $projectRoot '.tools\cli');$previousPath"
    $env:CMAKE_BUILD_PARALLEL_LEVEL = '6'
    & geode --version
    & geode sdk version
    # Windows PowerShell can turn harmless native stderr notices into errors
    # when output is redirected. The native exit code determines build success.
    $ErrorActionPreference = 'Continue'
    $buildArgs = @('build', '--config', $Configuration, '--', '-G', $Generator, '-DGEODE_DONT_INSTALL_MODS=ON')
    $existingBindings = Join-Path $projectRoot 'build\_deps\bindings-src'
    if (Test-Path "$existingBindings\.git") {
        $bindingsRevision = & git -C $existingBindings rev-parse HEAD
        if ($LASTEXITCODE -eq 0 -and $bindingsRevision -eq '8228e2b104e4e26c183ad7e5ef7442967c316077') {
            $buildArgs += "-DFETCHCONTENT_SOURCE_DIR_VULKANIZER_BINDINGS=$existingBindings"
        }
    }
    & geode @buildArgs 2>&1 | ForEach-Object { Write-Output "$_" }
    $buildExit = $LASTEXITCODE
    $ErrorActionPreference = 'Stop'
    if ($buildExit -ne 0) { throw "geode build failed: $buildExit" }
}
finally {
    Pop-Location
    $env:GEODE_SDK = $previousSdk
    $env:PATH = $previousPath
    $env:CMAKE_BUILD_PARALLEL_LEVEL = $previousParallel
}
